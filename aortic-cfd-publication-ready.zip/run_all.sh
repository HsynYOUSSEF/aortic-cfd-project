#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
CASE="cfd/repaired_run_01"
MODE="${1:-fresh}"
STAMP="$(date +%Y%m%d_%H%M%S)_$$"
LOGS="$ROOT/logs/run_$STAMP"
mkdir -p "$ROOT/logs" "$ROOT/reports" "$ROOT/results"
mkdir "$LOGS"
exec > >(tee "$LOGS/run.log") 2>&1
STAGE="environment"
trap 'code=$?; if (( code != 0 )); then printf "FAILED at %s; exit=%s; logs=%s\n" "$STAGE" "$code" "$LOGS" | tee "$ROOT/reports/LAST_RUN_STATUS.txt"; fi' EXIT
printf 'Starting repaired research case. Old project cases are not used.\n'
if [[ "$MODE" != "--resume" && -d "$CASE/constant/polyMesh" ]]; then
  printf 'This package already contains a generated mesh. Use Run-Simulation.ps1 -Resume only to deliberately continue it.\n'
  exit 2
fi
# Packaged OpenFOAM executables are on PATH; use the environment variables below.
export WM_PROJECT_DIR="${WM_PROJECT_DIR:-/usr/share/openfoam}"
export FOAM_ETC="${FOAM_ETC:-$WM_PROJECT_DIR/etc}"
for tool in blockMesh snappyHexMesh checkMesh surfaceCheck pimpleFoam ffmpeg ffprobe; do
  command -v "$tool" >/dev/null || { printf 'Missing dependency: %s. See README_FIRST.md.\n' "$tool"; exit 3; }
done
PY="${PYTHON_CFD:-$HOME/.venvs/aortic-cfd/bin/python}"
if [[ ! -x "$PY" ]]; then
  python3 -m venv "$ROOT/.venv"
  PY="$ROOT/.venv/bin/python"
  "$PY" -m pip install -r requirements.txt
fi
if ! "$PY" -c 'import numpy, scipy, vtk, PIL; assert hasattr(numpy,"trapezoid")'; then
  python3 -m venv "$ROOT/.venv"
  PY="$ROOT/.venv/bin/python"
  "$PY" -m pip install -r requirements.txt
fi
"$PY" -m pip freeze > "$LOGS/python_environment.txt"
STAGE="package integrity"
"$PY" src/verify_package.py
STAGE="surface checks"
"$PY" -c 'import json; from pathlib import Path; assert json.loads(Path("reports/surface_check.json").read_text())["status"]=="PASS"'
surfaceCheck "$CASE/constant/triSurface/aorta.stl" > "$LOGS/surfaceCheck.log" 2>&1
if grep -q 'checkSelfIntersection' <(surfaceCheck -help 2>&1); then
  surfaceCheck -checkSelfIntersection "$CASE/constant/triSurface/aorta.stl" > "$LOGS/surfaceCheck_intersections.log" 2>&1
fi
if [[ ! -f "$CASE/.mesh_complete" ]]; then
  STAGE="block mesh"
  blockMesh -case "$CASE" > "$LOGS/blockMesh.log" 2>&1
  STAGE="surface-fitted mesh"
  snappyHexMesh -case "$CASE" -overwrite > "$LOGS/snappyHexMesh.log" 2>&1
  touch "$CASE/.mesh_complete"
fi
STAGE="mesh validation"
checkMesh -case "$CASE" -allTopology -allGeometry > "$LOGS/checkMesh.log" 2>&1
"$PY" src/check_mesh_gate.py "$LOGS/checkMesh.log"
STAGE="flow solver"
pimpleFoam -case "$CASE" -noFunctionObjects > "$LOGS/solver.log" 2>&1
grep -q '^End' "$LOGS/solver.log"
LAST_TIME="$(grep '^Time = ' "$LOGS/solver.log" | tail -1 | awk '{print $3}' || true)"
if [[ -z "$LAST_TIME" ]]; then
  LAST_TIME="$("$PY" -c 'from pathlib import Path; import re; print(max(float(p.name) for p in Path("cfd/repaired_run_01").iterdir() if p.is_dir() and re.fullmatch(r"[0-9]+(?:\.[0-9]+)?",p.name) and (p/"U").is_file() and (p/"p").is_file()))')"
fi
"$PY" -c 'import sys; assert abs(float(sys.argv[1])-30)<1e-8, "Solver did not reach 30 seconds"' "$LAST_TIME"
STAGE="wall shear stress"
if ! pimpleFoam -case "$CASE" -postProcess -func wallShearStress -time '28:30' > "$LOGS/WSS.log" 2>&1; then
  if grep -qi 'sha1' "$LOGS/WSS.log"; then
    command -v g++ >/dev/null
    g++ -shared -fPIC -o "$LOGS/libsha1_compat.so" src/sha1_compat.cpp
    LD_PRELOAD="$LOGS/libsha1_compat.so${LD_PRELOAD:+:$LD_PRELOAD}" pimpleFoam -case "$CASE" -postProcess -func wallShearStress -time '28:30' > "$LOGS/WSS_retry.log" 2>&1
  else
    cat "$LOGS/WSS.log"
    exit 4
  fi
fi
STAGE="flow and WSS analysis"
"$PY" src/analyze_results.py
STAGE="particle and instantaneous-WSS video"
"$PY" src/render_flow_wss.py --project "$ROOT" --case repaired_run_01 --end 30 --seconds 30 --fps 30 --slowdown 8 --particles 4000 --output "$ROOT/results/video_$STAMP" > "$LOGS/render.log" 2>&1
printf 'COMPLETE: flow reached 30 s; WSS and video generated. Review numerical checks in results/repaired_run_01/summary.json.\n' | tee "$ROOT/reports/LAST_RUN_STATUS.txt"
