> Historical handoff; superseded by the completed 3.0 s transient result in `runs/runtime_optimization_20261018_01/reports/FINAL_STATUS.json`. No solver/controller is active. Do not treat the old target or session details below as current.

# Ubuntu continuation — 17 October 2026

The requested full simulation is **not complete**. All previous cases and results remain intact. The original prepared run's 24 manifest entries still match their SHA-256 hashes; see `runs/runtime_repair_20261017_01/reports/original_input_integrity.json`.

**Completed startup diagnostics:** the separate reduced-corrector case reached 0.01 s successfully in 1,585 seconds (about 26 minutes). Nine actual saved U/p/phi/WSS states passed finite-field, <0.5% conservation and <1% waveform gates. Worst relative imbalance is 3.81e-10; worst relative waveform error is 1.09e-5. At 0.01 s, peak speed is 0.5152 m/s, mean instantaneous WSS is 0.7918 Pa and maximum instantaneous WSS is 23.105 Pa. These are initial-transient values, not periodic-cycle WSS.

Primary new artifacts:

- `runs/corrector_test_20261017_01/cfd/aorta/aorta.foam`: real saved volume fields through 0.01 s.
- `runs/corrector_test_20261017_01/results/paraview_wall_series/wall_WSS_Pa.pvd`: nine actual wall states with WSS magnitude/vector explicitly in Pa; every VTP was read back and the PVD references checked.
- `runs/corrector_test_20261017_01/results/initial_transient_video_software/Initial_Transient_DIAGNOSTIC_720p.mp4`: actual nine-state diagnostic video, 5 seconds, 720p, 15 fps, 75 frames. FFprobe checks and a full FFmpeg decode pass; its final 0.01-s frame was visually inspected. It uses discrete saved phases and an orbiting camera, not five seconds of unique simulated flow or the requested final 1080p particle movie.
- `runs/corrector_test_20261017_01/reports/DIAGNOSTICS_COMPLETE.txt` and `short_test_summary.json`: startup diagnostic completion only.

Both solver branches have now ended. The reference was deliberately stopped after the successful common-time comparison; the faster branch completed its unchanged 0.01-s target. No long full solver is running. The full 30-s simulation, periodic-cycle gates, final-cycle WSS metrics and final 1080p/30fps/4,000-particle video remain uncompleted. MPI/PMIx is denied socket creation by the current sandbox; serial execution is possible but measured startup performance implies a very long full computation. The prepared full pipeline supports `AORTIC_RANKS=1` for serial execution, or its default eight ranks where MPI is normally permitted. It has not been run through the full stages. Its fresh case now includes an independently tested initial-flux reconstruction gate and hashes of the actual checked U/phi, in addition to the mesh and subsequent solution gates. All work directories and all intermediate results are retained; no cleanup or purge was performed.


## Repair and evidence

New baseline: `runs/runtime_repair_20261017_01`.

The installed runtime is Ubuntu OpenFOAM `1912.200626-2build3`. Executables resolve their finiteVolume/OpenFOAM libraries from `/lib`; `dpkg -V openfoam libopenfoam` found no changed package files. No other runtime is installed. Downloading a separate runtime failed at DNS resolution in this restricted environment.

Independent reconstruction of the saved, balanced face flux solves `sum(Sf Sf / |Sf|) U = sum(Sf phi / |Sf|)` for every cell. It gives maximum initial internal speed 3.48229 m/s and median 0.0723285 m/s; maximum equation residual is 1.06e-22. The original invalid U is archived in the new baseline's `reports/original_invalid_U`. Initial outlet patch values were also replaced with reconstructed adjacent-cell velocities. Native flux was retained. No native potentialFoam reconstruction is used again.

A two-cell SIMD store-order simulation of an in-place tensor–vector product reproduces the original corrupt components to maximum relative error approximately 1.2e-14. Even cell indices overwrite x/y together before evaluating z; odd indices overwrite x before evaluating y/z together. This explains why the earlier scalar in-place hypothesis did not match. It strongly identifies unsafe vector-field temporary reuse/aliasing in the compiled reconstruction path. Exact source-level/compiler provenance beyond that remains unproved. Native symmetric tensor inverse tests, both separate-buffer and in-place, agree with NumPy to approximately 1e-15 and do not reproduce the defect. See `src/inspect_alias.py`, `logs/alias.log`, and `logs/native_inverse.log`.

The fresh baseline passes full native `checkMesh -allTopology -allGeometry`. The original mesh gate has not been weakened. The transient now converges and writes actual U/p/phi fields.

## Validated initial saved fields, not periodic results

At 0.0001 and 0.0002 s, the VTK OpenFOAM reader successfully loads the 1,392,070-cell case, boundary patches, U, p and WSS. Peak speeds are approximately 1.318 and 1.193 m/s. Relative net flux imbalances are approximately 4.04e-11 and 4.77e-11; relative inlet waveform errors are 2.89e-7 and 5.78e-7. See `reports/saved_field_validation.json` within the new baseline.

Native wallShearStress postprocessing initially encounters the known SHA1 stream compatibility error. The existing project's compatibility shim, compiled locally and loaded only for postprocessing, permits successful execution. Native stress dimensions `[0 2 -2 0 0 0 0]` are checked and multiplied once by rho = 1060 kg/m3 to obtain Pa. Initial mean WSS is approximately 1.266 and 1.250 Pa; instantaneous maxima are approximately 88.56 and 72.56 Pa. These startup values are **not** converged-cycle or patient-specific WSS predictions.

ParaView files:

- `runs/runtime_repair_20261017_01/cfd/aorta/aorta.foam`: actual mesh and saved transient fields. Native wallShearStress remains kinematic.
- `runs/runtime_repair_20261017_01/results/diagnostic_wall_WSS_Pa.pvd`: two saved wall snapshots with an explicitly named `WSS_Pa` array.

Video:

`runs/runtime_repair_20261017_01/results/initial_transient_video_software/Initial_Transient_DIAGNOSTIC_720p.mp4`

This real 5-second, 1280×720, 15 fps video renders computed streamlines and WSS at the two saved times, with an orbiting camera and discrete time phases. It is prominently labelled as an initial-transient diagnostic. It does not represent five seconds of simulated evolution, moving blood particles, a converged cycle, or the requested final 1080p video. FFprobe confirms 75 frames and 5 seconds; a full FFmpeg decode passes. Preview image was visually inspected. The failed X/OpenGL rendering attempt and its logs remain preserved; the successful diagnostic uses CPU rasterization. The pre-existing final particle renderer already uses Pillow and does not require OpenGL.

## Diagnostic execution and remaining work

The baseline watchdog targets 0.01 s, stops timestep collapse below 1e-8 s, and retains its original 45-minute wall-time limit. The diagnostic maximum Courant number was changed from 0.25 to the original full run's 0.7 after initial convergence. Early outputs at 0.0001 and 0.0002 were added for validation, followed by 0.001-s output checkpoints. Changes are recorded in `reports/diagnostic_adjustments.json` in the new baseline. No old results are purged.

A separate case, `runs/corrector_test_20261017_01`, restarts from the validated 0.0002-s field to test one outer corrector and one nonorthogonal corrector, instead of two of each. It uses identical mesh bytes, unchanged pressure/velocity linear tolerances, maxCo 0.7, and the same watchdog. This is an unaccepted performance experiment. Shared saved fields must be compared before accepting it; `src/compare_correctors.py` requires velocity and WSS relative L2 differences below 1% at a common checkpoint. A startup comparison alone would not establish full-cycle accuracy.

Measured initial serial baseline cost is about 20–30 wall seconds per timestep, with timesteps of tens of microseconds. A full 30-s run cannot be claimed from these startup diagnostics. The 0.01-s test, saved-field validation, full 30-s evolution, final-cycle conservation and cycle-change gates, final WSS, particle video and final export remain required.

MPI preflight fails because the sandbox denies socket creation (`errno=1`); PMIx cannot start its listener. No workaround or command relay has been attempted. This is a runtime permission restriction, not a CFD validation failure. The current tools do not permit requesting a sandbox override.

`runs/runtime_repair_20261017_01/continue_parallel.sh` is a prepared pipeline for a normally permitted local MPI environment. It passes shell syntax checks; its actual MPI preflight fails here before any case is created. The entire pipeline is **not execution-validated**. It uses the corrected initial field and baseline corrector counts, creates a fresh Linux work directory, checks storage for retaining all new times, runs strict mesh and 0.01-s gates, retains watchdogs, solves to 30 s, reconstructs final fields, checks mass balance <0.5%, inlet error <1%, cycle WSS change <5%, renders the actual original 1080p/30fps/4,000-tracer video and decodes it, and exports a new Desktop case only after all gates pass. All intermediate times remain on the Linux work disk. Nothing deletes or overwrites old cases. About 60 GiB of free Linux work space and roughly 5 GiB free Desktop space are conservatively allowed; the Desktop currently has only about 8 GiB free.

Scientific limits remain unchanged: inferred CT alignment and substantial geometry repair; rigid wall; laminar Newtonian flow; synthetic 50 + 35 sin(2 pi t) mL/s inlet; two zero-pressure outlets; no mesh-convergence or clinical accuracy claim.

## Reference comparison update

At 0.0012 s, the reduced-corrector case differs from the reference by 0.02225% in volume-weighted velocity L2 and 0.16567% in area-weighted WSS L2, both below the predefined 1% checkpoint thresholds. Maximum pointwise cell-velocity difference is 0.007781 m/s. This supports using it for continued startup stability diagnostics only. It does not establish full-cycle or temporal convergence. The reference branch was deliberately given `stopAt writeNow` after this comparison; its watchdog will correctly report that it did not reach 0.01 s. The separate reduced-corrector case continues to the original 0.01-s target and 45-minute budget. The prepared full parallel pipeline still uses the baseline two-outer/two-nonorthogonal settings and explicitly restores `stopAt endTime` in its fresh case. It bridges from 0.01 to 0.05 s before restarting the full stage, to align its later 0.05-s writes exactly to 28–30 s.
