# Project cleanup record — 19 October 2026

## Preservation and latest result

A full pre-cleanup archive was created and verified before any removal: `backups/aortic_repaired_simulation_untouched_20261019.tar`. Its SHA-256 is in the adjacent checksum file and its snapshot/restore instructions are in `backups/README.md`.

The newest verified solver result is the 3.0 s exploratory transient in `runs/runtime_optimization_20261018_01/reports/FINAL_STATUS.json`; the final 1080p side-by-side video and validation are in `deliverables/Aortic_Exploratory_SideBySide_20261018_01/`. The phase-resolved periodicity test failed at WSS relative L2 8.8623% versus the unchanged 5% threshold. This status is not described as periodic or mesh-accurate.

## Removals

`CLEANUP_MANIFEST_20261019.json` records every removed path, byte count and SHA-256, plus per-file comparison evidence for the duplicate mesh case. The older `cfd/tetra_caps_20261017_004447_4970` was removed because 25 of its 27 files exactly matched the newer `cfd/tetra_caps_20261017_005319_4992`. Its two different logs and all removed content remain in the untouched backup. The newer case is retained. Other removals were superseded `.before_fix` copies, one byte-identical copied serial status file, one byte-identical saved-field report, generated Python bytecode, a zero-byte unreferenced `selfInterPoints.obj`, an empty render log, an earlier superseded side-by-side review encode, and empty log directories. No CT/mask, repaired geometry, latest validated solver result, restart checkpoint or unique validation record was deleted.

Lock files used by controller scripts are retained. Historical handoffs and incomplete/failed cases remain, but README.md points to the current status to avoid reading old continuation notes as active jobs.

## GitHub publish status

The latest run itself remains separately in `/tmp/aortic_exploratory_demo_20261018_01`; a temporary compressed copy was validated against that directory, then removed to avoid retaining a redundant second copy. The source copy was untouched. A local publishing layout and ignore rules are prepared. The linked GitHub app profile can inspect repositories, but its exposed tools cannot create a repository, push Git objects or upload LFS/release assets; the `gh` CLI is absent. The only listed accessible repository is an unrelated public project, so it was not modified. No repository URL exists yet and no project files were uploaded.
