> Historical handoff; superseded by the completed 3.0 s transient result in `runs/runtime_optimization_20261018_01/reports/FINAL_STATUS.json`. No solver/controller is active. Do not treat the old target or session details below as current.

# Startup-stage report

Reported: 2026-10-17T22:58:14.787994+00:00

**STARTUP_VALIDATED**. No additional solver was launched.

Completed startup simulated time: 0.01 s; target: 0.01 s.

Solver elapsed wall runtime: 3643.5274996129956 seconds (1.012 hours).

Pipeline launch through startup validation: 3670.4 seconds.

Mesh gate: PASS; independent initialization gate: INDEPENDENT_INITIAL_FLOW_CHECK_PASS; saved-field/WSS gate: PASS; complete validated snapshots: 5.

Worst relative flow imbalance: 2.7121324e-10 (limit 0.005).

Worst relative inlet-waveform error: 1.0826239e-05 (limit 0.01).

Maximum saved velocity magnitude: 0.60910267 m/s (limit 10).

WSS dimensions were checked and converted once by density 1060 kg/m3 to Pa.

Remaining solve to 30 s at the whole-startup average rate: 126.47 days.

Remaining solve at the recent completed-step rate: 99.97 days.

Linear runtime projections at measured startup rates, not a reliable ETA. Future adaptive timesteps and flow speeds can change the rate substantially. WSS analysis, video rendering and export time are excluded.

Pipeline stage at report: bridge to globally aligned output phase; state: RUNNING. The previously authorized pipeline continues automatically unless a required check fails. No stop or restart was requested.

The full 30-s simulation, periodic-cycle validation and final 1080p particle/ParaView exports are not established by this startup report.

Continuation instructions: `/mnt/c/Users/Admin/Desktop/Aortic_Repaired_Simulation_20261015/reports/STARTUP_CONTINUATION_20261018.md`.

Detailed numerical results: `/mnt/c/Users/Admin/Desktop/Aortic_Repaired_Simulation_20261015/reports/STARTUP_STAGE_REPORT_20261018.json`.

Failure log tail, if any: none reported.
