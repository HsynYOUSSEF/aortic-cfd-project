# CT direction correction and geometric gap repair, version 2

The final outputs are a new CT with an inferred slice-direction correction, a repaired research mask, and its smooth surface. Original CT, mask, green candidate and all earlier CFD results were preserved. No new CFD simulation was run.

## Files to use

- `CT_z_direction_corrected_RESEARCH.nii.gz`: full CT with corrected z direction in both qform and sform. Raw voxel data and intensity scaling are unchanged.
- `REPAIRED_AND_CHANGES.seg.nrrd`: Slicer segmentation containing the repaired geometry, original green reference, added regions and removed regions.
- `GREEN_REPAIRED_RESEARCH.nrrd`: final repaired binary mask.
- `REPAIRED_surface_Slicer.vtp`: final smooth surface saved with Slicer's coordinate-system metadata; use this model file in Slicer.
- `REPAIRED_surface_RAS_mm.vtp`: final smooth surface in explicit RAS millimetres for geometry processing. Generic VTP does not guarantee a coordinate-system tag; do not rely on an application's default LPS interpretation when importing this raw file.
- `REPAIRED_surface_RAS_mm.stl`: same surface; STL does not encode units.
- `repair_comparison.png`: CT-only, original, repaired and change-map comparisons.
- `repair_audit.json`: quantitative changes, methods and final topology checks.
- `alignment_provenance.json`: exact metadata changes and voxel preservation checks.

Other arrays and audit files are intermediate trials. In particular, the 7.2% volume-increase trial was rejected because it removed a lower channel. The final mask and final surface files listed above contain the later channel-preserving result.

## CT correction

The source CT and mask have identical dimensions and spacing. Their z origins differ by approximately 651 mm, equal to the full 1085-interval slice span within floating-point precision. The original CT describes increasing z, although reversing its slice mapping produces much better correspondence with the supplied mask. The derived CT changes the z direction from +0.6000000238 to -0.6000000238 mm per slice, retains its original origin, updates qfac consistently, and marks both coordinate forms as derived aligned coordinates.

The resulting physical z extent is approximately -647.638 to +3.362 mm, matching the mask extent to about 0.000026 mm. CT index K corresponds to mask index 1085-K. No image resampling or interpolation was performed. SHA256 of the complete uncompressed voxel payload matches the source exactly.

The saved direction correction is a reproducible, image-supported research correction. It is not independent confirmation of the original acquisition orientation; original DICOM metadata or provider confirmation remain unavailable. The separately saved intensity comparison supports the reversed mapping but is not an anatomical accuracy score.

## Gap repair and retained channels

The source green mask was not changed. Local closing, enclosed-hole filling and signed-distance smoothing were applied to a copy. The final reconstruction preserves the two meaningful lower channels in all 26 terminal slices after the smoothed separation point. Their major source components retain at least 84.7% of their pixels. The separation begins one 0.6 mm slice below the source's persistent two-component separation. Branch identity has not been assigned.

The final repair increases volume from 112.196 to 127.914 mL: **14.01% net**. This comprises **17.26% added** and **3.25% removed**, relative to the original extended green mask. The total changed region is 20.51%; the net figure alone understates the edit. Changes are available as separate added/removed masks and segments.

The final smooth surface has:

- One connected surface.
- Zero boundary edges.
- Zero non-manifold edges.
- Euler characteristic 2 and genus 0: no detected surface handles/tunnels.
- 137,336 triangles.
- Two meaningful terminal cross-section components preserved.

Surface display smoothing moves vertices by at most 0.161 mm relative to the repaired voxel surface. Mask edits are larger: bidirectional boundary distances reach 10.45 mm, and the original-to-repaired 95th percentile is 5.49 mm. These distances include the many internal boundaries being removed and possible small-feature changes; they must not be interpreted as registration error or anatomical accuracy.

## Limits before a flow solve

This is a computational repair of the supplied threshold candidate, not an expert-validated blood lumen. The intensity thresholds, outer AI mask, local repair assumptions, small-branch preservation and true tissue boundaries still limit anatomical accuracy. The repair removes numerical porosity but does not prove that every added voxel is blood.

Self-intersections, inlet/outlet cap construction, outlet-region assignment and volume mesh quality remain to be tested. The source crop ends are not final CFD boundary caps. A new case must recognize the lower channel geometry and must not reuse a single-outlet assumption without checking it. The current session's last Ubuntu check returned `Wsl/E_ACCESSDENIED`; no mesh or solver run was performed.

## Preservation

Original source CT SHA256: `a678305ded7a2d60faf28211d73b9fc34f836e0cedf322e9ef966d5fda1cf4c7`.

Original source mask SHA256: `22710cf5e959497cac698a8015b2c04075773ea67c8293d3b291eacc5a920a07`.

Original green-candidate segmentation SHA256: `05d0b12b1f26edeced30e86542b73659bdffadcb547effdfa1655b0f7fcbb4cc`.

All three remain unchanged. Only files under this chat's workspace outputs/work folders were written. Existing `C:\dev\aortic_project\cfd` and `results` cases were not modified.
