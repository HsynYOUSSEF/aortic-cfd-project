param([switch]$Resume, [string]$Distribution = 'Ubuntu-24.04')
$ErrorActionPreference = 'Stop'

$linuxRoot = & wsl.exe -d $distribution --exec wslpath -a ($PSScriptRoot.Replace('\', '/'))
if ($LASTEXITCODE -ne 0) { throw 'WSL path conversion failed. Review the error printed above.' }
$linuxRoot = ($linuxRoot | Select-Object -Last 1).Trim()
if ($Resume) {
    & wsl.exe -d $distribution -- bash "$linuxRoot/run_all.sh" '--resume'
} else {
    & wsl.exe -d $distribution -- bash "$linuxRoot/run_all.sh"
}
if ($LASTEXITCODE -ne 0) { throw "Simulation stopped. Inspect the newest folder under $PSScriptRoot\logs. Old project results are preserved." }
Write-Host "Finished. Results are under $PSScriptRoot\results"
