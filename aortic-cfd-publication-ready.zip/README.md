# Aortic repaired-surface CFD project

This project contains the source CT and segmentation, a research repair of the aortic lumen, mesh and solver experiments, validation records, and a completed exploratory CFD demonstration.

## Latest verified result

The latest completed solver run reached **3.0 simulated seconds** on a 128,472-cell coarse uniform staircase mesh. Saved-field checks passed for 200 states from 1.01 to 3.00 s, with maximum relative flow imbalance 2.37e-10 and inlet-waveform error 3.28e-8. Successive-cycle periodicity **failed**: phase-resolved WSS differed by 8.86% against an unchanged 5% gate (velocity 4.28%, pressure 3.65%). The result is transient. Mesh accuracy and WSS accuracy are not established.

The final side-by-side video is [`deliverables/Aortic_Exploratory_SideBySide_20261018_01/Aortic_Exploratory_SideBySide_1080p.mp4`](deliverables/Aortic_Exploratory_SideBySide_20261018_01/Aortic_Exploratory_SideBySide_1080p.mp4). It shows the 300 saved states at 0.01 s cadence once, at 10× slowed playback, without cycle replay or unsaved-field interpolation. Its right panel is labelled as unvalidated coarse-mesh WSS. Details and representative frames are in that folder's README and render report.

The complete computed case, logs, actual WSS fields, and ParaView files remain in the existing WSL work directory `/tmp/aortic_exploratory_demo_20261018_01`; its inventory is in [`large_assets/README.md`](large_assets/README.md). Large assets are excluded from ordinary Git history. Older runs, failed candidates, and their validation evidence remain available as history.

## Project map

- `data/original/` — original public CT/mask and provenance/attribution.
- `data/repaired/` — derived orientation-corrected CT and repair masks.
- `geometry/` — repaired surfaces in RAS mm, Slicer format, and SI CFD form.
- `cfd/` — prepared and experimental mesh cases; mesh candidates are not automatically verified CFD results.
- `runs/` — dated experiments, scripts, logs, and validation reports.
- `reports/` — project-wide preparation, verification, and cleanup records.
- `deliverables/` — final video and evidence.
- `large_assets/` — inventory of the existing external latest simulation fields and ParaView outputs; excluded from ordinary Git history.
- `backups/` — untouched pre-cleanup snapshot, excluded from Git.

## Start here

Read [`REPRODUCING.md`](REPRODUCING.md) for the exact run and rendering sequence and assumptions, [`REFERENCES.md`](REFERENCES.md) for data/software attribution, and [`reports/CLEANUP_MANIFEST_20261019.json`](reports/CLEANUP_MANIFEST_20261019.json) for removals. The authoritative machine-readable status is [`runs/runtime_optimization_20261018_01/reports/FINAL_STATUS.json`](runs/runtime_optimization_20261018_01/reports/FINAL_STATUS.json). Historical startup and 30-second pipeline handoffs are retained but superseded by that report.

## Scientific limits

The CT orientation was inferred without original DICOM. The repair adds 17.26% and removes 3.25% of source-mask voxels (14.01% net increase; 20.51% changed). The synthetic model assumes rigid walls, laminar Newtonian flow, density 1060 kg/m³, dynamic viscosity 0.0035 Pa·s, a one-second sinusoidal inflow, and two independent zero-gauge-pressure outlets; the outlet split is solved. The coarse/fine startup differences were 26.4% in velocity, 7.9% in pressure and 68.5% in mapped WSS. The result is an exploratory numerical demonstration, not patient-specific or clinically validated CFD.

Dataset attribution is required. The local dataset README and Zenodo API metadata record disagree on license terms; see [`REFERENCES.md`](REFERENCES.md) and `data/original/ATTRIBUTION.md`. The publisher’s live README explicitly states CC BY 4.0; this public distribution follows that attribution license. See the dated update in REFERENCES.md.


## Public upload contents — 21 October 2026

The latest video, four repaired model representations, Slicer segmentation with repair changes, component masks, retained code, and validation/reproduction documentation are published here. See [UPLOAD_STATUS.md](UPLOAD_STATUS.md) and [PUBLICATION_MANIFEST.json](PUBLICATION_MANIFEST.json). Backups, environments, caches, raw CT volumes, complete CFD time folders and large field exports remain local. Source-workspace paths in historical reports describe local artifacts and are not hosted download links. Full-field rendering/restart requires those local fields; the original repair generator was not retained.
