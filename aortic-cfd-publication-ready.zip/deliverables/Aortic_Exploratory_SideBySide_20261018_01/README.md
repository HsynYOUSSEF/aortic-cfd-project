# Side-by-side exploratory CFD video

- Video: `Aortic_Exploratory_SideBySide_1080p.mp4` (1920×1080, H.264, 300 computed frames, 29.91 s playback).
- Simulation snapshots: 0.01 s through 3.00 s at 0.01 s cadence. Frames use the fields saved at that same time. No cycle replay or unsaved-field interpolation. Particle positions advance between snapshots using the current saved velocity over 0.01 s.
- Playback is 10× slowed over the displayed simulation interval.
- Left: flow/particles, particle color denotes speed in m/s. Right: instantaneous wall shear stress with the exact in-video label “Wall shear stress — unvalidated coarse-mesh results”.
- The WSS field's OpenFOAM dimensions are `[0 2 -2 0 0 0 0]` (kinematic shear, m²/s²). Density 1060 kg/m³ was applied once to obtain Pa. The fixed scale is 0–11.9 Pa (global observed maximum 11.8402 Pa); ticks are 0, 5.95, and 11.9 Pa.
- Both panels use the same orthographic camera basis and scale. The shared simulation-time label follows the saved-state time.
- The run is transient: successive-cycle phase-resolved validation did not pass. Coarse-mesh WSS is not validated and mesh accuracy is not claimed.
- Existing single-panel video and all simulation results remain preserved.
- Validation: FFprobe reports 1920×1080, 300 frames, nominal 10 fps and 29.91 s; full FFmpeg decode completed successfully. Representative first, middle, and final frames are included as JPEG previews.
- Storage at completion: project tracked aggregate including bounded tests and this deliverable folder was about 3.68 GB (3.43 GiB), below the 5 GiB cap. Windows C: had 9,083,133,952 bytes free at final check.
- Detailed machine-readable render evidence: `render_report.json`. Rendering source: `runs/runtime_optimization_20261018_01/src/render_side_by_side.py`.
