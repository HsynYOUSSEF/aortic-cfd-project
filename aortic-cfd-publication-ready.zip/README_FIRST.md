> Historical handoff written 15 October 2026. Its “not generated” and 30-second pipeline status was superseded by the completed 3-second exploratory run on 18 October. See [README.md](README.md) and [REPRODUCING.md](REPRODUCING.md) for current results and steps. This file is retained in the untouched pre-cleanup backup for history.

# Repaired aorta research simulation package

Prepared on 15 October 2026. The repaired surface passed the recorded geometry checks. **The new volume mesh, flow solution, WSS results and video have not been generated.** Ubuntu returned Wsl/E_ACCESSDENIED in the preparation session. An empty aorta.foam marker does not mean solved fields exist.

## What is included

- data/original: original CT and mask, with dataset attribution and provenance.
- data/repaired: inferred CT direction correction, repaired green mask, original green reference, and masks showing every added and removed region.
- geometry: surfaces in RAS millimetres, a Slicer-compatible surface, and the clipped CFD surface in metres.
- cfd/repaired_run_01: a fresh prepared OpenFOAM case with one inlet and two distinct lower outlets.
- reports: alignment, repair, surface checks, a comparison image, and execution status.
- src: preparation, validation, analysis and rendering programs. INPUT_SHA256.json protects prepared inputs.

Old cases and videos in C:/dev/aortic_project were not modified. They remain there and are not duplicated in this package. New outputs stay inside this folder.

## Put this folder on your Desktop and run

Extract the supplied ZIP to your Desktop. Open PowerShell and run:

```powershell
powershell -ExecutionPolicy Bypass -File "$([Environment]::GetFolderPath('Desktop'))\Aortic_Repaired_Simulation_20261015\Run-Simulation.ps1"
```

The launcher uses Ubuntu-24.04. If your distribution has a different name, check `wsl --list --verbose` and add `-Distribution 'YourDistributionName'` to the PowerShell command.

If dependencies are missing, open Ubuntu and install them yourself:

```bash
sudo apt update
sudo apt install openfoam python3-venv python3-pip ffmpeg g++
```

The scripts target the existing OpenFOAM 1912 toolchain. A different OpenFOAM distribution/version may require dictionary changes. The launcher records logs and stops when a command or mesh gate fails. It installs Python packages in a local environment if the existing aortic-cfd environment is unsuitable.

To deliberately continue an interrupted run in this same package, add `-Resume` to the PowerShell command. Do not run two copies concurrently. Keep the prepared inputs unchanged; integrity verification intentionally stops if they change. Each invocation has a separate log folder and video output folder. Analysis files for this new case are refreshed on resume.

## What the run will do

1. Verify input hashes and check the surface.
2. Generate a volume mesh and require checkMesh to report Mesh OK, with all four boundary patches populated.
3. Solve a synthetic pulsatile flow to 30 seconds, saving every 0.05 seconds without purging earlier output.
4. Calculate wall shear stress for seconds 28–30 and export final-cycle WSS, TAWSS, OSI, RRT and flow-balance summaries. Kinematic WSS is multiplied by density once to obtain Pa.
5. Render a 30-second, 1080p, 30 fps particle/WSS video with 4,000 tracers. This slowed visualization repeats the last one-second simulated cycle; it is not 30 seconds of unique simulation history. Particles move through the computed velocity field.

Read reports/LAST_RUN_STATUS.txt and the newest logs/run_* folder for actual completion status. After solving, results/repaired_run_01/summary.json records conservation and cycle-change checks; inspect these even if all commands finish. Mesh independence is not established by one mesh check. Open cfd/repaired_run_01/aorta.foam in ParaView after the mesh and solution exist.

## Review the CT and repaired mask in Slicer

Load data/repaired/CT_z_direction_corrected_RESEARCH.nii.gz as a volume and data/repaired/REPAIRED_AND_CHANGES.seg.nrrd as a segmentation. Toggle the repaired, original, added and removed segments while scrolling all three slice views. Use geometry/REPAIRED_surface_Slicer.vtp for the standalone Slicer model; untagged RAS surface files may otherwise be interpreted as LPS.

## Scientific limits

The CT direction correction is inferred from the saved image geometry and slice correspondence; original DICOM orientation was unavailable. CT voxel values were preserved. This is not independent anatomical validation.

Repair added 17.26% and removed 3.25% of the original green-mask voxel count: net volume increase 14.01%, with 20.51% changed in total. Both substantial lower channels were retained. These changes are too large to equate a watertight surface with a verified blood-lumen boundary. See the change masks before interpreting results.

The new model assumes rigid walls, laminar Newtonian flow, density 1060 kg/m3, viscosity 0.0035 Pa s, a synthetic one-second inflow of 50 + 35 sin(2 pi t) mL/s, and zero gauge pressure at both lower outlets. Other closed branch stubs are treated as wall. The two outlets' anatomical identities are unconfirmed. No patient-specific outlet resistance or measured inflow is available. This is exploratory CFD, not a clinically validated stress prediction.
