> NOT UPLOADED: both GitHub blob and contents endpoints returned HTTP 403, Resource not accessible by integration, on 21 October 2026. The files below are a prepared publication candidate; no repository changes succeeded.

# Public publication — 21 October 2026

Requested public repository: HsynYOUSSEF/aortic-cfd-project. This publication supersedes the 19 October hold following the current owner request and verification that the dataset publisher explicitly states CC BY 4.0. Attribution and modified-data disclosures are retained in REFERENCES.md and data/original/ATTRIBUTION.md.

Included: latest side-by-side MP4 and previews; repaired STL and VTP models; combined Slicer segmentation and component masks; retained code/scripts/configuration; reproduction notes and compact validation reports. No raw CT volumes, full CFD time directories/fields, backups, caches, environments, or archived runs are included. All source files remain untouched locally.

Prepublication checks: full video decode and ffprobe (1920x1080, 300 frames, 29.91 s); visual preview inspection; binary STL structure (137336 triangles); combined NRRD header and gzip payload (569376768 decompressed bytes); Python syntax parsing; scan for common credential signatures. These checks do not establish anatomical or clinical validity. Periodicity failed at 8.86% WSS cycle change against the 5% gate; mesh accuracy remains unestablished.

PUBLICATION_MANIFEST.json records byte sizes, SHA-256 and Git blob identities. Historical INPUT_SHA256 manifests include local-only assets; use PUBLICATION_MANIFEST.json for this uploaded subset. The full repair generator is missing from the source workspace.
