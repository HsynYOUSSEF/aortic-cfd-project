from pathlib import Path
import sys,subprocess,time,re,json,math
def latest(text,label):
 values=re.findall(r'^'+label+r'\s*=\s*([^\s]+)',text,re.M)
 return float(values[-1]) if values else None
def problem(text,target=.01):
 t=latest(text,'Time');dt=latest(text,'deltaT')
 if 'FOAM FATAL' in text or re.search(r'\b(?:nan|inf)\b',text,re.I):return 'Non-finite result or OpenFOAM fatal error'
 if dt is not None and (not math.isfinite(dt) or dt<=0):return 'Invalid timestep'
 if dt is not None and dt<1e-8 and (t is None or t<target-1e-10):return 'Timestep collapsed below 1e-8 seconds'
 return None
def main():
 root=Path(sys.argv[1]);log=root/'logs/solver.log';start=time.monotonic();progress=start;printed=0;last_time=None;failure=None
 with log.open('w') as stream:
  p=subprocess.Popen(['pimpleFoam','-case',str(root/'cfd/aorta'),'-noFunctionObjects'],stdout=stream,stderr=subprocess.STDOUT)
  try:
   while p.poll() is None:
    time.sleep(2)
    with log.open('rb') as f:f.seek(max(0,log.stat().st_size-65536));text=f.read().decode(errors='replace')
    t=latest(text,'Time');dt=latest(text,'deltaT');now=time.monotonic()
    if t is not None and (last_time is None or t>last_time+1e-12):progress=now;last_time=t
    if now-printed>=30:print(f'Elapsed {(now-start)/60:.1f} min | simulated time {t} / 0.01 s | timestep {dt}',flush=True);printed=now
    failure=problem(text)
    if now-progress>360:failure='No meaningful simulated-time progress for six minutes'
    if now-start>2700:failure='45-minute diagnostic budget reached; inspect performance before a full run'
    if failure:break
  finally:
   if p.poll() is None:
    p.terminate()
    try:p.wait(timeout=10)
    except subprocess.TimeoutExpired:p.kill();p.wait()
 text=log.read_text(errors='replace');t=latest(text,'Time')
 passed=p.returncode==0 and not failure and t is not None and abs(t-.01)<1e-9 and re.search(r'^End\s*$',text,re.M) is not None
 result={'status':'SHORT_TEST_FINISHED' if passed else 'STOPPED','reason':failure,'returncode':p.returncode,'simulated_time':t,'elapsed_seconds':time.monotonic()-start,'interpretation':'Finishing this short test does not establish full-cycle stability, accuracy or a completed 30-second simulation.'}
 (root/'reports/stability_result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2),flush=True)
 if not passed:print('\n'.join(text.splitlines()[-25:]),flush=True);raise SystemExit(1)
if __name__=='__main__':main()
