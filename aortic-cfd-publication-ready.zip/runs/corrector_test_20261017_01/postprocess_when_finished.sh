#!/usr/bin/env bash
set -euo pipefail
PROJECT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)"
ROOT="$PROJECT/runs/corrector_test_20261017_01"
SOURCE="$PROJECT/runs/runtime_repair_20261017_01"
PY=/home/admin007/.venvs/aortic-cfd/bin/python
export WM_PROJECT_DIR=/usr/share/openfoam FOAM_ETC=/usr/share/openfoam/etc OPENBLAS_NUM_THREADS=1
python3 - "$ROOT" <<'PYWAIT'
from pathlib import Path
import sys,time,json
root=Path(sys.argv[1]);p=root/'reports/stability_result.json'
for i in range(1000):
 if p.exists():
  try:s=json.loads(p.read_text())
  except json.JSONDecodeError:time.sleep(2);continue
  assert s['status']=='SHORT_TEST_FINISHED',s
  assert (root/'cfd/aorta/0.01/U').is_file(),'Target field not saved'
  break
 time.sleep(2)
else:raise SystemExit('Timed out waiting for bounded stability test')
PYWAIT
LD_PRELOAD="$SOURCE/src/libsha1_compat.so" pimpleFoam -case "$ROOT/cfd/aorta" -postProcess -func wallShearStress -time '0.0016:0.01' > "$ROOT/logs/WSS_final_short.log" 2>&1
"$PY" "$SOURCE/src/validate_saved_fields.py" "$ROOT" --require-end .01 --minimum-times 9 > "$ROOT/logs/validate_final_short.log" 2>&1
"$PY" "$SOURCE/src/export_wall_series.py" "$ROOT" > "$ROOT/logs/export_wall_series.log" 2>&1
"$PY" "$SOURCE/src/render_diagnostic_software.py" "$ROOT" > "$ROOT/logs/render_software.log" 2>&1
ffmpeg -v error -i "$ROOT/results/initial_transient_video_software/Initial_Transient_DIAGNOSTIC_720p.mp4" -f null - > "$ROOT/logs/video_decode_check.log" 2>&1
printf '%s\n' 'INITIAL TRANSIENT ONLY: reached 0.01 s, saved fields and WSS checked, diagnostic video decoded, ParaView wall series read back. Full-cycle simulation and periodic validation remain incomplete.' > "$ROOT/reports/DIAGNOSTICS_COMPLETE.txt"
