#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
CASE="$ROOT/cfd/aorta"
STAMP="$(date +%Y%m%d_%H%M%S)_$$"
mkdir -p logs results reports
LOGS="$ROOT/logs/$STAMP"
mkdir "$LOGS"
exec > >(tee "$LOGS/run.log") 2>&1
STAGE=environment
trap 'code=$?; if (( code != 0 )); then printf "FAILED at %s; exit=%s; logs=%s\n" "$STAGE" "$code" "$LOGS"; fi' EXIT
exec 9>"$ROOT/.run.lock"
flock -n 9 || { echo 'This new case is already running.'; exit 2; }
export WM_PROJECT_DIR="${WM_PROJECT_DIR:-/usr/share/openfoam}"
export FOAM_ETC="${FOAM_ETC:-$WM_PROJECT_DIR/etc}"
for tool in checkMesh pimpleFoam ffmpeg ffprobe python3; do
  command -v "$tool" >/dev/null || { echo "Missing dependency: $tool"; exit 3; }
done
PY="${PYTHON_CFD:-$HOME/.venvs/aortic-cfd/bin/python}"
if [[ ! -x "$PY" ]]; then PY=python3; fi
if ! "$PY" -c 'import numpy, scipy, vtk, PIL; assert hasattr(numpy,"trapezoid")'; then
  python3 -m venv "$ROOT/.venv"
  PY="$ROOT/.venv/bin/python"
  "$PY" -m pip install -r requirements.txt
fi
STAGE='input integrity'
"$PY" - <<'PY'
from pathlib import Path
import json,hashlib
items=json.loads(Path('INPUT_SHA256.json').read_text())
for name,digest in items.items():
 assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,'Input changed: '+name
print('PASS: new case inputs match saved hashes.')
assert json.loads(Path('reports/local_quality.json').read_text())['local_pass']
PY
STAGE='native mesh validation'
echo 'Running full OpenFOAM mesh checks on the repaired candidate.'
checkMesh -case "$CASE" -allTopology -allGeometry > "$LOGS/checkMesh.log" 2>&1 || { tail -70 "$LOGS/checkMesh.log"; exit 1; }
tail -55 "$LOGS/checkMesh.log"
"$PY" src/check_mesh_gate.py "$LOGS/checkMesh.log"
STAGE='storage check'
"$PY" - <<'PY'
from pathlib import Path
import json,shutil
n=json.loads(Path('reports/local_quality.json').read_text())['cells']
required=n*64*41+2*1024**3
free=shutil.disk_usage('.').free
print(f'Free space: {free/1024**3:.2f} GiB; conservative allowance: {required/1024**3:.2f} GiB.')
assert free>=required,'Insufficient free space. Mesh passed; solver has not started.'
print('New case only: solve to 30 s, retain the final 41 saved times (28–30 s). Old cases are untouched.')
PY
if [[ ! -f "$ROOT/reports/SOLVER_COMPLETE" ]]; then
  STAGE='flow solver'
  echo 'Solving to 30 seconds. Progress is printed approximately every 30 seconds.'
  pimpleFoam -case "$CASE" -noFunctionObjects > "$LOGS/solver.log" 2>&1 &
  SOLVER_PID=$!
  trap 'kill "$SOLVER_PID" 2>/dev/null || true; exit 130' INT TERM
  while kill -0 "$SOLVER_PID" 2>/dev/null; do
    grep '^Time = ' "$LOGS/solver.log" | tail -1 || true
    sleep 30
  done
  wait "$SOLVER_PID" || { tail -60 "$LOGS/solver.log"; exit 1; }
  trap - INT TERM
  grep -q '^End' "$LOGS/solver.log"
  "$PY" - <<'PY'
from pathlib import Path
import re
times=[float(p.name) for p in Path('cfd/aorta').iterdir() if p.is_dir() and re.fullmatch(r'\d+(?:\.\d+)?',p.name) and (p/'U').is_file() and (p/'p').is_file()]
assert abs(max(times)-30)<1e-7,'Solver did not reach 30 seconds'
Path('reports/SOLVER_COMPLETE').write_text('Reached 30 seconds. WSS and rendering still require completion.\n')
PY
fi
STAGE='wall shear stress'
if ! pimpleFoam -case "$CASE" -postProcess -func wallShearStress -time '28:30' > "$LOGS/WSS.log" 2>&1; then
  if grep -qi 'sha1' "$LOGS/WSS.log"; then
    g++ -shared -fPIC -o "$LOGS/libsha1_compat.so" src/sha1_compat.cpp
    LD_PRELOAD="$LOGS/libsha1_compat.so${LD_PRELOAD:+:$LD_PRELOAD}" pimpleFoam -case "$CASE" -postProcess -func wallShearStress -time '28:30' > "$LOGS/WSS_retry.log" 2>&1
  else
    tail -60 "$LOGS/WSS.log"
    exit 1
  fi
fi
STAGE='flow and WSS analysis'
"$PY" src/analyze_results.py | tee "$LOGS/analysis.log"
"$PY" - <<'PY'
from pathlib import Path
import json
s=json.loads(Path('results/aorta/summary.json').read_text())
assert s['conservation_under_0_5_percent'],'Mass-balance gate failed; inspect summary.json'
assert s['cycle_change_under_5_percent'],'Final cycles differ by more than 5%; inspect summary.json'
assert s['max_relative_inlet_waveform_error']<.01,'Inlet waveform mismatch'
PY
STAGE='1080p particle and WSS video'
VIDEO="$ROOT/results/video_$STAMP"
"$PY" src/render_flow_wss.py --project "$ROOT" --case aorta --end 30 --seconds 30 --fps 30 --slowdown 8 --particles 4000 --output "$VIDEO" > "$LOGS/render.log" 2>&1 || { tail -60 "$LOGS/render.log"; exit 1; }
printf 'COMPLETE\nParaView: %s/aorta.foam\nVideo: %s/Aortic_Flow_And_Instantaneous_WSS_1080p.mp4\n' "$CASE" "$VIDEO" | tee "$ROOT/reports/COMPLETE.txt"
