$ErrorActionPreference = 'Stop'
$linux = '/mnt/c/' + $PSScriptRoot.Substring(3).Replace('\','/') + '/run.sh'
wsl.exe -d Ubuntu-24.04 --exec bash $linux
if ($LASTEXITCODE -ne 0) { throw 'Stopped. Read the latest logs folder in this new run.' }
