"""Render moving tracers from a saved OpenFOAM cycle, without frame blending.

Example (Ubuntu, package root): python src/render_flow_wss.py --project . --case repaired_run_01 --end 30
Uses existing NumPy, VTK, Pillow and FFmpeg; does not modify the CFD case.
"""
from pathlib import Path
import argparse
import json
import subprocess
import shutil
import re
import numpy as np
import vtk
from vtk.util.numpy_support import vtk_to_numpy, numpy_to_vtk
from PIL import Image, ImageDraw, ImageFont


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--project', type=Path, required=True)
    ap.add_argument('--case', default='repaired_run_01')
    ap.add_argument('--end', type=float, default=30.)
    ap.add_argument('--seconds', type=int, default=40)
    ap.add_argument('--fps', type=int, default=30)
    ap.add_argument('--slowdown', type=float, default=8)
    ap.add_argument('--particles', type=int, default=6000)
    ap.add_argument('--output', type=Path, help='New output directory; must not already exist.')
    a = ap.parse_args()
    if min(a.seconds, a.fps, a.slowdown, a.particles) <= 0:
        ap.error('Duration, frame rate, slowdown and particle count must be positive.')
    case = a.project / 'cfd' / a.case
    marker = case / 'aorta.foam'
    if not marker.is_file():
        raise FileNotFoundError(marker)
    if not shutil.which('ffmpeg'):
        raise RuntimeError('FFmpeg must be on PATH.')
    output = a.output or (a.project / 'results' / 'cfd' / (a.case + '_particles_wss'))
    output.mkdir(parents=True, exist_ok=False)
    movie = output / 'Aortic_Flow_And_Instantaneous_WSS_1080p.mp4'

    r = vtk.vtkOpenFOAMReader()
    r.SetFileName(str(marker))
    r.UpdateInformation()
    r.EnableAllPatchArrays()
    r.EnableAllCellArrays()
    times = vtk_to_numpy(r.GetTimeValues()).copy()
    available = times[(times >= a.end - 1 - 1e-8) & (times <= a.end + 1e-8)]
    if len(available) != 21 or not np.allclose(available, np.linspace(a.end - 1, a.end, 21)):
        raise RuntimeError('Expected 21 saved phases in the final one-second cycle.')
    velocities = []
    wall_stress = []
    grid = None
    wall = inlet = None
    for t in available:
        r.UpdateTimeStep(float(t))
        blocks = r.GetOutput()
        raw = blocks.GetBlock(0)
        boundaries = blocks.GetBlock(1)
        patches = {boundaries.GetMetaData(i).Get(vtk.vtkCompositeDataSet.NAME()):
                   boundaries.GetBlock(i) for i in range(boundaries.GetNumberOfBlocks())}
        stress = patches['aorta_wall'].GetCellData().GetArray('wallShearStress')
        if stress is None:
            raise RuntimeError(f'Missing wallShearStress at {t:g} s. Run WSS postprocessing first.')
        header = (case / f'{t:g}' / 'wallShearStress').read_bytes()[:1400]
        if not re.search(rb'dimensions\s+\[0 2 -2 0 0 0 0\]', header):
            raise RuntimeError(f'Unexpected native WSS units at {t:g}; expected m2/s2.')
        wall_stress.append(vtk_to_numpy(stress).astype(np.float64).copy() * 1060.)
        if grid is None:
            grid = vtk.vtkUnstructuredGrid()
            grid.DeepCopy(raw)
            boundaries = blocks.GetBlock(1)
            patches = {boundaries.GetMetaData(i).Get(vtk.vtkCompositeDataSet.NAME()):
                       boundaries.GetBlock(i) for i in range(boundaries.GetNumberOfBlocks())}
            wall = vtk.vtkPolyData()
            wall.DeepCopy(patches['aorta_wall'])
            inlet = vtk.vtkPolyData()
            inlet.DeepCopy(patches['aorta_inlet'])
        elif raw.GetNumberOfCells() != grid.GetNumberOfCells():
            raise RuntimeError('This renderer requires a static mesh.')
        c2p = vtk.vtkCellDataToPointData()
        c2p.SetInputData(raw)
        c2p.Update()
        velocities.append(vtk_to_numpy(c2p.GetOutput().GetPointData().GetArray('U')).copy())
    velocities = np.array(velocities, dtype=np.float64)
    wall_stress = np.array(wall_stress, dtype=np.float64)
    if not np.all(np.isfinite(wall_stress)) or wall_stress.shape[1] != wall.GetNumberOfCells():
        raise RuntimeError('Invalid WSS values or wall topology.')
    grid.GetCellData().Initialize()
    grid.GetPointData().Initialize()
    u = numpy_to_vtk(velocities[0].copy(), deep=True)
    u.SetName('U')
    grid.GetPointData().AddArray(u)
    buffer = vtk_to_numpy(u)

    # Persistent tracers, advanced by midpoint integration of dx/dt = U(x,t).
    # Linear temporal interpolation is applied to velocity data, never video frames.
    points = vtk.vtkPoints()
    points.SetDataTypeToDouble()
    cloud = vtk.vtkPolyData()
    cloud.SetPoints(points)
    probe = vtk.vtkProbeFilter()
    probe.SetInputData(cloud)
    probe.SetSourceData(grid)
    if hasattr(probe, 'SetCellLocatorPrototype'):
        probe.SetCellLocatorPrototype(vtk.vtkStaticCellLocator())
    probe.SetComputeTolerance(False)
    probe.SetTolerance(1e-8)

    def sample(x, t):
        phase = (t % 1.0) * 20
        k = min(int(phase), 19)
        w = phase - k
        buffer[:] = velocities[k] * (1 - w) + velocities[k + 1] * w
        u.Modified()
        points.SetData(numpy_to_vtk(np.ascontiguousarray(x), deep=True))
        points.Modified()
        cloud.Modified()
        probe.Update()
        data = probe.GetOutput().GetPointData()
        return (vtk_to_numpy(data.GetArray('U')).copy(),
                vtk_to_numpy(data.GetArray('vtkValidPointMask')).astype(bool))

    rng = np.random.default_rng(20261015)
    centres = vtk.vtkCellCenters()
    centres.SetInputData(grid)
    centres.Update()
    volume_centres = vtk_to_numpy(centres.GetOutput().GetPoints().GetData())
    pos = volume_centres[rng.integers(len(volume_centres), size=a.particles)].copy()
    triangulate = vtk.vtkTriangleFilter()
    triangulate.SetInputData(inlet)
    triangulate.Update()
    tri = triangulate.GetOutput()
    inlet_points = vtk_to_numpy(tri.GetPoints().GetData())
    triangles = np.array([[tri.GetCell(i).GetPointId(j) for j in range(3)]
                          for i in range(tri.GetNumberOfCells())])
    xyz = inlet_points[triangles]
    weights = np.linalg.norm(np.cross(xyz[:, 1] - xyz[:, 0], xyz[:, 2] - xyz[:, 0]), axis=1)
    weights /= weights.sum()

    def inject(n):
        v = xyz[rng.choice(len(xyz), n, p=weights)]
        s = np.sqrt(rng.random(n))
        b = rng.random(n)
        p = ((1 - s)[:, None] * v[:, 0] + (s * (1 - b))[:, None] * v[:, 1]
             + (s * b)[:, None] * v[:, 2])
        p[:, 2] -= .0006
        return p

    # Orthographic view in physical coordinates. Pillow avoids display-server needs.
    az, el = np.deg2rad([-65., 8.])
    right = np.array([-np.sin(az), np.cos(az), 0])
    up = np.array([-np.sin(el) * np.cos(az), -np.sin(el) * np.sin(az), np.cos(el)])
    depth = np.cross(right, up)
    wp = vtk_to_numpy(wall.GetPoints().GetData())
    center = (wp.min(axis=0) + wp.max(axis=0)) / 2
    projected = np.column_stack(((wp - center) @ right, (wp - center) @ up))
    scale = min(690 / np.ptp(projected[:, 0]), 730 / np.ptp(projected[:, 1]))

    def project(x):
        q = x - center
        return np.column_stack((490 + scale * (q @ right), 555 - scale * (q @ up)))

    W, H = 1920, 1080
    background = Image.new('RGB', (W, H), '#081422')
    shell = Image.new('RGBA', (W, H))
    sd = ImageDraw.Draw(shell)
    xy = project(wp)
    wall_indices = [[wall.GetCell(i).GetPointId(j) for j in range(wall.GetCell(i).GetNumberOfPoints())]
                    for i in range(wall.GetNumberOfCells())]
    wall_order = np.argsort([np.mean((wp[ids] - center) @ depth) for ids in wall_indices])
    wall_polygons = [[(float(xy[j, 0] + 940), float(xy[j, 1])) for j in ids] for ids in wall_indices]
    # A faint shell gives vessel context while leaving moving particles readable.
    for i in range(wall.GetNumberOfCells()):
        cell = wall.GetCell(i)
        polygon = [tuple(xy[cell.GetPointId(j)]) for j in range(cell.GetNumberOfPoints())]
        sd.polygon(polygon, fill=(64, 130, 166, 24), outline=(90, 168, 200, 22))
    background = Image.alpha_composite(background.convert('RGBA'), shell).convert('RGB')

    def font(size):
        for path in ['/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
                     'C:/Windows/Fonts/arial.ttf']:
            if Path(path).is_file():
                return ImageFont.truetype(path, size)
        return ImageFont.load_default()

    titlefont, bodyfont, smallfont = font(36), font(24), font(19)
    bd = ImageDraw.Draw(background)
    bd.text((80, 30), 'AORTIC FLOW & INSTANTANEOUS WALL SHEAR STRESS', font=titlefont, fill='#e9f5ff')
    bd.text((80, 108), 'Moving tracers | colour = speed', font=bodyfont, fill='#92b3ca')
    bd.text((1020, 108), 'Wall shear stress | changes with the flow', font=bodyfont, fill='#92b3ca')
    bd.text((80, 975), 'Particle colour: speed (m/s)', font=bodyfont, fill='#d4e8f5')
    stops = np.array([[70, 125, 255], [0, 216, 228], [80, 232, 140], [252, 208, 70], [255, 88, 65]])

    def colors(speed):
        f = np.clip(speed / .25, 0, 1) * 4
        k = np.minimum(f.astype(int), 3)
        return (stops[k] * (1 - (f - k)[:, None]) + stops[k + 1] * (f - k)[:, None]).astype(np.uint8)

    for j, c in enumerate(colors(np.linspace(0, .25, 480))):
        bd.line((80 + j, 1017, 80 + j, 1031), fill=tuple(c), width=1)
    bd.text((80, 1036), '0', font=smallfont, fill='#9ab8cc')
    bd.text((510, 1036), '0.25+', font=smallfont, fill='#9ab8cc')
    bd.text((1020, 975), 'Instantaneous WSS (Pa)', font=bodyfont, fill='#d4e8f5')
    for j, c in enumerate(colors(np.linspace(0, .25, 480))):
        bd.line((1020 + j, 1017, 1020 + j, 1031), fill=tuple(c), width=1)
    bd.text((1020, 1036), '0', font=smallfont, fill='#9ab8cc')
    bd.text((1450, 1036), '0.30+', font=smallfont, fill='#9ab8cc')
    bd.text((80, 923), f'Saved cycle {a.end-1:g}–{a.end:g} s repeated · synthetic inflow · repaired research geometry', font=smallfont, fill='#9ab8cc')

    command = ['ffmpeg', '-n', '-v', 'error', '-f', 'rawvideo', '-pix_fmt', 'rgb24',
               '-s', f'{W}x{H}', '-r', str(a.fps), '-i', '-', '-an', '-c:v', 'libx264',
               '-preset', 'medium', '-crf', '17', '-pix_fmt', 'yuv420p',
               '-movflags', '+faststart', str(movie)]
    log = (output / 'encoding.log').open('w')
    encoder = subprocess.Popen(command, stdin=subprocess.PIPE, stderr=log)
    frames = a.seconds * a.fps
    frame_dt = 1 / (a.fps * a.slowdown)
    substeps = max(2, int(np.ceil(frame_dt / .002)))
    dt = frame_dt / substeps
    t = 0.
    counts = []
    try:
        for frame in range(frames):
            previous = pos.copy()
            reset = np.zeros(len(pos), dtype=bool)
            for step in range(substeps):
                v0, ok0 = sample(pos, t)
                vm, okm = sample(pos + .5 * dt * v0, t + .5 * dt)
                pos += dt * vm
                t += dt
                _, ok1 = sample(pos, t)
                invalid = ~(ok0 & okm & ok1) | (pos[:, 2] < -.4199)
                if invalid.any():
                    pos[invalid] = inject(int(invalid.sum()))
                    reset |= invalid
            velocity, valid = sample(pos, t)
            counts.append(int(valid.sum()))
            if frame == 0 and valid.sum() < a.particles * .5:
                raise RuntimeError('Too few valid tracers; inspect the mesh and sampling.')
            screen, old = project(pos), project(previous)
            rgb = colors(np.linalg.norm(velocity, axis=1))
            image = background.copy()
            draw = ImageDraw.Draw(image)
            phase_index = (t % 1.) * 20
            phase_k = min(int(phase_index), 19)
            phase_w = phase_index - phase_k
            instantaneous = (wall_stress[phase_k] * (1 - phase_w)
                             + wall_stress[phase_k + 1] * phase_w)
            stress_magnitude = np.linalg.norm(instantaneous, axis=1)
            # One fixed scale across all phases; interpolate vectors before magnitude.
            stress_rgb = colors(stress_magnitude * (.25 / .30))
            for face in wall_order:
                draw.polygon(wall_polygons[face], fill=tuple(int(v) for v in stress_rgb[face]))
            for j in np.argsort((pos - center) @ depth):
                if not valid[j]:
                    continue
                x, y = screen[j]
                c = tuple(int(v) for v in rgb[j])
                if not reset[j] and np.linalg.norm(screen[j] - old[j]) < 30:
                    draw.line([tuple(old[j]), (x, y)], fill=tuple(int(v * .55) for v in rgb[j]), width=2)
                draw.ellipse((x - 2, y - 2, x + 2, y + 2), fill=c)
            phase = a.end - 1 + (t % 1)
            draw.text((80, 75), f'Phase: {phase:.3f} s | {a.slowdown:g}× slower playback', font=smallfont, fill='#e9f5ff')
            draw.text((1510, 975), f'Peak: {stress_magnitude.max():.3f} Pa', font=smallfont, fill='#e9f5ff')
            encoder.stdin.write(image.tobytes())
            if frame in [0, frames // 2]:
                image.save(output / ('preview.png' if frame == 0 else 'preview_mid.png'))
            if frame % a.fps == 0:
                print(f'{frame // a.fps:02d}/{a.seconds} seconds rendered | valid tracers {valid.sum()}', flush=True)
        encoder.stdin.close()
        if encoder.wait() != 0:
            raise RuntimeError('Encoding failed; see encoding.log.')
    except BaseException:
        if encoder.poll() is None:
            encoder.kill()
            encoder.wait()
        raise
    finally:
        log.close()
    metadata = dict(case=a.case, resolution=[W, H], fps=a.fps, frames=frames,
                    duration_s=a.seconds, slowdown=a.slowdown, particles=a.particles,
                    velocity_cycle_s=[a.end - 1, a.end], stored_phase_interval_s=.05,
                    wall_stress='Instantaneous face-associated native WSS vector, multiplied by 1060 once',
                    wss_color_range_Pa=[0, .30],
                    native_max_WSS_Pa=float(np.linalg.norm(wall_stress, axis=2).max()),
                    wss_interpolation='Linear interpolation of vectors in time, then magnitude; fixed color scale',
                    integration='midpoint RK2 with spatial VTK interpolation and linear temporal interpolation',
                    integration_step_s=dt, minimum_valid_tracers=min(counts),
                    note='Final solved cycle is repeated. Tracers are visual markers, not modeled blood cells. No video frame blending.')
    (output / 'render_details.json').write_text(json.dumps(metadata, indent=2))
    subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'stream=width,height,r_frame_rate,nb_frames',
                    '-show_entries', 'format=duration', '-of', 'json', str(movie)], check=True)
    print(f'COMPLETE: {movie}', flush=True)


if __name__ == '__main__':
    main()
