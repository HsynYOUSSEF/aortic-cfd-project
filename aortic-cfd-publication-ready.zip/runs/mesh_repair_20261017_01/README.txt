This is a new, isolated run. Old cases and results are not used or changed.

Local mesh checks pass; native OpenFOAM checks are still required and are the first gate in run.sh. It then solves to 30 s, retains the final 41 times (28-30 s) in THIS case only, calculates WSS, checks mass balance and cycle agreement, and renders a 30-second 1080p/30fps particle and WSS video. The last solved cycle is repeated at reduced playback speed; it is not 30 seconds of unique simulated history.

Ubuntu: bash run.sh
Windows PowerShell: powershell -ExecutionPolicy Bypass -File .\Run-Simulation.ps1

Open cfd/aorta/aorta.foam in ParaView. Mesh-only viewing is possible before solving. Final video location is printed on completion and saved in reports/COMPLETE.txt. Failures stop the pipeline and keep logs.

Geometry: maximum sampled original-to-new surface distance 0.113 mm; volume change -0.0094 percent. Original CT and masks unchanged. Synthetic inflow, rigid wall, two zero-pressure outlets, no prism layers. Anatomical accuracy and WSS grid convergence are not established.
