#!/usr/bin/env bash
# Normal local OpenFOAM pipeline. No system installation, relay, or permission workaround.
set -euo pipefail
SOURCE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT="$(cd "$SOURCE/../.." && pwd)"
PY="${PYTHON_CFD:-/home/admin007/.venvs/aortic-cfd/bin/python}"
RANKS="${AORTIC_RANKS:-8}"
export WM_PROJECT_DIR="${WM_PROJECT_DIR:-/usr/share/openfoam}"
export FOAM_ETC="${FOAM_ETC:-$WM_PROJECT_DIR/etc}"
for app in mpirun decomposePar reconstructPar checkMesh pimpleFoam ffmpeg ffprobe g++; do command -v "$app" >/dev/null; done
# Test permissions before creating a case. A failure is retained and must not be bypassed.
[[ "$RANKS" =~ ^[1-9][0-9]*$ ]] || { echo "AORTIC_RANKS must be a positive integer"; exit 2; }
if (( RANKS > 1 )); then mpirun -np "$RANKS" /usr/bin/true; fi
WORK="$(mktemp -d /tmp/aortic_validated_XXXXXXXX)"
export WORK SOURCE PROJECT RANKS
mkdir -p "$WORK"/{cfd,src,logs,reports,results}
exec > >(tee "$WORK/logs/pipeline.log") 2>&1
STAGE=preparation
trap 'code=$?; if (( code != 0 )); then echo "INCOMPLETE at $STAGE, exit $code. All files retained at $WORK"; fi' EXIT
"$PY" - <<'PY'
from pathlib import Path
import os,shutil,re,json,hashlib
source=Path(os.environ['SOURCE']);work=Path(os.environ['WORK']);case=work/'cfd/aorta';case.mkdir()
assert json.loads((source/'reports/saved_field_validation.json').read_text())['status']=='SAVED_INITIAL_TRANSIENT_CHECKS_PASS'
required=1392070*72*602+3*1024**3
assert shutil.disk_usage(work).free>required,'Insufficient Linux work-disk space for preserving every new saved time'
for name in ['0','system','constant']:shutil.copytree(source/'cfd/aorta'/name,case/name)
for name in ['watch_run.py','verify_initial_field.py','reconstruct_initial.py','analyze_results.py','validate_saved_fields.py','render_flow_wss.py','check_mesh_gate.py','sha1_compat.cpp']:shutil.copy2(source/'src'/name,work/'src'/name)
# Baseline corrector counts, never the unaccepted performance experiment.
p=case/'system/fvSolution';s=p.read_text();assert 'nOuterCorrectors 2' in s and 'nNonOrthogonalCorrectors 2' in s
p=case/'system/controlDict';s=p.read_text()
for key,value in {'startFrom':'startTime','startTime':'0','stopAt':'endTime','endTime':'0.01','writeInterval':'0.002','purgeWrite':'0','maxCo':'0.7'}.items():
 s,n=re.subn(r'\b'+key+r'\s+[^;]+;',key+' '+value+';',s);assert n==1
p.write_text(s);(case/'aorta.foam').touch()
(case/'system/decomposeParDict').write_text('FoamFile {version 2.0;format ascii;class dictionary;object decomposeParDict;}\nnumberOfSubdomains '+os.environ['RANKS']+';\nmethod scotch;\n')
manifest={str(p.relative_to(case)):hashlib.sha256(p.read_bytes()).hexdigest() for p in case.rglob('*') if p.is_file()};(work/'reports/INPUT_SHA256.json').write_text(json.dumps(manifest,indent=2))
config=json.loads((Path(os.environ['PROJECT'])/'runs/mesh_repair_20261017_01/run_config.json').read_text());config['run_status']='IN_PROGRESS';config['retained_output_times']='All new saved times retained on Linux work disk';(work/'run_config.json').write_text(json.dumps(config,indent=2))
PY
STAGE='native mesh validation'
checkMesh -case "$WORK/cfd/aorta" -allTopology -allGeometry > "$WORK/logs/checkMesh.log" 2>&1
"$PY" "$WORK/src/check_mesh_gate.py" "$WORK/logs/checkMesh.log"
STAGE='independent initialization gate'
OPENBLAS_NUM_THREADS=1 "$PY" "$WORK/src/verify_initial_field.py" "$WORK/cfd/aorta" > "$WORK/logs/verify_initial.log" 2>&1
STAGE='decomposition'
if (( RANKS > 1 )); then decomposePar -case "$WORK/cfd/aorta" > "$WORK/logs/decompose.log" 2>&1; fi
STAGE='short stability test'
"$PY" "$WORK/src/watch_run.py" "$WORK" --ranks "$RANKS" --target 0.01 --budget 2700 --stage short
if (( RANKS > 1 )); then reconstructPar -case "$WORK/cfd/aorta" -time '0.002:0.01' > "$WORK/logs/reconstruct_short.log" 2>&1; fi
g++ -shared -fPIC -o "$WORK/src/libsha1_compat.so" "$WORK/src/sha1_compat.cpp"
LD_PRELOAD="$WORK/src/libsha1_compat.so" pimpleFoam -case "$WORK/cfd/aorta" -postProcess -func wallShearStress -time '0.002:0.01' > "$WORK/logs/WSS_short.log" 2>&1
"$PY" "$WORK/src/validate_saved_fields.py" "$WORK" --require-end 0.01 --minimum-times 5 > "$WORK/logs/validate_short.log" 2>&1
STAGE='bridge to globally aligned output phase'
# Adjustable writes align to a restarted run's start time. Reach 0.05 s first,
# so subsequent 0.05-s writes are exactly 28, 28.05, ..., 30 s.
"$PY" - <<'PYBRIDGE'
from pathlib import Path
import os,re
p=Path(os.environ['WORK'])/'cfd/aorta/system/controlDict';s=p.read_text()
for key,value in {'startFrom':'latestTime','endTime':'0.05','writeInterval':'0.04','maxDeltaT':'0.005','purgeWrite':'0'}.items():
 s,n=re.subn(r'\b'+key+r'\s+[^;]+;',key+' '+value+';',s);assert n==1
p.write_text(s)
PYBRIDGE
"$PY" "$WORK/src/watch_run.py" "$WORK" --ranks "$RANKS" --target 0.05 --budget 2700 --stage bridge
if (( RANKS > 1 )); then reconstructPar -case "$WORK/cfd/aorta" -time 0.05 > "$WORK/logs/reconstruct_bridge.log" 2>&1; fi
test -f "$WORK/cfd/aorta/0.05/U"
test -f "$WORK/cfd/aorta/0.05/p"
STAGE='full transient'
"$PY" - <<'PY'
from pathlib import Path
import os,re
p=Path(os.environ['WORK'])/'cfd/aorta/system/controlDict';s=p.read_text()
for key,value in {'startFrom':'latestTime','endTime':'30','writeInterval':'0.05','maxDeltaT':'0.005','purgeWrite':'0'}.items():
 s,n=re.subn(r'\b'+key+r'\s+[^;]+;',key+' '+value+';',s);assert n==1
p.write_text(s)
PY
"$PY" "$WORK/src/watch_run.py" "$WORK" --ranks "$RANKS" --target 30 --budget 172800 --stage full
STAGE='final fields and WSS'
if (( RANKS > 1 )); then reconstructPar -case "$WORK/cfd/aorta" -time '28:30' > "$WORK/logs/reconstruct_final.log" 2>&1; fi
LD_PRELOAD="$WORK/src/libsha1_compat.so" pimpleFoam -case "$WORK/cfd/aorta" -postProcess -func wallShearStress -time '28:30' > "$WORK/logs/WSS_final.log" 2>&1
"$PY" "$WORK/src/analyze_results.py" > "$WORK/logs/analysis.log" 2>&1
"$PY" - <<'PY'
from pathlib import Path
import os,json,math
s=json.loads((Path(os.environ['WORK'])/'results/aorta/summary.json').read_text())
assert s['conservation_under_0_5_percent'] and s['cycle_change_under_5_percent']
assert s['max_relative_inlet_waveform_error']<.01
assert math.isfinite(s['peak_speed_m_s']) and s['peak_speed_m_s']<10
PY
STAGE='actual 1080p flow/WSS video'
"$PY" "$WORK/src/render_flow_wss.py" --project "$WORK" --case aorta --end 30 --seconds 30 --fps 30 --slowdown 8 --particles 4000 --output "$WORK/results/final_video" > "$WORK/logs/render.log" 2>&1
ffmpeg -v error -i "$WORK/results/final_video/Aortic_Flow_And_Instantaneous_WSS_1080p.mp4" -f null -
STAGE='export validated final fields to Desktop'
"$PY" - <<'PY'
from pathlib import Path
from datetime import datetime
import os,shutil,re,json
work=Path(os.environ['WORK']);project=Path(os.environ['PROJECT']);case=work/'cfd/aorta'
times=[p for p in case.iterdir() if p.is_dir() and re.fullmatch(r'\d+(?:\.\d+)?',p.name) and 28-1e-7<=float(p.name)<=30+1e-7]
assert len(times)==41
items=[case/n for n in ['0','system','constant']]+times+[work/n for n in ['results','reports','logs','src']]+[work/'run_config.json']
size=sum(f.stat().st_size for p in items for f in (p.rglob('*') if p.is_dir() else [p]) if f.is_file())
assert shutil.disk_usage(project).free>size+512*1024**2,'Insufficient Desktop space; complete results remain intact on Linux work disk'
dest=project/'runs'/('validated_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'));target=dest/'cfd/aorta';target.mkdir(parents=True,exist_ok=False)
for p in items:
 out=target/p.name if p.parent==case else dest/p.name
 if p.is_dir():shutil.copytree(p,out)
 else:shutil.copy2(p,out)
(target/'aorta.foam').touch();(dest/'reports/COMPLETE.txt').write_text(f'All pipeline gates passed. Full intermediate fields retained at {work}. Desktop copy contains the final two cycles plus initial fields. No old results deleted.\n')
print('COMPLETE: '+str(dest));print('Full Linux work directory retained: '+str(work))
PY
