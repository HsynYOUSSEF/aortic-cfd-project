from pathlib import Path
import sys,json
import numpy as np
import vtk
from vtk.util.numpy_support import vtk_to_numpy,numpy_to_vtk
sys.path.insert(0,str(Path(__file__).resolve().parent));import analyze_results as a
root=Path(sys.argv[1]).resolve();report=json.loads((root/'reports/saved_field_validation.json').read_text());out=root/'results/paraview_wall_series';out.mkdir(parents=True,exist_ok=False)
r=a.reader(root/'cfd/aorta');entries=[]
for row in report['fields']:
 t=row['time_s'];_,patches=a.fields(r,t);wall=vtk.vtkPolyData();wall.DeepCopy(patches['aorta_wall']);tau=vtk_to_numpy(wall.GetCellData().GetArray('wallShearStress')).astype(float)*1060
 arr=numpy_to_vtk(tau,deep=True);arr.SetName('WSS_vector_Pa');wall.GetCellData().AddArray(arr);arr=numpy_to_vtk(np.linalg.norm(tau,axis=1),deep=True);arr.SetName('WSS_Pa');wall.GetCellData().AddArray(arr)
 name=f'wall_{t:.10g}.vtp';w=vtk.vtkXMLPolyDataWriter();w.SetFileName(str(out/name));w.SetInputData(wall);assert w.Write()==1
 # Read back the standalone artifact, including units-bearing array names.
 verify=vtk.vtkXMLPolyDataReader();verify.SetFileName(str(out/name));verify.Update();assert verify.GetOutput().GetNumberOfCells()==wall.GetNumberOfCells();assert verify.GetOutput().GetCellData().GetArray('WSS_Pa') is not None
 entries.append(f'<DataSet timestep="{t:.10g}" group="" part="0" file="{name}"/>')
(out/'wall_WSS_Pa.pvd').write_text('<?xml version="1.0"?><VTKFile type="Collection" version="0.1" byte_order="LittleEndian"><Collection>'+''.join(entries)+'</Collection></VTKFile>')
(out/'README.txt').write_text('Initial-transient wall fields only. WSS_Pa is the magnitude and WSS_vector_Pa the vector after multiplying native kinematic wallShearStress once by rho=1060 kg/m3. No periodic-cycle validation or patient-specific accuracy claim. Native full-volume U/p/phi fields remain in ../../cfd/aorta/aorta.foam.\n')
print(out/'wall_WSS_Pa.pvd')
