from pathlib import Path
import re,json,time
from datetime import datetime,timezone
project=Path(__file__).resolve().parents[3]
names=['runtime_repair_20261017_01','corrector_test_20261017_01']
while True:
 rows=[]
 for name in names:
  root=project/'runs'/name;log=root/'logs/solver.log';tail=log.read_bytes()[-131072:].decode(errors='replace')
  def value(label):
   found=re.findall(r'^'+label+r'\s*=\s*([^\s]+)',tail,re.M);return float(found[-1]) if found else None
  result=root/'reports/stability_result.json'
  rows.append({'case':str(root.relative_to(project)),'latest_logged_time_s':value('Time'),'latest_timestep_s':value('deltaT'),'result':json.loads(result.read_text()) if result.exists() else None})
 status={'updated_utc':datetime.now(timezone.utc).isoformat(),'full_simulation_complete':False,'cases':rows,'validated_diagnostic_times_s':[.0001,.0002],'diagnostic_video':'runs/runtime_repair_20261017_01/results/initial_transient_video_software/Initial_Transient_DIAGNOSTIC_720p.mp4','paraview':'runs/runtime_repair_20261017_01/cfd/aorta/aorta.foam','blocked_parallel_preflight':'MPI/PMIx listener socket creation denied by current sandbox (errno=1). No override or relay attempted.'}
 p=project/'reports/CONTINUATION_STATUS.json';temporary=p.with_suffix('.json.tmp');temporary.write_text(json.dumps(status,indent=2));temporary.replace(p)
 if all(x['result'] is not None for x in rows):break
 time.sleep(10)
