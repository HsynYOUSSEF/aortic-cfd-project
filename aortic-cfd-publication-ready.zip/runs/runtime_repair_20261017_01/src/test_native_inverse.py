import ctypes as c
import numpy as np,json
from pathlib import Path
class UList(c.Structure):
 _fields_=[('size',c.c_int),('data',c.c_void_p)]
class Field(c.Structure):
 _fields_=[('vtable',c.c_void_p),('size',c.c_int),('data',c.c_void_p)]
lib=c.CDLL('/lib/libOpenFOAM.so')
f=getattr(lib,'_ZN4Foam3invERNS_5FieldINS_10SymmTensorIdEEEERKNS_5UListIS2_EE');f.argtypes=[c.POINTER(Field),c.POINTER(UList)];f.restype=None
rng=np.random.default_rng(173);m=rng.normal(size=(1000,3,3));a=m @ m.transpose(0,2,1)+np.eye(3)
a*=1e-7
indices=np.triu_indices(3);packed=a[:,indices[0],indices[1]].copy();expected=np.linalg.inv(a)[:,indices[0],indices[1]]
results={}
for alias in [False,True]:
 src=packed.copy();out=src if alias else np.zeros_like(src)
 f(c.byref(Field(None,len(out),out.ctypes.data)),c.byref(UList(len(src),src.ctypes.data)))
 results[str(alias)]={'max_relative_error':float(np.max(abs(out-expected))/np.max(abs(expected))),'max_error_by_component':np.max(abs(out-expected),axis=0).tolist()}
print(json.dumps(results,indent=2))
