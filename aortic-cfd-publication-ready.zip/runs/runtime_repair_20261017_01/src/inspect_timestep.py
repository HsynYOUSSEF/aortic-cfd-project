from pathlib import Path
import numpy as np,json
s=Path(__file__).with_name('reconstruct_initial.py').read_text();s=s[:s.index("assert np.isfinite(ur)")]
exec(s)
fc=points[faces].mean(1)
vface=np.einsum('ij,ij->i',sf,fc)/3
vol=np.bincount(own,weights=vface,minlength=nc)-np.bincount(nei,weights=vface[:ni],minlength=nc)
rate=both(abs(phiall))*.5
scale=vol/np.maximum(rate,1e-30)
print('VOLUME quantiles',np.quantile(vol,[0,.001,.01,.5,1]))
print('V/FLUX quantiles',np.quantile(scale,[0,.00001,.0001,.001,.01,.5,1]))
idx=np.argsort(scale)[:20]
for k in idx: print(k,vol[k],rate[k],scale[k],ur[k])
np.savez_compressed(root.parent.parent/'reports/mesh_flow_diagnostics.npz',volumes=vol,flux_rate=rate,timestep_scale=scale)
