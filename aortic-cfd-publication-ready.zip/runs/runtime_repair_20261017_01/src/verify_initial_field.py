"""Check native initial U against independent oriented-face flux reconstruction."""
from pathlib import Path
import sys,json,re,hashlib
import numpy as np
source=Path(__file__).with_name('reconstruct_initial.py').read_text();source=source[:source.index('assert np.isfinite(ur)')]
exec(compile(source,'independent_reconstruction','exec'))
assert np.isfinite(u).all() and np.isfinite(ur).all()
error=float(np.max(abs(u-ur)));assert error<1e-9,('Initial U does not match independent reconstruction',error)
peak=float(np.linalg.norm(u,axis=1).max());assert peak<10
ud=(root/'0/U').read_bytes();pd=(root/'0/phi').read_bytes();flux=[]
for name in ['aorta_inlet','aorta_outlet1','aorta_outlet2']:
 for data,components in [(ud,3),(pd,1)]:
  start=data.index(name.encode(),data.index(b'boundaryField'));part=data[start:];m=re.search(rb'value\s+nonuniform\s+List<\w+>\s+(\d+)\s*\(',part);assert m
  values=np.frombuffer(part,dtype='<f8',count=int(m[1])*components,offset=m.end()).reshape(-1,components);assert np.isfinite(values).all()
  if components==3:assert np.linalg.norm(values,axis=1).max()<10
  else:flux.append(float(values.sum()))
imbalance=abs(sum(flux))/abs(flux[0]);assert imbalance<.005
assert abs(-flux[0]-5e-5)/5e-5<.01
result={'status':'INDEPENDENT_INITIAL_FLOW_CHECK_PASS','max_component_error_m_s':error,'max_internal_speed_m_s':peak,'relative_initial_flux_imbalance':imbalance,'initial_fluxes_m3_s':flux,'input_sha256':{name:hashlib.sha256((root/'0'/name).read_bytes()).hexdigest() for name in ['U','phi']}}
(root.parent.parent/'reports/initialization_verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
