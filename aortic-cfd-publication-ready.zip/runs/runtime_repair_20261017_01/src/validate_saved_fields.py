from pathlib import Path
import sys,re,json,importlib.util
import numpy as np
import argparse
ap=argparse.ArgumentParser();ap.add_argument('root',type=Path);ap.add_argument('--require-end',type=float);ap.add_argument('--minimum-times',type=int,default=1);args=ap.parse_args()
root=args.root.resolve();case=root/'cfd/aorta'
spec=importlib.util.spec_from_file_location('analysis',root/'src/analyze_results.py');analysis=importlib.util.module_from_spec(spec);spec.loader.exec_module(analysis)
r=analysis.reader(case);rows=[]
for folder in sorted(case.iterdir(),key=lambda p:float(p.name) if re.fullmatch(r'[0-9.]+',p.name) else 1e99):
 if not re.fullmatch(r'[0-9.]+',folder.name) or float(folder.name)<=0:continue
 if not (folder/'wallShearStress').exists():continue
 t=float(folder.name);mesh,patches=analysis.fields(r,t)
 u=analysis.vtk_to_numpy(mesh.GetCellData().GetArray('U'));p=analysis.vtk_to_numpy(mesh.GetCellData().GetArray('p'));assert np.isfinite(u).all() and np.isfinite(p).all()
 assert np.linalg.norm(u,axis=1).max()<10,'Unphysical velocity for this diagnostic'
 flux=[analysis.patch_flux(folder/'phi',name,patches[name].GetNumberOfCells()) for name in ['aorta_inlet','aorta_outlet1','aorta_outlet2']]
 imbalance=abs(sum(flux))/abs(flux[0]);waveform=5e-5+3.5e-5*np.sin(2*np.pi*t);inlet_error=abs(-flux[0]-waveform)/waveform
 assert imbalance<.005 and inlet_error<.01,(imbalance,inlet_error)
 h=(folder/'wallShearStress').read_bytes()[:1500];assert re.search(rb'dimensions\s*\[\s*0\s+2\s+-2\s+0\s+0\s+0\s+0\s*\]',h)
 wall=patches['aorta_wall'];tau=analysis.vtk_to_numpy(wall.GetCellData().GetArray('wallShearStress')).astype(float)*1060;assert np.isfinite(tau).all()
 rows.append({'time_s':t,'cells':mesh.GetNumberOfCells(),'peak_speed_m_s':float(np.linalg.norm(u,axis=1).max()),'relative_flow_imbalance':imbalance,'relative_inlet_waveform_error':inlet_error,'fluxes_m3_s':flux,'mean_WSS_Pa':float(np.average(np.linalg.norm(tau,axis=1),weights=analysis.areas(wall))),'max_WSS_Pa':float(np.linalg.norm(tau,axis=1).max())})
assert len(rows)>=args.minimum_times,'Insufficient complete saved fields with WSS'
if args.require_end is not None:assert abs(rows[-1]['time_s']-args.require_end)<1e-8,'Required final saved field with WSS is missing'
report={'status':'SAVED_INITIAL_TRANSIENT_CHECKS_PASS','paraview_reader':'VTK OpenFOAM reader successfully loaded mesh, boundaries and time-dependent U/p/WSS','fields':rows,'stress_conversion':'Native [0 2 -2 0 0 0 0] multiplied once by rho=1060 kg/m3 to Pa','full_simulation_complete':False,'periodic_cycle_validated':False,'limitations':'Initial transient diagnostics only; no TAWSS, OSI, RRT or converged-cycle claims.'}
(root/'reports/saved_field_validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
