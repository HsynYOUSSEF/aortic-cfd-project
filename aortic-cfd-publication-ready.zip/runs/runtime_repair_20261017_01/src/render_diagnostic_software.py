"""Render saved initial-transient fields. This is not the final validated-cycle video."""
from pathlib import Path
import sys,json,importlib.util,subprocess
import numpy as np
import vtk
from vtk.util.numpy_support import vtk_to_numpy,numpy_to_vtk
from PIL import Image,ImageDraw
root=Path(sys.argv[1]).resolve();out=root/'results/initial_transient_video_software';out.mkdir(parents=True,exist_ok=False)
report=json.loads((root/'reports/saved_field_validation.json').read_text());assert report['status']=='SAVED_INITIAL_TRANSIENT_CHECKS_PASS'
spec=importlib.util.spec_from_file_location('analysis',root/'src/analyze_results.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
r=a.reader(root/'cfd/aorta');states=[]
for row in report['fields']:
 mesh,patches=a.fields(r,row['time_s']);wall=vtk.vtkPolyData();wall.DeepCopy(patches['aorta_wall'])
 stress=vtk_to_numpy(wall.GetCellData().GetArray('wallShearStress')).astype(float)*1060
 arr=numpy_to_vtk(np.linalg.norm(stress,axis=1),deep=True);arr.SetName('WSS_Pa');wall.GetCellData().AddArray(arr)
 w=vtk.vtkXMLPolyDataWriter();w.SetFileName(str(out.parent/f"wall_{row['time_s']:g}_diagnostic.vtp"));w.SetInputData(wall);assert (out.parent/f"wall_{row['time_s']:g}_diagnostic.vtp").exists() or w.Write()
 # Streamlines use the actual solved velocity, interpolated from cells to points.
 c=vtk.vtkCellDataToPointData();c.SetInputData(mesh);c.Update();c.GetOutput().GetPointData().SetActiveVectors('U')
 seeds=vtk.vtkPointSource();seeds.SetCenter(patches['aorta_inlet'].GetCenter());bounds=patches['aorta_inlet'].GetBounds();seeds.SetRadius(max(bounds[1]-bounds[0],bounds[3]-bounds[2])*.3);seeds.SetNumberOfPoints(70)
 stream=vtk.vtkStreamTracer();stream.SetInputData(c.GetOutput());stream.SetSourceConnection(seeds.GetOutputPort());stream.SetIntegratorTypeToRungeKutta4();stream.SetIntegrationDirectionToForward();stream.SetMaximumPropagation(.4);stream.SetInitialIntegrationStep(.2);stream.SetMinimumIntegrationStep(.01);stream.SetMaximumIntegrationStep(.5);stream.SetMaximumNumberOfSteps(4000);stream.Update()
 lines=vtk.vtkPolyData();lines.DeepCopy(stream.GetOutput());states.append((row,wall,lines))
from xml.sax.saxutils import escape
entries=''.join(f'<DataSet timestep="{row["time_s"]:.9g}" group="" part="0" file="wall_{row["time_s"]:g}_diagnostic.vtp"/>' for row,_,_ in states)
(out.parent/'diagnostic_wall_WSS_Pa.pvd').write_text('<?xml version="1.0"?><VTKFile type="Collection" version="0.1" byte_order="LittleEndian"><Collection>'+entries+'</Collection></VTKFile>')

# Deterministic CPU rasterization avoids a dependency on X/GL in batch environments.
width,height=1280,720;fps=15;frames=75
movie=out/'Initial_Transient_DIAGNOSTIC_720p.mp4'
prepared=[]
for row,wall,lines in states:
 points=vtk_to_numpy(wall.GetPoints().GetData()).astype(float)
 triangles=vtk_to_numpy(wall.GetPolys().GetData()).reshape(-1,4)[:,1:]
 tau=vtk_to_numpy(wall.GetCellData().GetArray('WSS_Pa'))
 tri=points[triangles];centers=tri.mean(1);norm=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);norm/=np.maximum(np.linalg.norm(norm,axis=1),1e-30)[:,None]
 color_stops=np.array([[35,65,190],[30,180,220],[80,220,130],[250,225,60],[220,45,30]],float)
 scalar=np.clip(tau/5,0,1)*4;i=np.minimum(scalar.astype(int),3);frac=scalar-i;color=color_stops[i]*(1-frac[:,None])+color_stops[i+1]*frac[:,None]
 line_points=vtk_to_numpy(lines.GetPoints().GetData()) if lines.GetNumberOfPoints() else np.empty((0,3));line_indices=[]
 if lines.GetNumberOfLines():
  data=vtk_to_numpy(lines.GetLines().GetData());pos=0
  while pos<len(data):n=int(data[pos]);line_indices.append(data[pos+1:pos+1+n]);pos+=n+1
 prepared.append((row,points,triangles,centers,norm,color,line_points,line_indices))
center=(points.min(0)+points.max(0))*.5
proc=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pixel_format','rgb24','-video_size',f'{width}x{height}','-framerate',str(fps),'-i','-','-an','-c:v','libx264','-crf','20','-pix_fmt','yuv420p',str(movie)],stdin=subprocess.PIPE)
try:
 for frame in range(frames):
  row,points,triangles,centers,norm,color,line_points,line_indices=prepared[min(frame*len(prepared)//frames,len(prepared)-1)]
  angle=np.deg2rad(25+frame*.45);view=np.array([np.sin(angle)*.97,np.cos(angle)*.97,.2431]);view/=np.linalg.norm(view);right=np.cross([0,0,1],view);right/=np.linalg.norm(right);up=np.cross(view,right)
  xyz=points-center;uv=np.c_[xyz@right,xyz@up];scale=min(900/np.ptp(uv[:,0]),535/np.ptp(uv[:,1]));uv=uv*scale;uv[:,0]+=560;uv[:,1]=375-uv[:,1]
  facing=norm@view;visible=np.flatnonzero(facing>0);order=visible[np.argsort((centers[visible]-center)@view)]
  shaded=np.clip(color*(.42+.58*np.maximum(facing,0))[:,None],0,255).astype(np.uint8)
  im=Image.new('RGB',(width,height),(10,16,28));draw=ImageDraw.Draw(im)
  for k in order:draw.polygon([tuple(p) for p in uv[triangles[k]]],fill=tuple(shaded[k]))
  if len(line_points):
   xyz=line_points-center;lxy=np.c_[560+(xyz@right)*scale,375-(xyz@up)*scale]
   for indices in line_indices:
    if len(indices)>1:draw.line([tuple(p) for p in lxy[indices]],fill=(160,235,250),width=1)
  for y in range(420):
   value=1-y/419;s=value*4;k=min(int(s),3);rgb=color_stops[k]*(1-(s-k))+color_stops[k+1]*(s-k);draw.line((1150,150+y,1175,150+y),fill=tuple(rgb.astype(int)))
  draw.text((1120,115),'WSS (Pa)',fill='white',font_size=20)
  for value in range(6):draw.text((1185,560-value*84),str(value),fill='white',font_size=18)
  draw.rectangle((0,0,width,90),fill=(12,18,30));draw.text((20,12),'INITIAL TRANSIENT DIAGNOSTIC | No validated periodic cycle',fill='white',font_size=24)
  draw.text((20,48),f"Solved time {row['time_s']:.7f} s | Peak speed {row['peak_speed_m_s']:.3f} m/s | WSS colors capped at 5 Pa",fill=(190,220,240),font_size=20)
  draw.rectangle((0,652,width,height),fill=(12,18,30));draw.text((20,660),'Computed streamlines overlaid on WSS; discrete saved phases and orbiting camera.',fill='white',font_size=18)
  draw.text((20,688),'Exploratory repaired geometry, synthetic inflow. Software-rendered initial transient only.',fill='white',font_size=18)
  if frame==0:im.save(out/'preview.png')
  proc.stdin.write(im.tobytes())
finally:proc.stdin.close()
assert proc.wait()==0
probe=subprocess.run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(movie)],capture_output=True,text=True,check=True);(out/'ffprobe.json').write_text(probe.stdout)
metadata={'status':'INITIAL_TRANSIENT_DIAGNOSTIC_ONLY','saved_times_s':[x[0]['time_s'] for x in states],'duration_s':frames/fps,'fps':fps,'resolution':[width,height],'renderer':'Pillow software rasterization of actual VTK triangles; projected computed streamlines overlaid','content':'Actual saved U streamlines and instantaneous WSS multiplied once by rho; discrete saved phases and orbiting camera. No invented particle motion.','full_simulation_complete':False};(out/'metadata.json').write_text(json.dumps(metadata,indent=2));print(movie)
