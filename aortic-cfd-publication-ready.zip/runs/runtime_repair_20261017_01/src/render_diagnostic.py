"""Render saved initial-transient fields. This is not the final validated-cycle video."""
from pathlib import Path
import sys,json,importlib.util,subprocess
import numpy as np
import vtk
from vtk.util.numpy_support import vtk_to_numpy,numpy_to_vtk
from PIL import Image,ImageDraw
root=Path(sys.argv[1]).resolve();out=root/'results/initial_transient_video';out.mkdir(parents=True,exist_ok=False)
report=json.loads((root/'reports/saved_field_validation.json').read_text());assert report['status']=='SAVED_INITIAL_TRANSIENT_CHECKS_PASS'
spec=importlib.util.spec_from_file_location('analysis',root.parent/'mesh_repair_20261017_01/src/analyze_results.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
r=a.reader(root/'cfd/aorta');states=[]
for row in report['fields']:
 mesh,patches=a.fields(r,row['time_s']);wall=vtk.vtkPolyData();wall.DeepCopy(patches['aorta_wall'])
 stress=vtk_to_numpy(wall.GetCellData().GetArray('wallShearStress')).astype(float)*1060
 arr=numpy_to_vtk(np.linalg.norm(stress,axis=1),deep=True);arr.SetName('WSS_Pa');wall.GetCellData().AddArray(arr)
 w=vtk.vtkXMLPolyDataWriter();w.SetFileName(str(out.parent/f"wall_{row['time_s']:g}_diagnostic.vtp"));w.SetInputData(wall);assert w.Write()
 # Streamlines use the actual solved velocity, interpolated from cells to points.
 c=vtk.vtkCellDataToPointData();c.SetInputData(mesh);c.Update();c.GetOutput().GetPointData().SetActiveVectors('U')
 seeds=vtk.vtkPointSource();seeds.SetCenter(patches['aorta_inlet'].GetCenter());bounds=patches['aorta_inlet'].GetBounds();seeds.SetRadius(max(bounds[1]-bounds[0],bounds[3]-bounds[2])*.3);seeds.SetNumberOfPoints(70)
 stream=vtk.vtkStreamTracer();stream.SetInputData(c.GetOutput());stream.SetSourceConnection(seeds.GetOutputPort());stream.SetIntegratorTypeToRungeKutta4();stream.SetIntegrationDirectionToForward();stream.SetMaximumPropagation(.4);stream.SetInitialIntegrationStep(.2);stream.SetMinimumIntegrationStep(.01);stream.SetMaximumIntegrationStep(.5);stream.SetMaximumNumberOfSteps(4000);stream.Update()
 lines=vtk.vtkPolyData();lines.DeepCopy(stream.GetOutput());states.append((row,wall,lines))
from xml.sax.saxutils import escape
entries=''.join(f'<DataSet timestep="{row["time_s"]:.9g}" group="" part="0" file="wall_{row["time_s"]:g}_diagnostic.vtp"/>' for row,_,_ in states)
(out.parent/'diagnostic_wall_WSS_Pa.pvd').write_text('<?xml version="1.0"?><VTKFile type="Collection" version="0.1" byte_order="LittleEndian"><Collection>'+entries+'</Collection></VTKFile>')
ren=vtk.vtkRenderer();ren.SetBackground(.035,.05,.085)
win=vtk.vtkRenderWindow();win.SetOffScreenRendering(1);win.SetSize(1280,720);win.AddRenderer(ren)
lut=vtk.vtkLookupTable();lut.SetHueRange(.67,0);lut.SetRange(0,5);lut.Build()
wallmap=vtk.vtkPolyDataMapper();wallmap.SetScalarModeToUseCellFieldData();wallmap.SelectColorArray('WSS_Pa');wallmap.SetLookupTable(lut);wallmap.SetScalarRange(0,5)
actor=vtk.vtkActor();actor.SetMapper(wallmap);actor.GetProperty().SetOpacity(.62);ren.AddActor(actor)
linemap=vtk.vtkPolyDataMapper();linemap.ScalarVisibilityOff();la=vtk.vtkActor();la.SetMapper(linemap);la.GetProperty().SetColor(.65,.95,1);la.GetProperty().SetLineWidth(1.3);ren.AddActor(la)
bar=vtk.vtkScalarBarActor();bar.SetLookupTable(lut);bar.SetTitle('WSS (Pa)');bar.SetNumberOfLabels(6);bar.SetWidth(.11);bar.SetHeight(.56);bar.SetPosition(.86,.18);ren.AddActor2D(bar)
wallmap.SetInputData(states[0][1]);linemap.SetInputData(states[0][2]);ren.ResetCamera();cam=ren.GetActiveCamera();cam.Azimuth(25);cam.Elevation(10);cam.Zoom(1.1)
movie=out/'Initial_Transient_DIAGNOSTIC_720p.mp4';fps=15;frames=75
proc=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pixel_format','rgb24','-video_size','1280x720','-framerate',str(fps),'-i','-','-an','-c:v','libx264','-crf','20','-pix_fmt','yuv420p',str(movie)],stdin=subprocess.PIPE)
try:
 for frame in range(frames):
  row,wall,lines=states[min(frame*len(states)//frames,len(states)-1)];wallmap.SetInputData(wall);linemap.SetInputData(lines);cam.Azimuth(.45);win.Render()
  shot=vtk.vtkWindowToImageFilter();shot.SetInput(win);shot.SetInputBufferTypeToRGB();shot.ReadFrontBufferOff();shot.Update();pixels=vtk_to_numpy(shot.GetOutput().GetPointData().GetScalars()).reshape(720,1280,3)
  im=Image.fromarray(np.flipud(pixels));d=ImageDraw.Draw(im);d.rectangle((0,0,1280,90),fill=(12,18,30));d.text((20,12),'INITIAL TRANSIENT DIAGNOSTIC | No validated periodic cycle',fill='white',font_size=24)
  d.text((20,48),f"Solved time {row['time_s']:.7f} s | Peak speed {row['peak_speed_m_s']:.3f} m/s | WSS colors capped at 5 Pa",fill=(190,220,240),font_size=20)
  d.rectangle((0,666,1280,720),fill=(12,18,30));d.text((20,680),'Saved fields shown in discrete phases; camera orbits. Exploratory repaired geometry and synthetic inflow.',fill='white',font_size=18)
  if frame==0:im.save(out/'preview.png')
  proc.stdin.write(im.tobytes())
finally:proc.stdin.close()
assert proc.wait()==0
probe=subprocess.run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(movie)],capture_output=True,text=True,check=True);(out/'ffprobe.json').write_text(probe.stdout)
metadata={'status':'INITIAL_TRANSIENT_DIAGNOSTIC_ONLY','saved_times_s':[x[0]['time_s'] for x in states],'duration_s':frames/fps,'fps':fps,'resolution':[1280,720],'content':'Actual saved U streamlines and instantaneous WSS multiplied once by rho; discrete saved phases and orbiting camera. No invented particle motion.','full_simulation_complete':False};(out/'metadata.json').write_text(json.dumps(metadata,indent=2));print(movie)
