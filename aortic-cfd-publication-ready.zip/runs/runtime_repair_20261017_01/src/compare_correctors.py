from pathlib import Path
import sys,json,re
import numpy as np
first,second=map(lambda x:Path(x).resolve(),sys.argv[1:3]);t=float(sys.argv[3])
# Use the already-tested reader and native flux decoder.
sys.path.insert(0,str(first/'src'));import analyze_results as a
meshes=[];patchsets=[]
for root in [first,second]:
 reader=a.reader(root/'cfd/aorta');mesh,patches=a.fields(reader,t)
 v=type(mesh)();v.DeepCopy(mesh);meshes.append(v)
 wall=type(patches['aorta_wall'])();wall.DeepCopy(patches['aorta_wall']);patchsets.append(wall)
assert meshes[0].GetNumberOfCells()==meshes[1].GetNumberOfCells()
size=a.vtk.vtkCellSizeFilter();size.SetInputData(meshes[0]);size.Update();volume=a.vtk_to_numpy(size.GetOutput().GetCellData().GetArray('Volume'))
u=[a.vtk_to_numpy(m.GetCellData().GetArray('U')).astype(float) for m in meshes]
assert all(np.isfinite(x).all() for x in u)
l2=float(np.sqrt(np.sum(volume*np.sum((u[0]-u[1])**2,axis=1))/np.sum(volume*np.sum(u[0]**2,axis=1))))
maxdiff=float(np.linalg.norm(u[0]-u[1],axis=1).max())
wss=[]
for wall in patchsets:
 array=wall.GetCellData().GetArray('wallShearStress');assert array is not None
 wss.append(a.vtk_to_numpy(array).astype(float)*1060)
area=a.areas(patchsets[0]);tau_l2=float(np.sqrt(np.sum(area*np.sum((wss[0]-wss[1])**2,axis=1))/np.sum(area*np.sum(wss[0]**2,axis=1))))
result={'status':'EARLY_CORRECTOR_COMPARISON_PASS' if l2<.01 and tau_l2<.01 else 'EARLY_CORRECTOR_COMPARISON_FAIL','saved_time_s':t,'velocity_volume_weighted_relative_L2':l2,'maximum_velocity_difference_m_s':maxdiff,'WSS_area_weighted_relative_L2':tau_l2,'acceptance_relative_L2':.01,'interpretation':'One initial-transient checkpoint only. Does not establish full-cycle accuracy, time-step convergence or periodic WSS.'}
(second/'reports'/f'corrector_comparison_{t:g}.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));raise SystemExit(0 if result['status'].endswith('_PASS') else 1)
