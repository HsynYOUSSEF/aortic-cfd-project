from pathlib import Path
import numpy as np,re
s=Path(__file__).with_name('reconstruct_initial.py').read_text();s=s[:s.index('assert np.isfinite(ur)')];exec(s)
d=(root.parent.parent/'reports/original_invalid_U').read_bytes();m=re.search(rb'internalField\s+nonuniform\s+List<\w+>\s+(\d+)\s*\(',d);u=np.frombuffer(d,dtype='<f8',count=nc*3,offset=m.end()).reshape(-1,3)
inv=np.linalg.inv(tensor)
bad=rhs.copy()
for i in range(3):bad[:,i]=np.einsum('ij,ij->i',inv[:,i,:],bad)
print('alias error',np.max(abs(bad-u),axis=0), 'relative', np.max(abs(bad-u),axis=0)/np.max(abs(u),axis=0))
print('bad quantiles',np.quantile(np.linalg.norm(bad,axis=1),[0,.5,.99,1]))
print('samples',np.c_[u[:5],bad[:5]])
b=rhs.copy()
for ix in (np.arange(0,nc,2),np.arange(1,nc,2)):
 if ix[0]==0:
  b[ix,:2]=np.einsum('nij,nj->ni',inv[ix,:2,:],b[ix])
  b[ix,2]=np.einsum('ij,ij->i',inv[ix,2,:],b[ix])
 else:
  b[ix,0]=np.einsum('ij,ij->i',inv[ix,0,:],b[ix])
  b[ix,1:]=np.einsum('nij,nj->ni',inv[ix,1:,:],b[ix])
print('SIMD reuse hypothesis relative error',np.max(abs(b-u),axis=0)/np.max(abs(u),axis=0))
print('SIMD abs error',np.max(abs(b-u),axis=0))
