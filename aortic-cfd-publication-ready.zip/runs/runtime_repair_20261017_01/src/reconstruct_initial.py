from pathlib import Path
import re,json
import numpy as np
import sys
root=Path(sys.argv[1]).resolve()
def field(name,components):
 d=(root/'0'/name).read_bytes();m=re.search(rb'internalField\s+nonuniform\s+List<\w+>\s+(\d+)\s*\(',d);n=int(m[1]);a=np.frombuffer(d,dtype='<f8',count=n*components,offset=m.end()).reshape(n,components)
 print(name,'range',a.min(0),a.max(0),'magnitude quantiles',np.quantile(np.linalg.norm(a,axis=1),[0,.5,.99,.999,1]));print('largest indices',np.argsort(np.linalg.norm(a,axis=1))[-10:])
 return a
u=field('U',3);phi=field('phi',1)
boundary_phi=[]
for name in ['U','phi']:
 d=(root/'0'/name).read_bytes();start=d.index(b'boundaryField');d=d[start:]
 for patch in [b'aorta_inlet',b'aorta_outlet1',b'aorta_outlet2']:
  part=d[d.index(patch):];m=re.search(rb'value\s+nonuniform\s+List<(\w+)>\s+(\d+)\s*\(',part)
  if m:
   n=int(m[2]);c=3 if m[1]==b'vector' else 1;a=np.frombuffer(part,dtype='<f8',count=n*c,offset=m.end()).reshape(n,c);print(name,patch,'n',n,'range',a.min(0),a.max(0),'sum',a.sum(0))
   if name=='phi':boundary_phi.extend(a[:,0])
def readlist(data,dtype,start=0,components=1):
 m=re.search(rb'\n\s*(\d+)\s*\n\(',data[start:]);n=int(m[1]);pos=start+m.end();a=np.frombuffer(data,dtype=dtype,count=n*components,offset=pos).copy();return (a.reshape(-1,components) if components>1 else a),pos+a.nbytes
mesh=root/'constant/polyMesh'
points,_=readlist((mesh/'points').read_bytes(),'<f8',components=3)
d=(mesh/'faces').read_bytes();offset,end=readlist(d,'<i4');flat,_=readlist(d,'<i4',end);assert np.all(np.diff(offset)==3);faces=flat.reshape(-1,3)
own,_=readlist((mesh/'owner').read_bytes(),'<i4');nei,_=readlist((mesh/'neighbour').read_bytes(),'<i4');ni=len(nei);nc=len(u)
sf=np.cross(points[faces[:,1]]-points[faces[:,0]],points[faces[:,2]]-points[faces[:,0]])*.5;mag=np.linalg.norm(sf,axis=1)
phiall=np.r_[phi[:,0],np.zeros(len(own)-ni-len(boundary_phi)),boundary_phi]
def both(a):return np.bincount(own,weights=a,minlength=nc)+np.bincount(nei,weights=a[:ni],minlength=nc)
tensor=np.empty((nc,3,3))
for i in range(3):
 for j in range(3):tensor[:,i,j]=both(sf[:,i]*sf[:,j]/mag)
rhs=np.column_stack([both(sf[:,i]*phiall/mag) for i in range(3)])
ur=np.linalg.solve(tensor,rhs[:,:,None])[:,:,0]
print('Independent reconstruction quantiles',np.quantile(np.linalg.norm(ur,axis=1),[0,.5,.99,.999,1]))
print('Component error',np.max(abs(ur-u),axis=0))
assert np.isfinite(ur).all()
assert np.max(np.linalg.norm(ur,axis=1)) < 10
f=root/'0/U'
d=f.read_bytes()
m=re.search(rb'internalField\s+nonuniform\s+List<\w+>\s+(\d+)\s*\(',d)
assert int(m[1])==len(ur)
original=root.parent.parent/'reports/original_invalid_U'
assert not original.exists()
original.write_bytes(d)
d=d[:m.end()]+np.asarray(ur,dtype='<f8').tobytes()+d[m.end()+ur.nbytes:]
bound=(mesh/'boundary').read_text()
for patch in ['aorta_outlet1','aorta_outlet2']:
 block=re.search(patch+r'\s*\{([^}]+)',bound)[1]
 start=int(re.search(r'startFace\s+(\d+)',block)[1]);count=int(re.search(r'nFaces\s+(\d+)',block)[1])
 begin=d.index(patch.encode(),d.index(b'boundaryField'))
 pm=re.search(rb'value\s+nonuniform\s+List<vector>\s+(\d+)\s*\(',d[begin:]);assert int(pm[1])==count
 offset=begin+pm.end();values=np.asarray(ur[own[start:start+count]],dtype='<f8')
 d=d[:offset]+values.tobytes()+d[offset+values.nbytes:]
f.write_bytes(d)
report={'method':'Oriented face flux least-squares reconstruction, NumPy solve', 'max_initial_speed_m_s':float(np.linalg.norm(ur,axis=1).max()), 'median_initial_speed_m_s':float(np.median(np.linalg.norm(ur,axis=1))), 'max_equation_residual':float(np.max(abs(np.einsum('nij,nj->ni',tensor,ur)-rhs))), 'status':'INITIALIZATION_REPAIRED_ONLY'}
(root.parent.parent/'reports/initialization.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
