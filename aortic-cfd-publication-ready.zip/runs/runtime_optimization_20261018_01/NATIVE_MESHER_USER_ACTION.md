# Native Linux mesher

The installed OpenFOAM tools run, but Gmsh's native Linux library/Python module are absent. The old preparation runtime contains a Windows DLL, which cannot run as a Linux meshing library. Local Ubuntu package metadata lists gmsh and python3-gmsh4.12.1+ds1-1.1build2.

To enable a boundary-fitted coarse-mesh attempt, run in an ordinary Ubuntu terminal:

```bash
sudo apt update
sudo apt install gmsh python3-gmsh
/usr/bin/python3 -c 'import gmsh; print(gmsh.__version__)'
```

Then report whether the import succeeds. This session cannot perform administrator installation or enable networking through its managed policy. No relay, sandbox override, or alternate network transport is used. Installation does not start a solver or modify existing cases. Future coarse candidates will be new cases and must pass the same native mesh, initial-field, flow, WSS and periodicity gates.
