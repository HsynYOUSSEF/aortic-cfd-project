"""Bounded two-case 0.01->0.05 s comparison; never launches a long run."""
from pathlib import Path
import sys,os,re,json,shutil,time,subprocess,hashlib,fcntl,signal,math
import numpy as np
ROOT=Path(__file__).resolve().parents[1];PROJECT=ROOT.parents[1];SOURCE=Path('/tmp/aortic_coarse_startup_20261018_03');SRCCASE=SOURCE/'cfd/aorta';BASE=ROOT/'archive/slow_run_complete'
LOCK=open(ROOT/'.benchmark.lock','a');fcntl.flock(LOCK,fcntl.LOCK_EX|fcntl.LOCK_NB)
WORK=Path('/tmp/aortic_outer_validation_20261018_01');WORK.mkdir(exist_ok=False);(ROOT/'OUTER_VALIDATION_DIRECTORY.txt').write_text(str(WORK)+'\n');(WORK/'logs').mkdir();(WORK/'reports').mkdir()
for src in [BASE/'src/analyze_results.py',BASE/'src/validate_saved_fields.py',BASE/'src/watch_run.py']:shutil.copy2(src,WORK/'src') if (WORK/'src').exists() else None
(WORK/'src').mkdir(exist_ok=True)
for src in [BASE/'src/analyze_results.py',BASE/'src/validate_saved_fields.py',BASE/'src/watch_run.py']:shutil.copy2(src,WORK/'src'/src.name)
os.environ.update(WM_PROJECT_DIR='/usr/share/openfoam',FOAM_ETC='/usr/share/openfoam/etc',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
rows=[]
def run(cmd,log,env=None,timeout=1500):
 with open(log,'w') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env,timeout=timeout)
 if p.returncode:raise RuntimeError(f'{cmd} returned {p.returncode}; see {log}')
for name,nouter in [('two_outer',2),('one_outer',1)]:
 case=WORK/name/'cfd/aorta';case.parent.mkdir(parents=True);case.mkdir();(WORK/name/'src').mkdir();(WORK/name/'reports').mkdir()
 shutil.copy2(WORK/'src/analyze_results.py',WORK/name/'src/analyze_results.py')
 for d in ['constant','system','0','0.01']:shutil.copytree(SRCCASE/d,case/d)
 (case/'aorta.foam').touch();p=case/'system/fvSolution';s=p.read_text();s,n=re.subn(r'nOuterCorrectors\s+\d+;',f'nOuterCorrectors {nouter};',s);assert n==1;p.write_text(s)
 p=case/'system/controlDict';s=p.read_text()
 for k,v in {'startFrom':'latestTime','stopAt':'endTime','endTime':'.05','deltaT':'1e-5','adjustTimeStep':'yes','maxCo':'.7','maxDeltaT':'.0002','writeControl':'adjustableRunTime','writeInterval':'.002','purgeWrite':'0'}.items():s,n=re.subn(r'\b'+k+r'\s+[^;]+;',k+' '+v+';',s);assert n==1
 p.write_text(s);(case/'system/decomposeParDict').unlink(missing_ok=True)
 (WORK/name/'run_config.json').write_text((SOURCE/'run_config.json').read_text().replace('"end_time_s": 0.01','"end_time_s": 0.05'))
 start=time.monotonic();log=WORK/'logs'/f'{name}_solver.log';stream=open(log,'w');proc=subprocess.Popen(['pimpleFoam','-case',str(case),'-noFunctionObjects'],stdout=stream,stderr=subprocess.STDOUT,start_new_session=True);samples=[];last=None;progress=start
 try:
  while proc.poll() is None:
   try:
    stat=Path(f'/proc/{proc.pid}/stat').read_text().split();rss=int(re.search(r'VmRSS:\s+(\d+)',Path(f'/proc/{proc.pid}/status').read_text())[1]);samples.append({'elapsed_s':time.monotonic()-start,'cpu_s':(int(stat[13])+int(stat[14]))/os.sysconf('SC_CLK_TCK'),'rss_kib':rss})
   except (FileNotFoundError,TypeError):pass
   stream.flush();txt=log.read_text(errors='replace')[-150000:];ts=re.findall(r'^Time =\s*(\S+)',txt,re.M);t=float(ts[-1]) if ts else None
   if t is not None and (last is None or t>last+1e-12):last=t;progress=time.monotonic()
   cos=[float(x) for x in re.findall(r'Courant Number mean: \S+ max: (\S+)',txt)]
   reason='CFL threshold' if cos and max(cos)>1 else 'linear iteration cap' if re.search(r'No Iterations (?:1000|[1-9][0-9]{4,})\b',txt) else None
   if reason:os.killpg(proc.pid,signal.SIGTERM);proc.wait();raise RuntimeError(f'{name}: {reason}; case retained')
   if time.monotonic()-progress>300:os.killpg(proc.pid,signal.SIGTERM);proc.wait();raise RuntimeError(f'{name}: no time progress; case retained')
   if time.monotonic()-start>1200:os.killpg(proc.pid,signal.SIGTERM);proc.wait();raise RuntimeError(f'{name}: bounded 20min wall limit reached')
   time.sleep(2)
 finally:
  stream.close()
 elapsed=time.monotonic()-start;txt=log.read_text(errors='replace');assert proc.returncode==0 and re.search(r'^End\s*$',txt,re.M) and abs(last-.05)<1e-8
 co=[float(x) for x in re.findall(r'Courant Number mean: \S+ max: (\S+)',txt)];assert co and max(co)<1
 env=os.environ.copy();env['LD_PRELOAD']=str(BASE/'src/libsha1_compat.so');run(['pimpleFoam','-case',str(case),'-postProcess','-func','wallShearStress','-time','.01:.05'],WORK/'logs'/f'{name}_WSS.log',env)
 run([sys.executable,str(WORK/'src/validate_saved_fields.py'),str(WORK/name),'--require-end','.05','--minimum-times','21','--minimum-time','.01','--report-name','saved_validation.json'],WORK/'logs'/f'{name}_validation.log')
 val=json.loads((WORK/name/'reports/saved_validation.json').read_text());disk=sum(x.stat().st_size for x in (WORK/name).rglob('*') if x.is_file());rows.append({'name':name,'nOuterCorrectors':nouter,'case':str(case),'simulated_from_s':.01,'to_s':.05,'wall_s':elapsed,'cpu_core_percent':100*samples[-1]['cpu_s']/samples[-1]['elapsed_s'],'peak_rss_MiB':max(x['rss_kib'] for x in samples)/1024,'max_Courant':max(co),'max_time_saved_field_bytes':max((case/t/'U').stat().st_size+(case/t/'p').stat().st_size+(case/t/'phi').stat().st_size+(case/t/'wallShearStress').stat().st_size for t in ['0.012','0.02','0.05'] if all((case/t/f).exists() for f in ['U','p','phi','wallShearStress'])),'case_total_bytes':disk,'validation':val,'status':'SAVED_FIELDS_FLOW_WSS_PASS','cpu_samples':samples});(ROOT/'reports/OUTER_VALIDATION_005.json').write_text(json.dumps(rows,indent=2));print(json.dumps({k:v for k,v in rows[-1].items() if k not in ['cpu_samples','validation']}),flush=True)
# Compare 21 matched phases in the overlapping tail (.03-.05 s).
sys.path.insert(0,str(WORK/'src'));from analyze_results import reader,fields,areas
from vtk.util.numpy_support import vtk_to_numpy
cases=[WORK/n/'cfd/aorta' for n in ['two_outer','one_outer']];rs=[reader(c) for c in cases];weighted={n:[0.,0.] for n in ['U','p','WSS']};phases=np.linspace(.03,.05,11)
for t in phases:
 loaded=[]
 for r in rs:
  m,b=fields(r,t);wall=b['aorta_wall'];size=__import__('vtk').vtkCellSizeFilter();size.SetInputData(m);size.Update();vol=vtk_to_numpy(size.GetOutput().GetCellData().GetArray('Volume'));wa=areas(wall);loaded.append((m,wall,vol,wa))
 a,b=loaded;assert a[0].GetNumberOfCells()==b[0].GetNumberOfCells() and a[1].GetNumberOfCells()==b[1].GetNumberOfCells()
 for n,x,y,w in [('U',a[0].GetCellData().GetArray('U'),b[0].GetCellData().GetArray('U'),a[2]),('p',a[0].GetCellData().GetArray('p'),b[0].GetCellData().GetArray('p'),a[2]),('WSS',a[1].GetCellData().GetArray('wallShearStress'),b[1].GetCellData().GetArray('wallShearStress'),a[3])]:
  x=vtk_to_numpy(x).astype(float);y=vtk_to_numpy(y).astype(float)*(1060 if n=='WSS' else 1);x=x*(1060 if n=='WSS' else 1);d=np.sum((x-y)**2,axis=1) if x.ndim==2 else (x-y)**2;q=np.sum(x*x,axis=1) if x.ndim==2 else x*x;weighted[n][0]+=float(np.dot(w,d));weighted[n][1]+=float(np.dot(w,q))
compare={n:float(np.sqrt(v[0]/v[1])) for n,v in weighted.items()};report={'status':'COMPLETED_BOUNDED_VALIDATION','phases_s':phases.tolist(),'relative_L2_one_outer_vs_two_outer':compare,'threshold_screen':.01,'interpretation':'Short transient comparison only. This is not cycle validation or authorization to launch a long run.','runs':[{k:v for k,v in x.items() if k not in ['cpu_samples','validation']} for x in rows]};(ROOT/'reports/OUTER_VALIDATION_005_COMPARISON.json').write_text(json.dumps(report,indent=2));(ROOT/'reports/OUTER_VALIDATION_005_COMPLETE').write_text('completed\n');print(json.dumps(report,indent=2),flush=True)
