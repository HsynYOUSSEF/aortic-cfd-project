"""User-run normal Ubuntu terminal only. Bounded MPI tests; never launches a long run."""
from pathlib import Path
import os,sys,re,json,time,tempfile,subprocess,shutil,fcntl
ROOT=Path(__file__).resolve().parents[1]
lock=open(ROOT/'.benchmark.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
os.environ.update(WM_PROJECT_DIR='/usr/share/openfoam',FOAM_ETC='/usr/share/openfoam/etc',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
# Respect existing permissions. Failure stops here, no transport or sandbox workaround.
subprocess.run(['mpirun','-np','2','hostname'],check=True,timeout=30)
WORK=Path(tempfile.mkdtemp(prefix='aortic_mpi_benchmark_',dir='/tmp'));stamp=WORK.name
(ROOT/(stamp+'_DIRECTORY.txt')).write_text(str(WORK)+'\n')
SRC=ROOT/'archive/slow_run_complete/cfd/aorta'
sys.path.insert(0,str(ROOT/'archive/slow_run_complete/src'))
from analyze_results import reader,fields,areas,patch_flux
from vtk.util.numpy_support import vtk_to_numpy
import numpy as np
baseline=None;results=[]
def cmd(args,log,env=None):
 with open(log,'w') as f:
  subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,timeout=900,check=True,env=env)
for ranks in [1,2,4,8]:
 case=WORK/f'ranks_{ranks}';case.mkdir();logs=WORK/f'logs_{ranks}';logs.mkdir()
 for d in ['constant','system','0.01']:shutil.copytree(SRC/d,case/d)
 (case/'aorta.foam').touch();p=case/'system/controlDict';s=p.read_text()
 for key,val in {'stopAt':'endTime','endTime':'.01028','deltaT':'.00007','adjustTimeStep':'no','writeControl':'timeStep','writeInterval':'1'}.items():s,n=re.subn(r'\b'+key+r'\s+[^;]+;',key+' '+val+';',s);assert n==1
 p.write_text(s+'\nprofiling { enabled true; sysInfo true; }\n')
 if ranks>1:
  (case/'system/decomposeParDict').write_text('FoamFile {version 2.0;format ascii;class dictionary;object decomposeParDict;}\nnumberOfSubdomains '+str(ranks)+';method scotch;\n')
  cmd(['decomposePar','-case',str(case),'-latestTime'],logs/'decompose.log')
 args=['pimpleFoam','-case',str(case),'-noFunctionObjects']
 if ranks>1:args=['mpirun','-np',str(ranks)]+args+['-parallel']
 start=time.monotonic();cmd(['/usr/bin/time','-v']+args,logs/'solver.log');elapsed=time.monotonic()-start
 if ranks>1:cmd(['reconstructPar','-case',str(case),'-latestTime'],logs/'reconstruct.log')
 txt=(logs/'solver.log').read_text();assert 'End' in txt and 'FOAM FATAL' not in txt and not re.search(r'\bnan\b',txt,re.I)
 env=os.environ.copy();env['LD_PRELOAD']=str(ROOT/'archive/slow_run_complete/src/libsha1_compat.so');cmd(['pimpleFoam','-case',str(case),'-postProcess','-func','wallShearStress','-latestTime'],logs/'WSS.log',env)
 r=reader(case);m,b=fields(r,.01028);arrays=[vtk_to_numpy(m.GetCellData().GetArray(n)).copy() for n in ['U','p']]+[vtk_to_numpy(b['aorta_wall'].GetCellData().GetArray('wallShearStress')).copy()*1060]
 assert all(np.isfinite(x).all() for x in arrays)
 q=[patch_flux(case/'0.01028/phi',n,b[n].GetNumberOfCells()) for n in ['aorta_inlet','aorta_outlet1','aorta_outlet2']];imbalance=abs(sum(q))/abs(q[0]);inlet=abs(-q[0]-(5e-5+3.5e-5*np.sin(2*np.pi*.01028)))/(5e-5+3.5e-5*np.sin(2*np.pi*.01028));assert imbalance<.005 and inlet<.01
 if baseline is None:baseline=arrays
 changes=[float(np.linalg.norm(x-y)/np.linalg.norm(y)) for x,y in zip(arrays,baseline)]
 # reconstruction must retain global cell/face addressing; compare cell centers explicitly if changed runtime
 assert all(z<.01 for z in changes),'MPI field comparison exceeds1%; retain failure and investigate'
 row={'ranks':ranks,'case':str(case),'solver_wall_s':elapsed,'simulated_s':.00028,'flow_imbalance':imbalance,'inlet_error':inlet,'relative_L2_U_p_WSS':changes,'status':'SHORT_WINDOW_PASS_ONLY'};results.append(row)
 (ROOT/(stamp+'_RESULTS.json')).write_text(json.dumps(results,indent=2));print(json.dumps(row),flush=True)
print('Bounded MPI tests complete. No long simulation launched. Results:',ROOT/(stamp+'_RESULTS.json'))
