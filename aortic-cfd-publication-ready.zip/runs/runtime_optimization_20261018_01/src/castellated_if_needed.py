from pathlib import Path
import sys,time,json,subprocess
ROOT=Path(__file__).resolve().parents[1]
for _ in range(120):
 if (ROOT/'reports/COARSE_SOLVER_BENCHMARK_COMPLETE').exists():break
 time.sleep(30)
else:raise RuntimeError('Benchmarks incomplete: no alternate meshing')
mesh=json.loads((ROOT/'reports/COARSE_MESH.json').read_text())
if mesh['status']=='PASS':sys.exit(0)
# New geometry approximation in a new case, never a weakened mesh gate.
subprocess.run([sys.executable,str(ROOT/'src/prepare_coarse_castellated.py')],check=True)
print('Alternate full mesh gate passed. No solver automatically launched; geometry error needs review.',flush=True)
