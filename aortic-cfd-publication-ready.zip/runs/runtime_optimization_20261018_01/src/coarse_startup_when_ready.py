from pathlib import Path
import time,sys,json,subprocess,shutil,fcntl,re,os
ROOT=Path(__file__).resolve().parents[1]
for _ in range(120):
 if (ROOT/'reports/COARSE_SOLVER_BENCHMARK_COMPLETE').exists():break
 time.sleep(30)
else:raise RuntimeError('Preceding bounded benchmarks incomplete; no coarse startup launched')
mesh=json.loads((ROOT/'reports/COARSE_MESH.json').read_text())
if mesh['status']!='PASS':raise RuntimeError('Mesh gate failed; no coarse flow solver launched')
# Cross-check generalized polygon algebra against established triangular reconstruction.
lock=open(ROOT/'.benchmark.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
work=Path('/tmp/aortic_poly_reconstruction_crosscheck_20261018_01');case=work/'cfd/aorta';case.mkdir(parents=True,exist_ok=False);(work/'reports').mkdir();source=ROOT/'archive/slow_run_complete/cfd/aorta'
for d in ['constant','0']:shutil.copytree(source/d,case/d)
with open(ROOT/'logs/poly_crosscheck.log','w') as f:p=subprocess.run([sys.executable,str(ROOT/'src/reconstruct_poly_initial.py'),str(case)],stdout=f,stderr=subprocess.STDOUT,timeout=300)
assert p.returncode==0,'General reconstruction cross-check failed; no coarse solver'
import numpy as np
def u(path):
 d=path.read_bytes();m=re.search(rb'internalField\s+nonuniform\s+List<vector>\s+(\d+)\s*\(',d);return np.frombuffer(d,dtype='<f8',count=int(m[1])*3,offset=m.end()).copy()
a=u(source/'0/U');b=u(case/'0/U');err=float(np.max(abs(a-b)));rel=float(np.linalg.norm(a-b)/np.linalg.norm(a));r={'status':'PASS' if err<1e-10 and rel<1e-10 else 'FAIL','max_component_error_m_s':err,'relative_L2':rel,'case':str(case)};(ROOT/'reports/POLY_RECONSTRUCTION_CROSSCHECK.json').write_text(json.dumps(r,indent=2));assert r['status']=='PASS',r
fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
with open(ROOT/'logs/coarse_startup_controller.log','w') as f:p=subprocess.run([sys.executable,str(ROOT/'src/coarse_startup.py')],stdout=f,stderr=subprocess.STDOUT)
(ROOT/'reports/COARSE_STARTUP_STAGE.json').write_text(json.dumps({'returncode':p.returncode,'status':'COMPLETED_BOUNDED_TEST' if p.returncode==0 else 'FAILED_RETAINED','log':str(ROOT/'logs/coarse_startup_controller.log'),'long_run_launched':False},indent=2));sys.exit(p.returncode)
