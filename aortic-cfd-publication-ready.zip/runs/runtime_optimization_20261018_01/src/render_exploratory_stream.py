"""Stream actual saved CFD snapshots into a labelled 1080p particle/WSS video."""
from pathlib import Path
import sys, json, subprocess, shutil, re, math
import numpy as np
import vtk
from vtk.util.numpy_support import vtk_to_numpy, numpy_to_vtk

PROJECT=Path('/mnt/c/Users/Admin/Desktop/Aortic_Repaired_Simulation_20261015')
WORK=Path('/tmp/aortic_exploratory_demo_20261018_01')
CASE=WORK/'cfd/aorta'; OUT=WORK/'results/video_1080p_transient'
if OUT.exists(): raise FileExistsError(OUT)
if not shutil.which('ffmpeg'): raise RuntimeError('ffmpeg missing')

sys.path.insert(0,str(WORK/'src'))
import analyze_results as analysis
reader=analysis.reader(CASE)
times=vtk_to_numpy(reader.GetTimeValues()).astype(float)
times=times[(times>=.01-1e-8)&(times<=3+1e-8)]
expected=np.round(np.arange(.01,3.0001,.01),8)
if len(times)!=300 or not np.allclose(times,expected,atol=1e-7):
    raise RuntimeError(f'Expected exactly 300 actual saved states at .01 s cadence; got {len(times)}')

# Read the static mesh, inlet triangles, wall centres and all actual output snapshots.
velocities=[]; wss=[]; wall_centres=None; wall_ref=None; inlet=None; mesh_ref=None
centres_filter=vtk.vtkCellCenters()
for j,t in enumerate(times):
    mesh,patches=analysis.fields(reader,float(t))
    u=mesh.GetCellData().GetArray('U')
    tau=patches['aorta_wall'].GetCellData().GetArray('wallShearStress')
    if u is None or tau is None: raise RuntimeError(f'Missing computed U/WSS at saved state {t:g}')
    U=vtk_to_numpy(u).astype(np.float32,copy=True)
    T=vtk_to_numpy(tau).astype(np.float32,copy=True)*1060.
    if not np.isfinite(U).all() or not np.isfinite(T).all(): raise RuntimeError(f'Non-finite fields at {t:g}')
    if mesh_ref is None:
        mesh_ref=vtk.vtkUnstructuredGrid();mesh_ref.DeepCopy(mesh)
        wall_ref=vtk.vtkPolyData();wall_ref.DeepCopy(patches['aorta_wall'])
        centres_filter.SetInputData(wall_ref);centres_filter.Update()
        wall_centres=vtk_to_numpy(centres_filter.GetOutput().GetPoints().GetData()).astype(float)
        inlet=vtk.vtkPolyData();inlet.DeepCopy(patches['aorta_inlet'])
    elif mesh.GetNumberOfCells()!=mesh_ref.GetNumberOfCells() or T.shape[0]!=wall_ref.GetNumberOfCells():
        raise RuntimeError('Mesh or wall topology changed during run')
    velocities.append(U);wss.append(T)
velocities=np.asarray(velocities,dtype=np.float32);wss=np.asarray(wss,dtype=np.float32)

# Set orthographic projection from the actual wall geometry.
wp=vtk_to_numpy(wall_ref.GetPoints().GetData()).astype(float)
az,el=np.deg2rad([-65.,8.])
right=np.array([-np.sin(az),np.cos(az),0]); up=np.array([-np.sin(el)*np.cos(az),-np.sin(el)*np.sin(az),np.cos(el)])
center=(wp.min(axis=0)+wp.max(axis=0))/2
projwall=np.column_stack(((wall_centres-center)@right,(wall_centres-center)@up))
W,H=1920,1080
scale=min(660/max(np.ptp(projwall[:,0]),1e-9),760/max(np.ptp(projwall[:,1]),1e-9))
def project(x):
    q=np.asarray(x)-center
    return np.column_stack((470+scale*(q@right),565-scale*(q@up)))
wallxy=np.rint(project(wall_centres)).astype(int)

# Explicit inlet sampling: particles originate on the inflow patch, then move using one actual .01 s snapshot per step.
triangulate=vtk.vtkTriangleFilter();triangulate.SetInputData(inlet);triangulate.Update();tri=triangulate.GetOutput()
ip=vtk_to_numpy(tri.GetPoints().GetData()); tris=np.array([[tri.GetCell(i).GetPointId(k) for k in range(3)] for i in range(tri.GetNumberOfCells())])
xyz=ip[tris]; weights=np.linalg.norm(np.cross(xyz[:,1]-xyz[:,0],xyz[:,2]-xyz[:,0]),axis=1);weights/=weights.sum()
rng=np.random.default_rng(20261018);N=1200
def inject(n):
    v=xyz[rng.choice(len(xyz),n,p=weights)]; s=np.sqrt(rng.random(n));b=rng.random(n)
    p=(1-s)[:,None]*v[:,0]+(s*(1-b))[:,None]*v[:,1]+(s*b)[:,None]*v[:,2]
    p[:,2]-=.0006
    return p
pos=inject(N)

# Reuse the static grid and update its cell-centred velocity with each exact saved field for probing.
grid=vtk.vtkUnstructuredGrid();grid.DeepCopy(mesh_ref)
grid.GetCellData().RemoveArray('U')
probe_points=vtk.vtkPoints();probe_points.SetDataTypeToDouble();cloud=vtk.vtkPolyData();cloud.SetPoints(probe_points)
probe=vtk.vtkProbeFilter();probe.SetInputData(cloud);probe.SetSourceData(grid);probe.SetComputeTolerance(False);probe.SetTolerance(1e-8)
def sample(U,x):
    arr=numpy_to_vtk(np.ascontiguousarray(U),deep=True);arr.SetName('U');grid.GetCellData().RemoveArray('U');grid.GetCellData().AddArray(arr);grid.Modified()
    probe_points.SetData(numpy_to_vtk(np.ascontiguousarray(x,dtype=np.float64),deep=True));probe_points.Modified();cloud.Modified();probe.Update()
    pd=probe.GetOutput().GetPointData();v=vtk_to_numpy(pd.GetArray('U')).copy();valid=vtk_to_numpy(pd.GetArray('vtkValidPointMask')).astype(bool)
    return v,valid

stops=np.array([[62,115,232],[0,205,226],[77,221,137],[247,202,68],[248,76,66]],dtype=np.float32)
def color(values,maximum):
    f=np.clip(values/max(maximum,1e-12),0,1)*4;k=np.minimum(f.astype(int),3);w=(f-k)[:,None]
    return (stops[k]*(1-w)+stops[k+1]*w).astype(np.uint8)
def scatter(img,xy,rgb,radius=1):
    x=xy[:,0];y=xy[:,1];ok=(x>=radius)&(x<W-radius)&(y>=radius)&(y<H-radius)
    x=x[ok];y=y[ok];c=rgb[ok]
    for dy in range(-radius,radius+1):
      for dx in range(-radius,radius+1):
        if dx*dx+dy*dy<=radius*radius+0.25:img[y+dy,x+dx]=c

wall_center=np.array(wallxy);wallcolors_base=np.zeros((len(wallxy),3),np.uint8)
OUT.mkdir(parents=True)
movie=OUT/'Aortic_Exploratory_Transient_1080p.mp4'
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
filters=(f"drawtext=fontfile={font}:text='EXPLORATORY TRANSIENT - NOT PERIODIC':fontcolor=white:fontsize=32:x=80:y=35:box=1:boxcolor=0x081422CC:boxborderw=10,"
         f"drawtext=fontfile={font}:text='WSS: UNVALIDATED COARSE MESH RESULTS':fontcolor=0xFFB080:fontsize=25:x=80:y=88:box=1:boxcolor=0x081422CC:boxborderw=8,"
         f"drawtext=fontfile={font}:text='300 computed snapshots at 0.01 s cadence | 3.0 simulated seconds shown at 10x slow playback | no cycle replay':fontcolor=0xD4E8F5:fontsize=20:x=80:y=1005:box=1:boxcolor=0x081422CC:boxborderw=7,"
         f"drawtext=fontfile={font}:text='Particles: speed (m/s) | Wall points: instantaneous WSS (Pa), scale 0-0.8':fontcolor=0xD4E8F5:fontsize=20:x=1050:y=145:box=1:boxcolor=0x081422CC:boxborderw=7")
cmd=['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r','10','-i','-','-vf',filters,'-an','-c:v','libx264','-preset','ultrafast','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(movie)]
log=(OUT/'encoding.log').open('wb');enc=subprocess.Popen(cmd,stdin=subprocess.PIPE,stderr=log)
counts=[];last_valid=0
try:
    for frame,(t,U,T) in enumerate(zip(times,velocities,wss)):
        # A one-time point cloud shell with actual wall locations and phase-specific WSS colours.
        image=np.empty((H,W,3),dtype=np.uint8);image[:]=[8,20,34]
        mag=np.linalg.norm(T,axis=1);wc=color(mag,.8)
        scatter(image,wall_center,wc,1)
        vel,valid=sample(U,pos)
        counts.append(int(valid.sum()));last_valid=int(valid.sum())
        if frame==0 and last_valid<N*.5:raise RuntimeError(f'Only {last_valid}/{N} tracers are inside the mesh at start')
        pxy=np.rint(project(pos)).astype(int);pc=color(np.linalg.norm(vel,axis=1),1.0);scatter(image,pxy[valid],pc[valid],2)
        # Directly advance one saved interval using only the velocity at the exact current snapshot; no temporal interpolation.
        pos=pos+vel.astype(float)*.01
        invalid=~valid | (pos[:,2]<-.4199)
        if invalid.any():pos[invalid]=inject(int(invalid.sum()))
        enc.stdin.write(image.tobytes())
        if frame%50==0:print(f'encoded snapshot {frame+1}/{len(times)} at t={t:.2f}s; valid particles={last_valid}',flush=True)
    enc.stdin.close()
    rc=enc.wait()
    if rc:raise RuntimeError(f'ffmpeg exited {rc}; see {OUT/"encoding.log"}')
finally:
    if enc.poll() is None:enc.kill();enc.wait()
    log.close()
probe=subprocess.run(['ffprobe','-v','error','-show_entries','stream=codec_type,width,height,r_frame_rate,nb_frames','-show_entries','format=duration','-of','json',str(movie)],capture_output=True,text=True,check=True)
info=json.loads(probe.stdout);(OUT/'ffprobe.json').write_text(json.dumps(info,indent=2)+'\n')
stream=next(x for x in info['streams'] if x.get('codec_type')=='video')
assert (int(stream['width']),int(stream['height']),stream['r_frame_rate'],int(stream['nb_frames']))==(1920,1080,'10/1',300)
assert abs(float(info['format']['duration'])-30)<.1
metadata={'status':'PASS_VIDEO_DECODE_METADATA','resolution':[1920,1080],'fps':10,'frames':300,'video_duration_s':30,'simulated_time_shown_s':[.01,3.0],'time_scale':'10x slowed playback','cycle_replay':'none; all 300 actual saved snapshots are shown once','saved_snapshot_interval_s':.01,'flow_interpolation':'none; each frame colors particles and wall from the actual saved snapshot; particle positions advance using the current saved velocity held over one .01 s interval','particle_count':N,'minimum_valid_particles':min(counts),'WSS':'Unvalidated coarse-mesh values from actual saved wallShearStress fields, multiplied once by rho=1060 kg/m3','periodicity':'phase-resolved successive-cycle gate failed; explicitly transient','mesh_accuracy':'not established; coarse/fine startup differences remain large'}
(OUT/'render_details.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps(metadata,indent=2))
