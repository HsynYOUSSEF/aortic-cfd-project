from pathlib import Path
import json,re,sys
import numpy as np,vtk
from vtk.util.numpy_support import vtk_to_numpy
from scipy.spatial import cKDTree
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'archive/slow_run_complete/src'));from analyze_results import reader,fields,areas
rows=json.loads((ROOT/'reports/BENCHMARKS.json').read_text())
if (ROOT/'reports/COARSE_SOLVER_BENCHMARKS.json').exists():rows+=json.loads((ROOT/'reports/COARSE_SOLVER_BENCHMARKS.json').read_text())
def centers(mesh):
 c=vtk.vtkCellCenters();c.SetInputData(mesh);c.Update();return vtk_to_numpy(c.GetOutput().GetPoints().GetData()).copy()
def data(case):
 r=reader(Path(case));m,b=fields(r,.01028);w=b['aorta_wall'];s=vtk.vtkCellSizeFilter();s.SetInputData(m);s.Update()
 return centers(m),centers(w),[vtk_to_numpy(m.GetCellData().GetArray(n)).copy() for n in ['U','p']]+[vtk_to_numpy(w.GetCellData().GetArray('wallShearStress')).copy()],vtk_to_numpy(s.GetOutput().GetCellData().GetArray('Volume')).copy(),areas(w)
base=next(x for x in rows if x['name']=='baseline');a=data(base['case']);ren=next(x for x in rows if x['name']=='renumber');b=data(ren['case']);maps=[]
for c,d in zip(a[:2],b[:2]):
 dist,idx=cKDTree(c).query(d);assert dist.max()<1e-10 and len(np.unique(idx))==len(c);maps.append(idx)
changes={}
for n,x,y,idx,wt in zip(['velocity','pressure','WSS'],b[2],a[2],[maps[0],maps[0],maps[1]],[b[3],b[3],b[4]]):
 y=y[idx];sq=lambda z:np.sum(z*z,axis=1) if z.ndim==2 else z*z
 changes[n+'_relative_L2']=float(np.sqrt(np.average(sq(x-y),weights=wt)/np.average(sq(y),weights=wt)))
ren['startup_sensitivity']=changes;ren['mapping']='Bijective nearest cell/face centroid mapping; max distance <1e-10m'
for row in rows:
 path=Path(row['case'])/'0.01028/uniform/profiling';s=path.read_text();entries={}
 for block in re.findall(r'trigger\d+\s*\{([^}]+)\}',s):
  name=re.search(r'description\s+"([^"]+)"',block)[1];entries[name]={k:float(re.search(k+r'\s+([0-9.e+-]+)',block)[1]) for k in ['totalTime','childTime','calls']}
 row['profiling']=entries;row['startup_sensitivity_under_1_percent']=all(v<.01 for v in row['startup_sensitivity'].values());row['speedup_vs_baseline']=base['wall_s']/row['wall_s']
(ROOT/'reports/BENCHMARK_ANALYSIS.json').write_text(json.dumps(rows,indent=2))
lines=['# Bounded benchmark results','', 'All cases start at0.01s and end at0.01028s. Results screen a short startup window; they do not establish full-cycle accuracy. Wall times include startup and saved writes. Native profiling is included in JSON. No long run has been launched.','', '| Factor | Wall seconds | Speedup | Hours per simulated second | Max Co | U / p / WSS relative L2 |','|---|---:|---:|---:|---:|---|']
for r in rows:
 vals=' / '.join(f'{r["startup_sensitivity"].get(k+"_relative_L2",0):.3%}' for k in ['velocity','pressure','WSS']);lines.append(f'| {r["name"]} | {r["wall_s"]:.2f} | {r["speedup_vs_baseline"]:.2f} | {r["estimated_wall_hours_per_simulated_second"]:.2f} | {r["max_Courant"]:.3f} | {vals} |')
lines+=['','Projection is local startup throughput, not a completion promise. Final duration must be set by successive1s-cycle agreement. Three seconds would cost three times the hours-per-second column if throughput stayed constant;30s is not automatically required.','', 'Finite U/p/WSS, flow imbalance<0.5%, inlet error<1%, max speed<10m/s were required for every recorded case. Final pressure absolute tolerances unchanged. A startup L2 change below1% is a screening threshold only. Periodic U/p/WSS and TAWSS gates<5% remain mandatory, plus coarse/fine sensitivity.','', 'MPI is unmeasured because managed socket creation is denied. See MPI_USER_ACTION.md for a normal Ubuntu-terminal smoke test and bounded MPI benchmark. No sandbox bypass.']
(ROOT/'reports/BENCHMARK_REPORT.md').write_text('\n'.join(lines)+'\n');print('\n'.join(lines))
