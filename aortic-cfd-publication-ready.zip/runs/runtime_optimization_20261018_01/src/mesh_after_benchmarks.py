from pathlib import Path
import time,subprocess,sys
root=Path(__file__).resolve().parents[1]
for _ in range(120):
 if (root/'reports/BENCHMARK_COMPLETE').exists():break
 time.sleep(30)
else:raise RuntimeError('Benchmarks did not finish: no mesh work started')
subprocess.run([sys.executable,str(root/'src/prepare_coarse.py')],check=True)
