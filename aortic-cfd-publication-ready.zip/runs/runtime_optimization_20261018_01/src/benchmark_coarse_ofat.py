from pathlib import Path
import os,sys,shutil,re,json,time,subprocess,fcntl,hashlib
ROOT=Path(__file__).resolve().parents[1]; SOURCE=Path('/tmp/aortic_coarse_startup_20261018_03/cfd/aorta')
os.environ.update(WM_PROJECT_DIR='/usr/share/openfoam',FOAM_ETC='/usr/share/openfoam/etc',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
for _ in range(120):
 if (ROOT/'reports/COARSE_MESH_UNIFORM_SNAPPED.json').exists():break
 time.sleep(30)
else:raise RuntimeError('Mesh stage incomplete')
lock=open(ROOT/'.benchmark.lock','w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
WORK=Path('/tmp/aortic_coarse_ofat_20261018_01');WORK.mkdir(exist_ok=False);(ROOT/'COARSE_OFAT_DIRECTORY.txt').write_text(str(WORK)+'\n')
sys.path.insert(0,str(ROOT/'archive/slow_run_complete/src'))
from analyze_results import reader,fields,areas,patch_flux
import numpy as np
from vtk.util.numpy_support import vtk_to_numpy
results=[]; baseline=None
variants=[('timestep_0004',None,None),('timestep_0008',None,None),('outer','nOuterCorrectors 2','nOuterCorrectors 1')]
def run(cmd,log,env=None):
 with open(log,'w') as f:
  p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env,timeout=1800)
 if p.returncode:raise RuntimeError(f'{cmd} failed; see {log}')
def snapshot(case,t):
 r=reader(case);m,b=fields(r,t);v=vtk_to_numpy(m.GetCellData().GetArray('U')).copy();p=vtk_to_numpy(m.GetCellData().GetArray('p')).copy()*1060;w=vtk_to_numpy(b['aorta_wall'].GetCellData().GetArray('wallShearStress')).copy()*1060
 size=__import__('vtk').vtkCellSizeFilter();size.SetInputData(m);size.Update();vol=vtk_to_numpy(size.GetOutput().GetCellData().GetArray('Volume')).copy();wa=areas(b['aorta_wall'])
 folder=next(x for x in case.iterdir() if x.is_dir() and re.fullmatch(r'[0-9.]+',x.name) and abs(float(x.name)-t)<1e-8)
 q=[patch_flux(folder/'phi',n,b[n].GetNumberOfCells()) for n in ['aorta_inlet','aorta_outlet1','aorta_outlet2']];expected=5e-5+3.5e-5*np.sin(2*np.pi*t)
 gate={'flux_m3_s':q,'relative_flow_imbalance':abs(sum(q))/abs(q[0]),'relative_inlet_error':abs(-q[0]-expected)/expected,'max_speed_m_s':float(np.linalg.norm(v,axis=1).max()),'mean_WSS_Pa':float(np.average(np.linalg.norm(w,axis=1),weights=wa)),'max_WSS_Pa':float(np.linalg.norm(w,axis=1).max()),'pressure_range_Pa':[float(p.min()),float(p.max())]}
 assert all(np.isfinite(x).all() for x in [v,p,w]);assert gate['relative_flow_imbalance']<.005 and gate['relative_inlet_error']<.01 and gate['max_speed_m_s']<10,gate
 return (v,p,w,vol,wa),gate
baseline=snapshot(SOURCE,.01)[0]
for name,old,new in variants:
 case=WORK/name;case.mkdir();logs=WORK/(name+'_logs');logs.mkdir()
 for d in ['constant','system','0']:shutil.copytree(SOURCE/d,case/d)
 (case/'aorta.foam').touch();p=case/'system/controlDict';s=p.read_text()
 for k,val in {'stopAt':'endTime','endTime':'.01','deltaT':'1e-5','adjustTimeStep':'yes','writeControl':'adjustableRunTime','writeInterval':'.002','maxDeltaT':'.0004' if name=='timestep_0004' else '.0008' if name=='timestep_0008' else '.0002','purgeWrite':'0'}.items():s,n=re.subn(r'\b'+k+r'\s+[^;]+;',k+' '+val+';',s);assert n==1
 s+='\nprofiling { enabled true; sysInfo true; }\n';p.write_text(s)
 if old:
  p=case/'system/fvSolution';s=p.read_text();assert old in s;s=s.replace(old,new,1);p.write_text(s)
 if name=='renumber':
  run(['renumberMesh','-case',str(case),'-latestTime','-overwrite'],logs/'renumber.log')
  run(['checkMesh','-case',str(case),'-allTopology','-allGeometry'],logs/'checkMesh.log');assert 'Mesh OK.' in (logs/'checkMesh.log').read_text()
 started=time.monotonic();usage=[]
 with open(logs/'solver.log','w') as f:
  p=subprocess.Popen(['pimpleFoam','-case',str(case),'-noFunctionObjects'],stdout=f,stderr=subprocess.STDOUT)
  while p.poll() is None:
   try:
    st=Path(f'/proc/{p.pid}/stat').read_text().split();status=Path(f'/proc/{p.pid}/status').read_text();usage.append({'elapsed_s':time.monotonic()-started,'cpu_s':(int(st[13])+int(st[14]))/os.sysconf('SC_CLK_TCK'),'rss_kib':int(re.search(r'VmRSS:\s+(\d+)',status)[1])})
   except (FileNotFoundError,TypeError):pass
   if time.monotonic()-started>900:p.terminate();raise RuntimeError('Benchmark exceeded 900s')
   time.sleep(2)
 elapsed=time.monotonic()-started;txt=(logs/'solver.log').read_text();assert p.returncode==0 and 'End' in txt and 'FOAM FATAL' not in txt
 co=[float(v) for v in re.findall(r'Courant Number mean: \S+ max: (\S+)',txt)];assert co and max(co)<2 and not re.search(r'\bnan\b',txt,re.I)
 env=os.environ.copy();env['LD_PRELOAD']=str(ROOT/'archive/slow_run_complete/src/libsha1_compat.so');run(['pimpleFoam','-case',str(case),'-postProcess','-func','wallShearStress','-latestTime'],logs/'wss.log',env)
 a,gate=snapshot(case,.01)
 comparisons={}
 if name=='baseline':baseline=a
 elif name!='renumber':
  for field,x,y,weights in zip(['velocity','pressure','WSS'],a[:3],baseline[:3],[a[3],a[3],a[4]]):
   sq=lambda z:np.sum(z*z,axis=1) if z.ndim==2 else z*z
   comparisons[field+'_relative_L2']=float(np.sqrt(np.average(sq(x-y),weights=weights)/np.average(sq(y),weights=weights)))
 row={'name':name,'case':str(case),'wall_s':elapsed,'simulated_interval_s':.01,'estimated_wall_hours_per_simulated_second':elapsed/.01/3600,'max_Courant':max(co),'cpu_core_percent':100*usage[-1]['cpu_s']/usage[-1]['elapsed_s'],'max_rss_MiB':max(x['rss_kib'] for x in usage)/1024,'validation':gate,'startup_sensitivity':comparisons,'accuracy_status':'Short-window screen only; periodic and mesh sensitivity gates still required','cpu_samples':usage}
 results.append(row);(ROOT/'reports/COARSE_OFAT_BENCHMARKS.json').write_text(json.dumps(results,indent=2));print(json.dumps({k:v for k,v in row.items() if k!='cpu_samples'}),flush=True)
(ROOT/'reports/COARSE_OFAT_BENCHMARK_COMPLETE').write_text('No long simulation launched.\n')
