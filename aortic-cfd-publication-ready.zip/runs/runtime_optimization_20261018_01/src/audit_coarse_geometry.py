from pathlib import Path
import json,sys,shutil
import numpy as np,vtk
from vtk.util.numpy_support import vtk_to_numpy
ROOT=Path(__file__).resolve().parents[1];reportpath=Path(sys.argv[1]);report=json.loads(reportpath.read_text());assert report['status']=='PASS'
case=Path(report['case']);audit=Path(str(case.parents[1])+'_geometry_audit');dst=audit/'cfd/aorta';dst.mkdir(parents=True,exist_ok=False)
shutil.copytree(case/'constant',dst/'constant');shutil.copytree(case/'system',dst/'system');(dst/'0').mkdir();(dst/'aorta.foam').touch()
for n in ['U','p']:shutil.copy2(ROOT.parents[1]/'cfd/repaired_run_01/0'/n,dst/'0'/n)
sys.path.insert(0,str(ROOT/'archive/slow_run_complete/src'));from analyze_results import reader,fields,areas
fine=ROOT/'archive/slow_run_complete/cfd/aorta';datasets=[]
for c in [fine,dst]:
 r=reader(c);m,b=fields(r,0);size=vtk.vtkCellSizeFilter();size.SetInputData(m);size.Update();vol=vtk_to_numpy(size.GetOutput().GetCellData().GetArray('Volume'));wall=vtk.vtkPolyData();wall.DeepCopy(b['aorta_wall']);metrics={'cells':m.GetNumberOfCells(),'volume_m3':float(vol.sum()),'wall_area_m2':float(areas(wall).sum()),'patch_areas_m2':{n:float(areas(b[n]).sum()) for n in ['aorta_inlet','aorta_outlet1','aorta_outlet2']}};datasets.append((wall,metrics))
a,b=datasets;distances={}
for name,x,y in [('coarse_to_fine',b[0],a[0]),('fine_to_coarse',a[0],b[0])]:
 d=vtk.vtkDistancePolyDataFilter();d.SetInputData(0,x);d.SetInputData(1,y);d.SignedDistanceOff();d.ComputeSecondDistanceOff();d.ComputeCellCenterDistanceOn();d.Update();out=d.GetOutput();point=vtk_to_numpy(out.GetPointData().GetArray('Distance'));cell=vtk_to_numpy(out.GetCellData().GetArray('Distance'));wt=areas(x);distances[name]={'sampled_vertex_max_mm':float(point.max()*1000),'sampled_face_center_max_mm':float(cell.max()*1000),'face_area_weighted_mean_mm':float(np.average(cell,weights=wt)*1000),'note':'Samples at mesh vertices and face centers; not a certified Hausdorff bound.'}
r={'status':'GEOMETRY_MEASURED_ONLY','candidate':str(case),'fine':a[1],'coarse':b[1],'volume_relative_change':b[1]['volume_m3']/a[1]['volume_m3']-1,'wall_area_relative_change':b[1]['wall_area_m2']/a[1]['wall_area_m2']-1,'cap_area_relative_changes':{n:b[1]['patch_areas_m2'][n]/a[1]['patch_areas_m2'][n]-1 for n in a[1]['patch_areas_m2']},'wall_distances':distances,'accuracy':'Geometry approximation only; flow and WSS sensitivity and cycle convergence still required.'};out=ROOT/'reports'/(reportpath.stem+'_GEOMETRY_AUDIT.json');out.write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
