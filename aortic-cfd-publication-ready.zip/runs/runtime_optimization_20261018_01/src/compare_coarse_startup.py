from pathlib import Path
import sys,json,numpy as np,vtk
from vtk.util.numpy_support import vtk_to_numpy,numpy_to_vtk
from scipy.spatial import cKDTree
ROOT=Path(__file__).resolve().parents[1];coarse=Path(sys.argv[1]);sys.path.insert(0,str(ROOT/'archive/slow_run_complete/src'));from analyze_results import reader,fields,areas
fine=ROOT/'archive/slow_run_complete/cfd/aorta'
def load(case):
 r=reader(case);m,b=fields(r,.01);grid=vtk.vtkUnstructuredGrid();grid.DeepCopy(m);wall=vtk.vtkPolyData();wall.DeepCopy(b['aorta_wall']);press={n:float(np.average(vtk_to_numpy(b[n].GetCellData().GetArray('p')),weights=areas(b[n]))*1060) for n in ['aorta_inlet','aorta_outlet1','aorta_outlet2']};return grid,wall,press
f,fw,fp=load(fine);c,cw,cp=load(coarse)
def centers(m):
 v=vtk.vtkCellCenters();v.SetInputData(m);v.Update();return vtk_to_numpy(v.GetOutput().GetPoints().GetData()).copy()
# Deterministic sampled fine-cell centers, inside both domains; no extrapolation.
xyz=centers(f);idx=np.arange(0,len(xyz),50);points=vtk.vtkPoints();points.SetData(numpy_to_vtk(xyz[idx],deep=True));poly=vtk.vtkPolyData();poly.SetPoints(points);probe=vtk.vtkProbeFilter();probe.SetInputData(poly);probe.SetSourceData(c);probe.Update();pd=probe.GetOutput().GetPointData();mask=vtk_to_numpy(pd.GetArray('vtkValidPointMask')).astype(bool)
size=vtk.vtkCellSizeFilter();size.SetInputData(f);size.Update();wt=vtk_to_numpy(size.GetOutput().GetCellData().GetArray('Volume'))[idx][mask];comparisons={}
for name in ['U','p']:
 a=vtk_to_numpy(f.GetCellData().GetArray(name))[idx][mask];b=vtk_to_numpy(pd.GetArray(name))[mask];sq=lambda z:np.sum(z*z,axis=1) if z.ndim==2 else z*z;comparisons[name+'_sampled_volume_relative_L2']=float(np.sqrt(np.average(sq(a-b),weights=wt)/np.average(sq(a),weights=wt)))
fa=areas(fw);ca=areas(cw);fs=np.linalg.norm(vtk_to_numpy(fw.GetCellData().GetArray('wallShearStress')),axis=1)*1060;cs=np.linalg.norm(vtk_to_numpy(cw.GetCellData().GetArray('wallShearStress')),axis=1)*1060;dist,near=cKDTree(centers(cw)).query(centers(fw));comparisons['WSS_magnitude_nearest_face_area_relative_L2']=float(np.sqrt(np.average((fs-cs[near])**2,weights=fa)/np.average(fs*fs,weights=fa)));comparisons['fine_area_mean_WSS_Pa']=float(np.average(fs,weights=fa));comparisons['coarse_area_mean_WSS_Pa']=float(np.average(cs,weights=ca))
r={'status':'SENSITIVITY_MEASURED_NOT_ACCURACY_ESTABLISHED','comparison_time_s':.01,'fine_case':str(fine),'coarse_case':str(coarse),'common_domain_sampled_points':int(mask.sum()),'sampled_fine_points':len(idx),'fine_patch_pressure_Pa':fp,'coarse_patch_pressure_Pa':cp,'comparisons':comparisons,'WSS_mapping_max_center_distance_mm':float(dist.max()*1000),'limitations':'Early transient only. Geometry differs. Velocity/pressure sampled in common domain; WSS magnitude mapped to nearest coarse face, not a conservative transfer. No mesh convergence, cycle convergence, time-step convergence or anatomical accuracy claim.'};(ROOT/'reports/COARSE_FINE_STARTUP_SENSITIVITY.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
