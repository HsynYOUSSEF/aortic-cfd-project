"""Independent generic polygon-face flux reconstruction; never trusts native initial U."""
from pathlib import Path
import re,sys,json,numpy as np
case=Path(sys.argv[1]);report=case.parents[1]/'reports';mesh=case/'constant/polyMesh'
def rawlist(data,dtype,start=0,components=1):
 m=re.search(rb'\n\s*(\d+)\s*\n\(',data[start:]);assert m;n=int(m[1]);pos=start+m.end();a=np.frombuffer(data,dtype=dtype,count=n*components,offset=pos).copy();return a.reshape(-1,components) if components>1 else a,pos+a.nbytes
def fld(data,start,components=1):
 m=re.search(rb'(?:internalField|value)\s+nonuniform\s+List<\w+>\s+(\d+)\s*\(',data[start:]);assert m;pos=start+m.end();n=int(m[1]);a=np.frombuffer(data,dtype='<f8',count=n*components,offset=pos).copy();return a.reshape(-1,components) if components>1 else a,pos
points,_=rawlist((mesh/'points').read_bytes(),'<f8',components=3);data=(mesh/'faces').read_bytes();offset,end=rawlist(data,'<i4');flat,_=rawlist(data,'<i4',end);assert offset[0]==0 and offset[-1]==len(flat)
following=np.arange(len(flat))+1;following[offset[1:]-1]=offset[:-1];origins=np.repeat(points[flat[offset[:-1]]],np.diff(offset),axis=0);sf=.5*np.add.reduceat(np.cross(points[flat]-origins,points[flat[following]]-origins),offset[:-1],axis=0);mag=np.linalg.norm(sf,axis=1);assert np.all(mag>0)
own,_=rawlist((mesh/'owner').read_bytes(),'<i4');nei,_=rawlist((mesh/'neighbour').read_bytes(),'<i4');ni=len(nei);nc=int(max(own.max(),nei.max())+1)
fluxdata=(case/'0/phi').read_bytes();phiall=np.zeros(len(own));phiall[:ni]=fld(fluxdata,0)[0];boundary=(mesh/'boundary').read_text();patches={}
for name,block in re.findall(r'(\w+)\s*\{([^}]+)\}',boundary):
 start=re.search(r'startFace\s+(\d+)',block);count=re.search(r'nFaces\s+(\d+)',block)
 if not start or not count:continue
 start,count=int(start[1]),int(count[1]);patches[name]=(start,count)
 if not count:continue
 begin=fluxdata.index(name.encode(),fluxdata.index(b'boundaryField'));end=fluxdata.index(b'}',begin);part=fluxdata[begin:end]
 if re.search(rb'value\s+nonuniform',part):values,_=fld(fluxdata,begin);assert len(values)==count
 else:
  m=re.search(rb'value\s+uniform\s+([^;]+)',part);assert m;values=float(m[1])*np.ones(count)
 phiall[start:start+count]=values
assert len(phiall)==len(sf)
both=lambda a:np.bincount(own,weights=a,minlength=nc)+np.bincount(nei,weights=a[:ni],minlength=nc)
tensor=np.empty((nc,3,3))
for i in range(3):
 for j in range(3):tensor[:,i,j]=both(sf[:,i]*sf[:,j]/mag)
rhs=np.column_stack([both(sf[:,i]*phiall/mag) for i in range(3)]);u=np.linalg.solve(tensor,rhs[:,:,None])[:,:,0];speed=np.linalg.norm(u,axis=1);assert np.isfinite(u).all() and speed.max()<10
path=case/'0/U';data=path.read_bytes();old,pos=fld(data,0,3);assert old.shape==u.shape
archive=report/'original_native_potential_U';assert not archive.exists();archive.write_bytes(data);data=data[:pos]+np.asarray(u,dtype='<f8').tobytes()+data[pos+u.nbytes:]
for name in ['aorta_outlet1','aorta_outlet2']:
 start,count=patches[name];begin=data.index(name.encode(),data.index(b'boundaryField'));old,pos=fld(data,begin,3);assert len(old)==count;values=u[own[start:start+count]];data=data[:pos]+values.astype('<f8').tobytes()+data[pos+values.nbytes:]
path.write_bytes(data);written,_=fld(data,0,3);assert np.array_equal(written,u)
q=[float(phiall[s:s+n].sum()) for s,n in [patches[x] for x in ['aorta_inlet','aorta_outlet1','aorta_outlet2']]];imb=abs(sum(q))/abs(q[0]);inlet=abs(q[0]+5e-5)/5e-5;assert imb<.005 and inlet<.01
r={'status':'INDEPENDENT_INITIALIZATION_PASS','cells':nc,'max_speed_m_s':float(speed.max()),'max_equation_residual':float(np.abs(np.einsum('nij,nj->ni',tensor,u)-rhs).max()),'flux_m3_s':q,'flow_imbalance':imb,'inlet_error':inlet,'method':'NumPy tensor solve from actual oriented polygon area vectors and every phi boundary patch; original native U archived; outlet values corrected to owner cells'};(report/'initialization.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
