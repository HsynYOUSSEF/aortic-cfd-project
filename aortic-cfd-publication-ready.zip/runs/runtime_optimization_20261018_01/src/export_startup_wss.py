from pathlib import Path
import sys,json,numpy as np,vtk
from vtk.util.numpy_support import vtk_to_numpy,numpy_to_vtk
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'archive/slow_run_complete/src'));from analyze_results import reader,fields
case=Path('/tmp/aortic_coarse_startup_20261018_03/cfd/aorta');out=ROOT/'diagnostic_outputs/coarse_startup_WSS';out.mkdir(parents=True,exist_ok=False);r=reader(case);entries=[]
for t in [.002,.004,.006,.008,.01]:
 m,b=fields(r,t);wall=vtk.vtkPolyData();wall.DeepCopy(b['aorta_wall']);tau=vtk_to_numpy(wall.GetCellData().GetArray('wallShearStress')).astype(float)*1060;assert np.isfinite(tau).all();a=numpy_to_vtk(tau,deep=True);a.SetName('WSS_Pa');wall.GetCellData().AddArray(a);a=numpy_to_vtk(np.linalg.norm(tau,axis=1),deep=True);a.SetName('WSS_magnitude_Pa');wall.GetCellData().AddArray(a);w=vtk.vtkXMLPolyDataWriter();name=f'wall_{t:g}.vtp';w.SetFileName(str(out/name));w.SetInputData(wall);assert w.Write()==1;entries.append(f'<DataSet timestep="{t:g}" group="" part="0" file="{name}"/>')
(out/'startup_WSS_Pa.pvd').write_text('<?xml version="1.0"?><VTKFile type="Collection" version="0.1" byte_order="LittleEndian"><Collection>'+''.join(entries)+'</Collection></VTKFile>');(out/'README.txt').write_text('STARTUP DIAGNOSTIC ONLY: 0.002–0.01 seconds. Saved-field/conservation gates passed; periodic cycles NOT validated. Coarse staircase geometry has large measured fine/coarse sensitivity. WSS_Pa and WSS_magnitude_Pa are native kinematic wallShearStress multiplied once by1060. No mesh-converged or anatomical accuracy claim. Full U/p/phi/mesh case preserved at '+str(case)+'; open aorta.foam. This is not a final deliverable.\n')
print(out/'startup_WSS_Pa.pvd')
