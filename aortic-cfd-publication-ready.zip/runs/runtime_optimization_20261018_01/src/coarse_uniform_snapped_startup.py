from pathlib import Path
import os,sys,json,re,subprocess,shutil,time,fcntl
ROOT=Path(__file__).resolve().parents[1];PROJECT=ROOT.parents[1];MESH=json.loads((ROOT/'reports/COARSE_MESH_UNIFORM_SNAPPED.json').read_text());assert MESH['status']=='PASS','No solver permitted for failed mesh'
lock=open(ROOT/'.benchmark.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
WORK=Path('/tmp/aortic_coarse_startup_20261018_04');WORK.mkdir(exist_ok=False);(ROOT/'COARSE_UNIFORM_SNAPPED_STARTUP_DIRECTORY.txt').write_text(str(WORK)+'\n');case=WORK/'cfd/aorta';case.parent.mkdir();shutil.copytree(MESH['case'],case);(WORK/'reports').mkdir();(WORK/'logs').mkdir();(WORK/'src').mkdir();(case/'0').mkdir()
for n in ['U','p']:shutil.copy2(PROJECT/'cfd/repaired_run_01/0'/n,case/'0'/n)
for n in ['analyze_results.py','validate_saved_fields.py','watch_run.py']:shutil.copy2(ROOT/'archive/slow_run_complete/src'/n,WORK/'src'/n)
config=json.loads((ROOT/'archive/slow_run_complete/run_config.json').read_text());config['end_time_s']=.01;(WORK/'run_config.json').write_text(json.dumps(config,indent=2))
p=case/'system/controlDict';s=p.read_text()
for key,val in {'startFrom':'startTime','startTime':'0','stopAt':'endTime','endTime':'.01','deltaT':'1e-5','writeControl':'adjustableRunTime','writeInterval':'.002','adjustTimeStep':'yes','maxCo':'.7','maxDeltaT':'.0002'}.items():s,n=re.subn(r'\b'+key+r'\s+[^;]+;',key+' '+val+';',s);assert n==1
p.write_text(s+'\nprofiling {enabled true;sysInfo true;}\n');os.environ.update(WM_PROJECT_DIR='/usr/share/openfoam',FOAM_ETC='/usr/share/openfoam/etc',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
def run(args,name,env=None):
 with open(WORK/'logs'/name,'w') as f:subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,timeout=1000,check=True,env=env)
run(['potentialFoam','-case',str(case),'-initialiseUBCs','-writephi'],'potential.log')
run([sys.executable,str(ROOT/'src/reconstruct_poly_initial.py'),str(case)],'independent_initialization.log')
start=time.monotonic();run([sys.executable,str(WORK/'src/watch_run.py'),str(WORK),'--target','.01','--budget','900','--stage','coarse_startup'],'watchdog.log');elapsed=time.monotonic()-start
env=os.environ.copy();env['LD_PRELOAD']=str(ROOT/'archive/slow_run_complete/src/libsha1_compat.so');run(['pimpleFoam','-case',str(case),'-postProcess','-func','wallShearStress','-time','0.002:0.01'],'WSS.log',env)
run([sys.executable,str(WORK/'src/validate_saved_fields.py'),str(WORK),'--require-end','.01','--minimum-times','5'],'validation.log')
report={'status':'BOUNDED_STARTUP_PASS_ONLY','work':str(WORK),'simulation_duration_s':.01,'wall_s':elapsed,'projected_hours_per_simulated_second':elapsed/.01/3600,'validation':json.loads((WORK/'reports/saved_field_validation.json').read_text()),'limitations':'Fine/coarse sensitivity and periodic cycles not yet established. No long run or final video launched.'};(ROOT/'reports/COARSE_UNIFORM_SNAPPED_STARTUP.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
