from pathlib import Path
import sys,shutil,json,re,os,time,subprocess,hashlib
import numpy as np,vtk
from vtk.util.numpy_support import vtk_to_numpy
ROOT=Path(__file__).resolve().parents[1];PROJECT=ROOT.parents[1];SRC=ROOT/'archive/slow_run_complete/cfd/aorta';WORK=Path('/tmp/aortic_optimization_coarse_20261018_03');WORK.mkdir(exist_ok=False)
import atexit
def persist_failure():
 p=ROOT/'reports/COARSE_MESH_UNIFORM.json'
 if not p.exists():p.write_text(json.dumps({'status':'FAIL','case':str(WORK/'cfd/aorta'),'solver_launched':False,'reason':'Mesh preparation or native command failed; inspect logs/coarse_controller.log and Linux mesh logs. No checks bypassed.'},indent=2))
atexit.register(persist_failure)
(ROOT/'COARSE_UNIFORM_DIRECTORY.txt').write_text(str(WORK)+'\n');case=WORK/'cfd/aorta';case.mkdir(parents=True);(WORK/'logs').mkdir();(WORK/'reports').mkdir();(case/'aorta.foam').touch()
for d in ['system']:shutil.copytree(SRC/d,case/d)
(case/'constant/triSurface').mkdir(parents=True)
for n in ['transportProperties','turbulenceProperties']:shutil.copy2(SRC/'constant'/n,case/'constant'/n)
r=vtk.vtkXMLPolyDataReader();r.SetFileName(str(PROJECT/'runs/mesh_repair_20261017_01/geometry/boundary.vtp'));r.Update();d=r.GetOutput();pts=vtk_to_numpy(d.GetPoints().GetData());faces=vtk_to_numpy(d.GetPolys().GetData()).reshape(-1,4)[:,1:];xyz=pts[faces]
sys.path.insert(0,str(PROJECT/'src'));from prepare_case import groups
upper=np.flatnonzero(np.max(abs(xyz[:,:,2]+.24),axis=1)<1e-7);lower=np.flatnonzero(np.max(abs(xyz[:,:,2]+.42),axis=1)<1e-7);ug=groups(faces,upper);lg=groups(faces,lower);assert len(ug)==1 and len(lg)==2,(len(ug),len(lg));lg.sort(key=lambda ids:float(xyz[ids,:,0].mean()));labels=np.full(len(faces),'wall',dtype='<U10');labels[upper]='inlet'
for i,ids in enumerate(lg,1):labels[ids]=f'outlet{i}'
with open(case/'constant/triSurface/aorta.stl','w') as f:
 for name in ['wall','inlet','outlet1','outlet2']:
  f.write(f'solid {name}\n')
  for tri in xyz[labels==name]:
   n=np.cross(tri[1]-tri[0],tri[2]-tri[0]);n/=np.linalg.norm(n);f.write('facet normal '+' '.join(map(str,n))+'\nouter loop\n')
   for p in tri:f.write('vertex '+' '.join(map(str,p))+'\n')
   f.write('endloop\nendfacet\n')
  f.write(f'endsolid {name}\n')
# Preserve exact fine-mesh boundary coordinates; only volume discretization changes.
p=case/'system/snappyHexMeshDict';s=p.read_text().replace('addLayers true','addLayers false').replace('level (2 2)','level (1 1)').replace('snap true','snap false').replace('refinementRegions {};','refinementRegions {aorta {mode inside;levels ((1e15 1));}};');p.write_text(s)
# No solver launch or projected-success assumptions in this mesh-only stage.
os.environ.update(WM_PROJECT_DIR='/usr/share/openfoam',FOAM_ETC='/usr/share/openfoam/etc')
for cmd,name in [(['blockMesh'],'blockMesh'),(['snappyHexMesh','-overwrite'],'snappyHexMesh'),(['checkMesh','-allTopology','-allGeometry'],'checkMesh')]:
 with open(WORK/'logs'/f'{name}.log','w') as f:
  p=subprocess.run(cmd+['-case',str(case)],stdout=f,stderr=subprocess.STDOUT,timeout=1800)
 if p.returncode:raise RuntimeError(f'{name} failed; retained {WORK}')
text=(WORK/'logs/checkMesh.log').read_text();boundary=(case/'constant/polyMesh/boundary').read_text();counts={}
for n in ['aorta_wall','aorta_inlet','aorta_outlet1','aorta_outlet2']:
 m=re.search(r'\b'+n+r'\s*\{([^}]+)',boundary);counts[n]=int(re.search(r'nFaces\s+(\d+)',m[1])[1]) if m else 0
passed='Mesh OK.' in text and all(counts.values()) and not re.search(r'Failed\s+[1-9]\d*\s+mesh checks|FOAM FATAL',text,re.I)
report={'status':'PASS' if passed else 'FAIL','case':str(case),'patch_faces':counts,'source_geometry':'Exact preserved fine-mesh boundary, regrouped into original four patches','surface_sha256':hashlib.sha256((case/'constant/triSurface/aorta.stl').read_bytes()).hexdigest(),'nominal_surface_cell_mm':1,'layers':0,'snapping':False,'interior_refinement':'uniform1mm; remove coarse-fine hanging-face transitions','geometry_approximation':'Staircase voxel boundary; original fine surface preserved. Quantify volume/cap/nearest-wall errors and U/p/WSS sensitivity before interpreting results.','accuracy':'Exploratory candidate only. Native full mesh gate, geometry/topology, startup conservation and U/p/WSS sensitivity still required before any accuracy claim.','solver_launched':False};(ROOT/'reports/COARSE_MESH_UNIFORM.json').write_text(json.dumps(report,indent=2));(WORK/'reports/mesh_check.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));assert passed,'Full native mesh validation failed; no solver permitted'
