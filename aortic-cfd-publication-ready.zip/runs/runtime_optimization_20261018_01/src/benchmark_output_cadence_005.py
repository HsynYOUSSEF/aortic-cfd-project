"""Bounded, same-control output cadence comparison; no long run."""
from pathlib import Path
import os, re, json, shutil, subprocess, sys, time, fcntl, signal, hashlib
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path('/tmp/aortic_coarse_startup_20261018_03')
SRC_CASE = SOURCE / 'cfd/aorta'
ARCHIVE_SRC = ROOT / 'archive/slow_run_complete/src'
WORK = Path('/tmp/aortic_output_cadence_20261018_01')
CASE_CAP = int(.25 * 1024**3)
LOCK = open(ROOT / '.benchmark.lock', 'a')
fcntl.flock(LOCK, fcntl.LOCK_EX | fcntl.LOCK_NB)
WORK.mkdir(exist_ok=False)
(ROOT / 'OUTPUT_CADENCE_DIRECTORY.txt').write_text(str(WORK) + '\n')
for d in ['logs', 'reports', 'src']:
    (WORK / d).mkdir()
for filename in ['analyze_results.py', 'validate_saved_fields.py']:
    shutil.copy2(ARCHIVE_SRC / filename, WORK / 'src' / filename)
os.environ.update(WM_PROJECT_DIR='/usr/share/openfoam', FOAM_ETC='/usr/share/openfoam/etc',
                  OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')

def footprint():
    return sum(p.stat().st_size for p in WORK.rglob('*') if p.is_file())

def stop_at_checkpoint(case, proc):
    control = case / 'system/controlDict'
    s = control.read_text()
    s, n = re.subn(r'\bstopAt\s+[^;]+;', 'stopAt writeNow;', s)
    if n == 1:
        control.write_text(s)
    try:
        proc.wait(timeout=120)
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid, signal.SIGTERM)
        proc.wait()

rows = []
for name, interval, min_times in [('dense_002', '.002', 21), ('sparse_010', '.01', 5)]:
    root = WORK / name
    case = root / 'cfd/aorta'
    case.parent.mkdir(parents=True)
    root.joinpath('src').mkdir()
    root.joinpath('reports').mkdir()
    shutil.copy2(WORK / 'src/analyze_results.py', root / 'src/analyze_results.py')
    for d in ['0', '0.01', 'system']:
        shutil.copytree(SRC_CASE / d, case / d)
    # Immutable mesh/source geometry is shared read-only; no mesh copy is made.
    (case / 'constant').symlink_to(SRC_CASE / 'constant', target_is_directory=True)
    (case / 'aorta.foam').touch()
    (case / 'system/decomposeParDict').unlink(missing_ok=True)
    control = case / 'system/controlDict'
    s = control.read_text()
    updates = {'startFrom': 'latestTime', 'stopAt': 'endTime', 'endTime': '.05',
               'deltaT': '1e-5', 'adjustTimeStep': 'yes', 'maxCo': '.7',
               'maxDeltaT': '.0002', 'writeControl': 'adjustableRunTime',
               'writeInterval': interval, 'purgeWrite': '0'}
    for key, value in updates.items():
        s, n = re.subn(r'\b' + key + r'\s+[^;]+;', key + ' ' + value + ';', s)
        assert n == 1, (key, n)
    control.write_text(s)
    config = json.loads((SOURCE / 'run_config.json').read_text())
    config['end_time_s'] = .05
    (root / 'run_config.json').write_text(json.dumps(config, indent=2))

    log = WORK / 'logs' / f'{name}_solver.log'
    started = time.monotonic()
    cpu_samples = []
    with log.open('w') as stream:
        proc = subprocess.Popen(['pimpleFoam', '-case', str(case), '-noFunctionObjects'],
                                stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        last_time, progress = None, started
        while proc.poll() is None:
            text = log.read_text(errors='replace')[-100000:]
            times = re.findall(r'^Time =\s*(\S+)', text, re.M)
            if times:
                current = float(times[-1])
                if last_time is None or current > last_time + 1e-12:
                    last_time, progress = current, time.monotonic()
            cos = [float(x) for x in re.findall(r'Courant Number mean: \S+ max: (\S+)', text)]
            reason = ('CFL threshold' if cos and max(cos) > 1 else
                      'linear iteration cap' if re.search(r'No Iterations (?:1000|[1-9][0-9]{4,})\b', text) else None)
            if reason:
                stop_at_checkpoint(case, proc)
                raise RuntimeError(f'{name}: {reason}; checkpoint retained')
            if time.monotonic() - progress > 300:
                stop_at_checkpoint(case, proc)
                raise RuntimeError(f'{name}: no time progress; checkpoint retained')
            if time.monotonic() - started > 1200:
                stop_at_checkpoint(case, proc)
                raise RuntimeError(f'{name}: 20 minute wall cap; checkpoint retained')
            if footprint() > CASE_CAP:
                stop_at_checkpoint(case, proc)
                raise RuntimeError(f'{name}: 0.25 GiB bounded-test cap; checkpoint retained')
            try:
                stat = Path(f'/proc/{proc.pid}/stat').read_text().split()
                rss = int(re.search(r'VmRSS:\s+(\d+)', Path(f'/proc/{proc.pid}/status').read_text())[1])
                cpu_samples.append({'elapsed_s': time.monotonic()-started,
                                    'cpu_s': (int(stat[13])+int(stat[14]))/os.sysconf('SC_CLK_TCK'),
                                    'rss_kib': rss})
            except (FileNotFoundError, TypeError):
                pass
            time.sleep(2)
    elapsed = time.monotonic() - started
    solver_log = log.read_text(errors='replace')
    saved_times = sorted(float(p.name) for p in case.iterdir()
                         if p.is_dir() and re.fullmatch(r'\d+(?:\.\d+)?', p.name))
    assert proc.returncode == 0 and re.search(r'^End\s*$', solver_log, re.M), (name, proc.returncode)
    assert saved_times and abs(saved_times[-1] - .05) < 1e-8, (name, saved_times[-5:])
    cos = [float(x) for x in re.findall(r'Courant Number mean: \S+ max: (\S+)', solver_log)]
    assert cos and max(cos) < 1
    env = os.environ.copy()
    env['LD_PRELOAD'] = str((ARCHIVE_SRC / 'libsha1_compat.so').resolve())
    for label, cmd in [
        ('wss', ['pimpleFoam', '-case', str(case), '-postProcess', '-func', 'wallShearStress', '-time', '.01:.05']),
        ('validate', [sys.executable, str(WORK / 'src/validate_saved_fields.py'), str(root),
                      '--require-end', '.05', '--minimum-times', str(min_times), '--minimum-time', '.01',
                      '--report-name', 'saved_validation.json'])]:
        with (WORK / 'logs' / f'{name}_{label}.log').open('w') as out:
            result = subprocess.run(cmd, env=env, stdout=out, stderr=subprocess.STDOUT)
        assert result.returncode == 0, (name, label)
    val = json.loads((root / 'reports/saved_validation.json').read_text())
    final = re.findall(r'ExecutionTime\s*=\s*([\d.]+)\s+s\s+ClockTime\s*=\s*([\d.]+)\s+s', solver_log)[-1]
    rows.append({'name': name, 'writeInterval_s': float(interval), 'wall_s': elapsed,
                 'solver_clock_s': float(final[1]), 'solver_cpu_s': float(final[0]),
                 'maxCo': max(cos), 'saved_times_after_0.01_s': len(val['fields']),
                 'case_bytes': sum(p.stat().st_size for p in root.rglob('*') if p.is_file()),
                 'flow_imbalance_max': max(x['relative_flow_imbalance'] for x in val['fields']),
                 'inlet_error_max': max(x['relative_inlet_waveform_error'] for x in val['fields']),
                 'validation': 'PASS', 'cpu_samples': cpu_samples})
    (WORK / 'reports/cadence_runs.json').write_text(json.dumps(rows, indent=2))
    print(json.dumps({k:v for k,v in rows[-1].items() if k != 'cpu_samples'}), flush=True)

sys.path.insert(0, str(WORK / 'src'))
from analyze_results import reader, fields, areas
from vtk.util.numpy_support import vtk_to_numpy
readers = [reader(WORK/n/'cfd/aorta') for n in ['dense_002', 'sparse_010']]
phases = [.01, .02, .03, .04, .05]
acc = {name: [0., 0.] for name in ['U', 'p', 'WSS']}
for t in phases:
    loaded = []
    for r in readers:
        mesh, blocks = fields(r, t)
        size = __import__('vtk').vtkCellSizeFilter(); size.SetInputData(mesh); size.Update()
        volume = vtk_to_numpy(size.GetOutput().GetCellData().GetArray('Volume'))
        wall = blocks['aorta_wall']
        loaded.append((mesh, wall, volume, areas(wall)))
    a, b = loaded
    assert a[0].GetNumberOfCells() == b[0].GetNumberOfCells()
    for name, xa, xb, weights in [
        ('U', a[0].GetCellData().GetArray('U'), b[0].GetCellData().GetArray('U'), a[2]),
        ('p', a[0].GetCellData().GetArray('p'), b[0].GetCellData().GetArray('p'), a[2]),
        ('WSS', a[1].GetCellData().GetArray('wallShearStress'), b[1].GetCellData().GetArray('wallShearStress'), a[3])]:
        x = vtk_to_numpy(xa).astype(float); y = vtk_to_numpy(xb).astype(float)
        if name == 'WSS': x *= 1060; y *= 1060
        d = np.sum((x-y)**2, axis=1) if x.ndim == 2 else (x-y)**2
        q = np.sum(x*x, axis=1) if x.ndim == 2 else x*x
        acc[name][0] += float(np.dot(weights, d)); acc[name][1] += float(np.dot(weights, q))
relative = {k: float(np.sqrt(v[0]/v[1])) for k,v in acc.items()}
report = {'status': 'COMPLETED_BOUNDED_OUTPUT_CADENCE_COMPARISON', 'phases_s': phases,
          'dense_write_interval_s': .002, 'candidate_write_interval_s': .01,
          'relative_L2_candidate_vs_dense': relative, 'gate_each_under_1_percent': all(v <= .01 for v in relative.values()),
          'runs': [{k:v for k,v in row.items() if k != 'cpu_samples'} for row in rows],
          'limitation': 'Short-window output-frequency screen only; full-cycle WSS sampling check remains required.'}
(WORK / 'reports/cadence_comparison.json').write_text(json.dumps(report, indent=2)+'\n')
(ROOT / 'reports/OUTPUT_CADENCE_005_COMPARISON.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report, indent=2), flush=True)
