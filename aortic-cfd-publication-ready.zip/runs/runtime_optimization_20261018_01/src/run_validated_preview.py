"""Launch only after measured coarse startup/sensitivity report has been presented."""
from pathlib import Path
import sys,os,json,re,shutil,subprocess,time,fcntl,traceback
ROOT=Path(__file__).resolve().parents[1];PROJECT=ROOT.parents[1]
assert (ROOT/'reports/PRELAUNCH_REPORT.json').exists(),'Measured report must precede this launch'
pre=json.loads((ROOT/'reports/PRELAUNCH_REPORT.json').read_text());assert pre['eligible_for_exploratory_run']
lock=open(ROOT/'.benchmark.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
source=Path(pre['startup_work']);WORK=Path('/tmp/aortic_validated_preview_20261018_01');assert not WORK.exists();shutil.copytree(source,WORK);case=WORK/'cfd/aorta';(ROOT/'PREVIEW_DIRECTORY.txt').write_text(str(WORK)+'\n')
archive=ROOT/'archive/slow_run_complete';
for n in ['analyze_results.py','validate_saved_fields.py','check_periodicity.py','check_deliverables.py','render_flow_wss.py','watch_run.py']:shutil.copy2(archive/'src'/n,WORK/'src'/n)
os.environ.update(WM_PROJECT_DIR='/usr/share/openfoam',FOAM_ETC='/usr/share/openfoam/etc',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1');env=os.environ.copy();env['LD_PRELOAD']=str(archive/'src/libsha1_compat.so');started=time.monotonic()
status={'status':'RUNNING','work':str(WORK),'end_time_policy':'successive1s cycles; earliest3s; maximum8s/3h before unresolved convergence stop','latest_completed_simulation_time_s':.01,'long_video':'30s video replays last validated1s cycle at8x slower playback','accuracy':'Exploratory staircase geometry; mesh-dependent WSS; no accuracy or clinical claim','old_results_preserved':True,'validation_checks_bypassed':False}
def save():
 status['wall_elapsed_s']=time.monotonic()-started;(ROOT/'reports/PREVIEW_STATUS.json').write_text(json.dumps(status,indent=2))
def command(args,log,environment=None,check=True,timeout=7200):
 with open(log,'w') as f:p=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,env=environment,timeout=timeout)
 if check and p.returncode:raise RuntimeError(f'Command failed{p.returncode}: {log}')
 return p.returncode
def solve(end,interval,stage,budget):
 p=case/'system/controlDict';s=p.read_text()
 for k,v in {'startFrom':'latestTime','stopAt':'endTime','endTime':str(end),'writeControl':'adjustableRunTime','writeInterval':str(interval),'maxDeltaT':'.0002','adjustTimeStep':'yes','maxCo':'.7','purgeWrite':'0'}.items():s,n=re.subn(r'\b'+k+r'\s+[^;]+;',k+' '+v+';',s);assert n==1
 p.write_text(s);status['stage']=stage;status['current_stage_target_s']=end;save()
 command([sys.executable,str(WORK/'src/watch_run.py'),str(WORK),'--target',str(end),'--budget',str(budget),'--stage',stage],WORK/'logs'/f'{stage}_watch.log',timeout=budget+60)
 txt=(WORK/'logs'/f'{stage}_solver.log').read_text();cos=[float(x) for x in re.findall(r'Courant Number mean: \S+ max: (\S+)',txt)];assert cos and max(cos)<1, 'CFL gate failed';assert not re.search(r'No Iterations (?:1000|[1-9][0-9]{4,})\b',txt),'Linear iteration cap reached';status['latest_completed_simulation_time_s']=end;save()
def wss(selection,stage):command(['pimpleFoam','-case',str(case),'-postProcess','-func','wallShearStress','-time',selection],WORK/'logs'/f'{stage}_WSS.log',env)
try:
 save();solve(.05,.04,'bridge',900);wss('0.05','bridge')
 for end in range(1,9):
  remaining=10800-(time.monotonic()-started);assert remaining>120,'Three-hour solver budget exhausted without completed convergence'
  solve(end,.05,f'cycle_{end}',min(remaining,3600));wss(f'{.1 if end==1 else end-1+.05:g}:{end}',f'cycle_{end}')
  if end<3:continue
  val=WORK/'cycle_validation'/f'end_{end}';(val/'src').mkdir(parents=True);(val/'reports').mkdir();(val/'results').mkdir();(val/'cfd').mkdir();(val/'cfd/aorta').symlink_to(case,target_is_directory=True)
  for n in ['analyze_results.py','validate_saved_fields.py','check_periodicity.py','check_deliverables.py','render_flow_wss.py']:shutil.copy2(WORK/'src'/n,val/'src'/n)
  cfg=json.loads((WORK/'run_config.json').read_text());cfg['end_time_s']=end;(val/'run_config.json').write_text(json.dumps(cfg,indent=2))
  command([sys.executable,str(val/'src/validate_saved_fields.py'),str(val),'--require-end',str(end),'--minimum-times','41','--minimum-time',str(end-2),'--report-name','final_saved_field_validation.json'],val/'reports/saved_validation.log')
  command([sys.executable,str(val/'src/analyze_results.py')],val/'reports/analysis.log')
  summary=json.loads((val/'results/aorta/summary.json').read_text());assert summary['conservation_under_0_5_percent'] and summary['max_relative_inlet_waveform_error']<.01,'Conservation gate failed'
  code=command([sys.executable,str(val/'src/check_periodicity.py'),str(val)],val/'reports/periodicity.log',check=False);phase=json.loads((val/'reports/phase_periodicity.json').read_text());assert code in [0,1]
  status['latest_cycle_check']={'end_s':end,'TAWSS_relative_L2':summary['TAWSS_cycle_relative_L2'],'phase':phase};save()
  if phase['status']!='PASS' or not summary['cycle_change_under_5_percent']:continue
  status['stage']='rendering validated cycle';status['validated_simulation_duration_s']=end;save()
  # Final checker is duration-adaptive; video duration stays30s,900frames,1080p.
  p=val/'src/check_deliverables.py';s=p.read_text().replace("assert all((case/'30'/name)","cfg=json.loads((root/'run_config.json').read_text());end=float(cfg['end_time_s'])\nassert all((case/f'{end:g}'/name)").replace('np.linspace(29,30,21)','np.linspace(end-1,end,21)').replace("metadata['velocity_cycle_s']==[29,30]","metadata['velocity_cycle_s']==[end-1,end]").replace("'completed_simulation_duration_s':30","'completed_simulation_duration_s':end").replace("'periodicity_cycles_s':[[28,29],[29,30]]","'periodicity_cycles_s':[[end-2,end-1],[end-1,end]]").replace('completed_simulation_duration_s=30','completed_simulation_duration_s=end');p.write_text(s)
  p=val/'src/render_flow_wss.py';s=p.read_text().replace('Saved cycle {a.end-1:g}', 'Exploratory coarse mesh | cycle {a.end-1:g}');p.write_text(s)
  command([sys.executable,str(p),'--project',str(val),'--case','aorta','--end',str(end),'--seconds','30','--fps','30','--particles','4000','--output',str(val/'results/final_video')],val/'reports/render.log',timeout=10800)
  command(['ffmpeg','-v','error','-xerror','-i',str(val/'results/final_video/Aortic_Flow_And_Instantaneous_WSS_1080p.mp4'),'-f','null','-'],val/'reports/video_decode.log')
  command([sys.executable,str(val/'src/check_deliverables.py'),str(val)],val/'reports/deliverable_check.log')
  dest=ROOT/'deliverables'/f'validated_exploratory_{end}s';dest.mkdir(parents=True,exist_ok=False)
  for n in ['results','reports','src']:shutil.copytree(val/n,dest/n)
  shutil.copy2(val/'run_config.json',dest/'run_config.json');target=dest/'cfd/aorta';target.mkdir(parents=True)
  for n in ['constant','system','0']:shutil.copytree(case/n,target/n)
  for folder in case.iterdir():
   if folder.is_dir() and re.fullmatch(r'[0-9.]+',folder.name) and end-2-1e-8<=float(folder.name)<=end+1e-8:shutil.copytree(folder,target/folder.name)
  (target/'aorta.foam').touch()
  status.update(status='COMPLETE',stage='all periodic, saved-field, WSS, video decode and export gates passed',completed_simulation_duration_s=end,deliverables=str(dest),video=str(dest/'results/final_video/Aortic_Flow_And_Instantaneous_WSS_1080p.mp4'),paraview=str(target/'aorta.foam'),wall_metrics=str(dest/'results/aorta/wall_metrics.vtp'));save();break
 else:raise RuntimeError('Eight cycles reached without required successive-cycle agreement; no final video generated')
except BaseException as error:
 status.update(status='STOPPED_OR_FAILED',error=str(error));save();traceback.print_exc();raise
