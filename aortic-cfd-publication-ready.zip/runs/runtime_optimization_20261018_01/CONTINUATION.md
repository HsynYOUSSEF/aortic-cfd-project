> Continuation record updated after the 3.0 s run completed. The run is transient and should not be resumed. See `reports/FINAL_STATUS.json` for authoritative status. Earlier planned steps below are retained for provenance.

# Continuation — exploratory coarse-mesh demonstration

Controller launched in session 61564; solver log confirms active advancement to 0.0214 s at the last check. At the saved progress update, solver reached 0.0274 s of its 1.0 s first-cycle target, maxCo 0.1544, dt 0.0002 s. Check `reports/PROGRESS.json` and the log for current time. Do not launch another controller while this one is active.

Current run folder: `/tmp/aortic_exploratory_demo_20261018_01`. Existing project and result folders are preserved. Mesh-repair work is stopped for this run. The existing 128,472-cell coarse uniform staircase mesh has a native mesh-validity PASS report, but is explicitly **not an accuracy pass** (startup differences from fine mesh: U 26.4%, p 7.94%, mapped WSS 68.5%). WSS output must be labeled unvalidated coarse-mesh results.

Before launch, the 5 GiB ledger included 695,956,503 bytes of bounded tests, estimated 2.4 GB for about 300 WSS-complete saved states through 3 s, 350 MB for video/compact ParaView files, 100 MB logs/temp and a 600 MiB final checkpoint reserve: estimated peak 4,190,206,597 bytes. The actual stop threshold is 4.4 GiB (leaving 0.6 GiB under the cap); the monitor also stops at Windows C: free space <=5 GiB. Monitor actual C: via `df -B1 /mnt/c`; do not rely on `/tmp` free-space figures. Storage details: `reports/PRELAUNCH_REPORT.json`.

Settings: one outer correction and 0.01 s output cadence, each supported by separate bounded tests; `maxDeltaT=0.0002 s`, `maxCo=0.7`, two pressure and two nonorthogonal corrections are unchanged. Solver timestep accuracy remains distinct from write cadence. Runtime measured 94 s per 0.04 s on the coarse mesh, approximately 1.96 h for 3 s by linear extrapolation, excluding postprocessing and not guaranteed.

Run controller: `/tmp/aortic_exploratory_demo_20261018_01/src/run_cycles.py`. It solves successive one-second stages only through 3 s, checks maxCo/timestep, writes WSS, validates all saved fields/conservation/inlet flux and then compares the latest two cycles. It does not extend automatically. If periodicity fails, mark deliverables transient. Retain initial state, cycle-boundary states, reports and latest two cycles. Do not prune any reference data unless cadence/WSS/particle comparison evidence passes and is saved.

Before restart, inspect `reports/PROGRESS.json` and `logs/*solver.log`; verify no `pimpleFoam` is active. If the previous controller exited at a clean cycle boundary, resume with `python3 /tmp/aortic_exploratory_demo_20261018_01/src/run_cycles.py` only after checking the status and its next target. Do not start a duplicate controller. At 3 s, do not extend automatically. Render a 1080p flow video directly to FFmpeg from computed fields, and provide the `.foam` reader plus actual WSS/metrics files for ParaView; include the coarse-WSS label and disclose slow/replayed playback. No final exports exist before the run completes.


## Controller investigation update — 18 October 2026

The solver did not stop at 0.29 s. Its log continued advancing and the latest fully saved checkpoint at this update is 0.49 s; latest solver log Time is 0.4958 s. Do not launch a second controller. The shell process table did not expose the managed solver/controller PID, but timestamped log growth confirms the existing run is active. No `End`/cycle result exists yet. Check `reports/CONTROLLER_INVESTIGATION_20261018.json` and `/tmp/aortic_exploratory_demo_20261018_01/reports/PROGRESS_RECONCILED.json`; the original progress writer reports only completed stage endpoints and is stale during a cycle. The source reporting routine was corrected for future starts to read the latest saved time, in-progress log time, Courant number, timestep and solver clocks. The active process has the old routine already loaded.

The read-only 0.29 s checkpoint check passed core solver fields U/p/phi, finite values, speed, flux balance and inlet waveform. It has no postprocessed WSS, so this is not a WSS saved-field validation. Kernel OOM counter is 0, memory available was about 6.9 GB, C: had about 11.5 GiB free, and no storage-stop marker existed. No logs or time directories were changed by the investigation.


## Final run state

Three simulated seconds completed with solver return code 0. The saved-field/flow checks passed. Phase periodicity did not: WSS relative L2 across the last two cycles was 8.8623% vs a 5% gate (U 4.2831%, p 3.6457%). Mark all outputs transient; no extension beyond 3 s. The 0.29 s false-stop diagnosis and final evidence are in `reports/FINAL_EXPLORATORY_STATUS.json`. Video and ParaView paths are listed there and in `reports/FINAL_EXPLORATORY_STATUS.md`. The encoder uses all computed snapshots once at 10 fps (30 s video, 10x slowed playback; no cycle replay or temporal interpolation).

Controller and solver are confirmed exited after target completion. Do not resume. Retained run and logs remain at `/tmp/aortic_exploratory_demo_20261018_01`; the NumPy 1.26 failed postprocessing output is preserved in `results/aorta_failed_numpy126_attempt1`.
