# Supported MPI benchmark action

This managed session rejects IPv4 socket creation with EPERM before MPI ranks launch. It does not allow sandbox escalation. No sandbox changes or alternative transport bypass have been attempted.

In an ordinary Ubuntu terminal, run this smoke test (it launches no CFD solver):

```bash
mpirun -np 2 hostname
```

If it prints the hostname twice and exits successfully, the bounded test below can measure serial/2/4/8 ranks in separate new cases. Run it only once the Codex serial benchmark has completed. A shared nonblocking lock refuses overlap with that benchmark. It never resumes the old case or launches a long run, and all outputs get a new Linux temporary folder plus a Desktop pointer/results file.

```bash
/home/admin007/.venvs/aortic-cfd/bin/python /mnt/c/Users/Admin/Desktop/Aortic_Repaired_Simulation_20261015/runs/runtime_optimization_20261018_01/src/benchmark_parallel_terminal.py
```

Paste the result summary or tell Codex the generated RESULTS.json path. If the smoke test fails in your ordinary terminal too, paste its exact output; do not change firewall, seccomp, MPI transports, or kernel settings just to force the test through.

Alternatively, your environment administrator can provide a supported execution profile that permits the local socket creation/listening needed by MPI. Domain-only internet access is not evidence that local MPI listeners are permitted. This session cannot change its managed permission policy. References: https://developers.openai.com/codex/permissions and https://developers.openai.com/codex/security (official OpenAI Docs skill consulted).
