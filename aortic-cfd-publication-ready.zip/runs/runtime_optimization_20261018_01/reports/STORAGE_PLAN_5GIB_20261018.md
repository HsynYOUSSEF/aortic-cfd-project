# 5 GiB storage plan — measured update, 18 October 2026

## Current measured state

The physical Windows C: backing volume was checked with `df -B1 /mnt/c`: 12,885,557,248 bytes free (12.00 GiB). `/tmp` is a separate Linux virtual filesystem and is not used as a proxy for physical capacity. No `pimpleFoam` solver is active.

The retained bounded-test directories measure 476,298,959 bytes (outer-corrector comparison) and 219,657,544 bytes (output-cadence comparison), combined 695,956,503 bytes (0.648 GiB). They are evidence and remain preserved. Existing project/case files are untouched.

## Validated bounded results

The one-outer-corrector case ran 0.04 simulated seconds in 94 s, versus 214 s for two correctors (2.28x faster). Relative L2 differences at the sampled phases were U 0.143%, p 0.052%, WSS 0.616%; maxCo 0.171. This is a short startup sensitivity screen, not cycle accuracy.

The unchanged-timestep cadence test compared .002 s writes with .01 s writes over 0.04 simulated seconds. Both cases passed field, flow-balance, inlet and WSS checks. At five coincident phases, sparse-vs-dense relative L2 was U 0, p 8.45e-11, WSS 0. The saved states reduced from 21 to 5 and measured case footprint from 172,712,679 to 45,821,156 bytes (73.5% smaller), but runtime was 222.5 s versus 210.3 s; less output did not speed up this short test. Full-cycle sampling effects on WSS metrics and particle visualization are still unvalidated. The solver timestep was not changed by output cadence.

## Mesh accuracy and runtime gate

The 128,472-cell uniform staircase candidate differs from the fine startup case by 26.4% U, 7.94% p and 68.5% mapped WSS relative L2, so it is not accuracy-approved. A separate native Gmsh boundary-surface attempt failed `createGeometry()` with `Wrong topology of boundary mesh for parametrization`; the error evidence is retained. No long run may start until a geometry/mesh candidate passes its unchanged gates and its accuracy/sensitivity is measured.

Measured one-corrector throughput on the current coarse mesh is 94 s per 0.04 simulated seconds, about 0.653 h per simulated second (roughly 1.96 h for 3 s by linear extrapolation). This is not a reliable ETA for a different mesh or a periodic simulation; no long-run runtime is being promised.

## Hard-cap feasibility

The 5 GiB aggregate cap is not yet demonstrated feasible. The earlier state-size measurement is 7,922,429 bytes (7.56 MiB) per WSS-complete field state. A .002 s reference over one second would contain about 500 states, approximately 3.70 GiB of state fields alone. Adding retained bounded tests (0.648 GiB), mesh/scratch (previous allowance 0.15 GiB), logs/temporary work (0.10 GiB) and a 0.60 GiB final-checkpoint reserve projects to about 5.20 GiB. This exceeds the cap; it is an estimate from a different run, not a measured peak, and must not be treated as permission to launch.

The .01 s output cadence would use far less storage for two cycles (about 1.5 GiB at the old per-state rate), but periodic-cycle validation alone does not verify that this cadence captures WSS metrics or particle paths accurately. We must preserve the dense reference until the cadence, WSS and particle comparisons pass and evidence is saved. The approved new-case retention policy is therefore still disabled. The failed geometry check also blocks launching the reference cycle on the current candidate.

Possible next step is to design a bounded, evidence-preserving segmented cadence/WSS/particle test whose complete peak footprint, including test cases, is measured below 4.4 GiB (leaving at least 0.6 GiB for a final checkpoint). Do not prune intermediate fields before every required comparison has passed and its report/hash exists. Count all new work and exports toward 5,368,709,120 bytes; watch actual C: free independently. Stop the solver gracefully before 4.4 GiB aggregate use and earlier if C: free requires it. No long or cycle-scale run has been launched.
