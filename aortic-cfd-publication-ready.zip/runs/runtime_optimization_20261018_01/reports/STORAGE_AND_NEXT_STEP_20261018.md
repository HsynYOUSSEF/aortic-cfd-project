# Storage audit and continuation gate — 18 October 2026

## Actual backing storage

The Windows NTFS volume mounted at `/mnt/c` reports 13,235,617,792 bytes available (12.33 GiB) on the latest check. This is the physical C: backing volume; the much larger Linux virtual filesystem figure is not used. A direct Windows PowerShell executable call is unavailable from this WSL shell, so the evidence is `df -B1 /mnt/c` on the NTFS mount.

No process named `pimpleFoam` or `potentialFoam` is running. No benchmark controller is active. The old archive (523 MiB), coarse startup case (110 MiB), and coarse OFAT cases (310 MiB) are all retained because they hold old, validated, or failed-check evidence. No redundant file has been identified, and nothing was deleted.

## Measured storage and estimates

The validated 128,472-cell coarse case has 7,922,429 bytes (7.56 MiB) across U, p, phi, and wallShearStress at one saved time. It writes every 0.002 s. Estimates below are planning envelopes, not measured consumption for a future mesh or video.

| Work | Estimate |
|---|---:|
| Bounded two-case 0.01→0.05 s comparison | about 0.35 GiB expected; hard planning cap 1 GiB including copied mesh, WSS, reports and logs |
| New boundary-fitted coarse mesh plus mesher scratch | reserve 1 GiB (mesh size unmeasured; must inspect after generation) |
| 3 simulated seconds at current 0.002 s cadence | about 11.1 GiB for 1,500 saved states at current per-state size, before case metadata |
| WSS/ParaView wall exports for two cycles | budget 1.5 GiB pending an actual export-size sample |
| 1080p encoded video | budget 1 GiB pending render/encode measurement |
| WSS processing and temporary files | 0.5 GiB |
| Safety reserve | 5 GiB |
| Total at current cadence | about 20.1 GiB |

That leaves an estimated 7.8 GiB shortfall against current free space. The 12.34 GiB is sufficient for the bounded 1 GiB comparison, but not for the full mesh + current-cadence 3-second run + processing/video plan while keeping a 5 GiB reserve. Do not launch a long run at the current write cadence. A lower output cadence is a possible storage optimization, but it must first be benchmarked as a separate factor and checked against phase-resolved U/p/WSS and TAWSS accuracy; it is not approved by this estimate. No redundant data is proposed for deletion.

## Bounded comparison preflight

The attempted `compare_outer_005.py` invocation stopped before creating a case or launching a solver. First it exposed a syntax typo, corrected in the source; `py_compile` now passes. The next preflight then found the active `/usr/bin/python3` lacks both NumPy and VTK. OpenFOAM works after sourcing `/usr/share/openfoam/etc/bashrc`, but the required VTK saved-field validation and spatial comparison cannot run in the current environment. The next run was therefore not started. This preserves the rule that checks must not be bypassed.

Measured one-factor speeds available for planning: coarse baseline 0.01 s in 68.12 s; one outer correction 0.01 s in 32.01 s; both used one CPU core. Extrapolating those measured rates to the planned 0.04 s interval gives about 4.5 minutes (two outer corrections) and 2.1 minutes (one correction); budget 12 minutes for the two solvers plus field checks. These are bounded-test estimates only, not cycle or full-run ETAs. Previous short-window one-outer sensitivity was 0.089% U, 0.039% p and 0.358% WSS against the coarse baseline, but mesh sensitivity remains large (26.4% U, 7.9% p, 68.5% WSS), so no accuracy claim follows.

## User action needed to resume the blocked validation

In a normal Ubuntu terminal (not a privileged or altered Codex sandbox), install the missing analysis packages and native mesher, then report success/output:

```bash
sudo apt update
sudo apt install python3-numpy python3-vtk9 gmsh python3-gmsh
python3 -c 'import numpy, vtk; print(numpy.__version__, vtk.vtkVersion.GetVTKVersion())'
gmsh --version
```

Keep at least 5 GiB free on Windows C: after installation. Do not delete any simulation data to make room; none has been identified as redundant. After the packages are available, rerun only the preflighted bounded comparison in a new uniquely named attempt if the prior attempt directory exists; retain all results and validation reports. Before any longer run, refresh the disk estimate and report the benchmark, expected time, peak disk budget, and accuracy tradeoffs first.
