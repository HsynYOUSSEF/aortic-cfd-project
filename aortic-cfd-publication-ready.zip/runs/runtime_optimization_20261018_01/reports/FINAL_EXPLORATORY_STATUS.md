# Exploratory CFD status

The solver reached 3.0 s and exited normally. Saved-field validation passed for 200 states in the latest two cycles. Flow balance and inlet waveform gates passed.

The phase-resolved periodicity gate failed: WSS relative L2 is 8.8623%, above the unchanged 5% threshold (U 4.2831%, p 3.6457%). The run is therefore **transient**, not periodic, and it was not extended beyond 3 s. Coarse-mesh WSS is unvalidated; the accepted coarse/fine startup discrepancy remains.

1080p video: `/tmp/aortic_exploratory_demo_20261018_01/results/video_1080p_transient/Aortic_Exploratory_Transient_1080p.mp4` (1920x1080, 10 fps, 300 frames, 30 s, 10x slowed playback; all actual saved snapshots shown once, no cycle replay and no temporal field interpolation).

ParaView: `/tmp/aortic_exploratory_demo_20261018_01/cfd/aorta/aorta.foam`, `/tmp/aortic_exploratory_demo_20261018_01/results/paraview/aorta_cycle_2_to_3_instantaneous_WSS_unvalidated.pvd`, `/tmp/aortic_exploratory_demo_20261018_01/results/paraview/aorta_cycle_3_TAWSS_OSI_RRT_unvalidated.pvd`. WSS labels and limitations are in the ParaView README.

Aggregate tracked files including bounded tests: 3,665,654,174 bytes (3.41 GiB) of 5 GiB; Windows C: free 9,197,879,296 bytes. No existing cases/results were removed, and no reference-cycle fields were pruned. The first failed analysis attempt and its partial outputs remain archived.
