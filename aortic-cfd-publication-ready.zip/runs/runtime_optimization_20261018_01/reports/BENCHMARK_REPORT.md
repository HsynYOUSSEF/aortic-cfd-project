# Bounded benchmark results

All cases start at0.01s and end at0.01028s. Results screen a short startup window; they do not establish full-cycle accuracy. Wall times include startup and saved writes. Native profiling is included in JSON. No long run has been launched.

| Factor | Wall seconds | Speedup | Hours per simulated second | Max Co | U / p / WSS relative L2 |
|---|---:|---:|---:|---:|---|
| baseline | 76.02 | 1.00 | 75.41 | 0.704 | 0.000% / 0.000% / 0.000% |
| renumber | 66.01 | 1.15 | 65.49 | 0.704 | 0.000% / 0.065% / 0.003% |
| pressure_smoother | 106.04 | 0.72 | 105.20 | 0.704 | 0.000% / 0.039% / 0.003% |
| pressure_relTol | 86.05 | 0.88 | 85.37 | 0.704 | 0.003% / 0.711% / 0.019% |
| nonorthogonal | 99.96 | 0.76 | 99.16 | 0.704 | 0.004% / 0.029% / 0.034% |
| outer | 40.02 | 1.90 | 39.70 | 0.704 | 0.008% / 0.132% / 0.087% |
| timestep | 50.01 | 1.52 | 49.62 | 1.408 | 0.085% / 0.176% / 0.696% |
| direct_coarsest | 94.02 | 0.81 | 93.28 | 0.704 | 0.000% / 0.000% / 0.000% |
| coarsest_cells | 168.63 | 0.45 | 167.29 | 0.704 | 0.000% / 0.030% / 0.001% |

Projection is local startup throughput, not a completion promise. Final duration must be set by successive1s-cycle agreement. Three seconds would cost three times the hours-per-second column if throughput stayed constant;30s is not automatically required.

Finite U/p/WSS, flow imbalance<0.5%, inlet error<1%, max speed<10m/s were required for every recorded case. Final pressure absolute tolerances unchanged. A startup L2 change below1% is a screening threshold only. Periodic U/p/WSS and TAWSS gates<5% remain mandatory, plus coarse/fine sensitivity.

MPI is unmeasured because managed socket creation is denied. See MPI_USER_ACTION.md for a normal Ubuntu-terminal smoke test and bounded MPI benchmark. No sandbox bypass.
