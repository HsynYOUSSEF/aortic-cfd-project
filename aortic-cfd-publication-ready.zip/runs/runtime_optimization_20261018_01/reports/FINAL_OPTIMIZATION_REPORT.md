> Point-in-time optimization report written before the three-second exploratory run. Its “no long run/final outputs” statements are historical. See sibling `FINAL_STATUS.json` for the later completed transient run.

# Runtime optimization — saved status

All solver processes launched by this task have exited. No long run is active. Every old case, stopped checkpoint, benchmark and failed candidate remains intact.

The original solver stopped gracefully at **0.01261048 s**, with timestep **7.1354045e-5 s** and maximum Courant **0.69965046**. It returned zero and wrote its checkpoint before exiting. Its full archive is `archive/slow_run_complete`; 94 archived files were verified against the stopped source by SHA256. The original 30 s target was not completed.

## Hardware and profiling

The i7-13620H exposes 16 logical CPUs to WSL. RAM is 7.6 GiB. The serial solver used approximately 100% of one core; the guest-wide CPU sample was 7.12%. Peak memory was approximately 1.3 GiB for fine tests and 209 MiB for the coarse outer-correction test.

Native OpenFOAM profiling worked. In the baseline first step, the application took 19.30 s, pressure solves 9.60 s, and the nested coarsest-level pressure solver 8.83 s. Nested timings must not be added together. Renumbering reduced bandwidth from 1,390,859 to 6,263, but its measured speedup was modest.

## Fine-mesh measurements

All tests start at 0.01 s and advance the same 0.00028 s interval. Each changes one factor. Final pressure absolute tolerances remain unchanged. Every recorded test passed finite-field, conservation, inlet and WSS checks. These are startup screens, not full-cycle accuracy evidence.

| Factor | Wall seconds | Speedup |
|---|---:|---:|
| baseline | 76.02 | 1.00× |
| renumber | 66.01 | 1.15× |
| pressure_smoother | 106.04 | 0.72× |
| pressure_relTol | 86.05 | 0.88× |
| nonorthogonal | 99.96 | 0.76× |
| outer | 40.02 | 1.90× |
| timestep | 50.01 | 1.52× |
| direct_coarsest | 94.02 | 0.81× |
| coarsest_cells | 168.63 | 0.45× |

The fastest single fine-mesh change, one outer correction, still projects to **39.7 wall hours per simulated second**. Fine serial execution remains impractical. Pressure smoother, intermediate tolerance, nonorthogonal correction and coarsest-grid changes did not improve measured speed.

## Coarse-mesh measurements and tradeoffs

Three coarse candidates failed full native mesh checks and were retained without flow execution. The uniform 1 mm staircase candidate has 128,472 cells and passed the same full native checks, including cell convexity and all four populated patches. Independent initialization exactly reproduced the established fine-mesh reconstruction, then passed the coarse initial-flow checks.

The coarse baseline reached **0.01 s in 68.12 s**, with five validated saved states. Final flow imbalance was 7.58e-11, inlet error 3.52e-9, maximum velocity 0.4864 m/s, mean WSS 0.3422 Pa, and maximum WSS 3.8028 Pa.

| Isolated coarse change | Wall seconds for 0.01 s | Velocity difference | Pressure difference | WSS difference | 1% sensitivity screen |
|---|---:|---:|---:|---:|---|
| timestep_0004 | 46.01 | 1.362% | 0.658% | 5.146% | REJECTED_SENSITIVITY |
| timestep_0008 | 40.01 | 1.944% | 0.711% | 7.106% | REJECTED_SENSITIVITY |
| outer | 32.01 | 0.089% | 0.039% | 0.358% | PASS_STARTUP_ONLY |

One outer correction projects to **2.67 hours for three simulated seconds** at measured startup throughput. This is not a completion promise: convergence may require more cycles, and throughput may change. The larger timesteps are rejected by the sensitivity screen despite passing conservation and finite-field checks. No combined settings or long run have been selected.

The current coarse geometry has 0.46% less volume, 36.7% more wall area, and 21.1% less area at the smaller outlet. Its startup differences from the fine mesh are **26.4% velocity, 7.9% pressure and 68.5% mapped WSS magnitude**. Mean WSS is 0.3422 Pa versus 0.7917 Pa on the fine mesh. Sampling and nearest-face mapping also limit these comparisons. This is a numerical diagnostic, with no mesh-converged, time-converged or anatomical accuracy claim. A better boundary-fitted mesh is preferable before a long run.

## Storage and supported user actions

**C: has about 575 MiB free. Do not install packages or launch more simulation until space is available.** WSL reports hundreds of GiB of virtual capacity, but its backing disk expanded on C: while storing the benchmark cases. No results were deleted to reclaim space.

1. Free 15–20 GiB on C: without deleting simulation results, or provide another drive as a supported writable workspace. This session can write only the project and `/tmp`; both currently consume the same Windows backing storage.
2. After storage is available, install native Gmsh in an ordinary Ubuntu terminal using `NATIVE_MESHER_USER_ACTION.md`. The old preparation Gmsh runtime contains a Windows DLL, not a usable Linux library. Local package metadata confirms the native Ubuntu packages are available.
3. Run `mpirun -np 2 hostname` in an ordinary Ubuntu terminal and report its output. In this managed session, IPv4 socket creation returns EPERM and PMIx fails before launching ranks. No sandbox override, relay or alternate-transport bypass was attempted. Parallel performance remains unmeasured. `MPI_USER_ACTION.md` contains a bounded, separate-case serial/2/4/8-rank benchmark for a supported terminal.

After storage and meshing support are available, build a fresh boundary-fitted coarse candidate, retain all native/initial/conservation checks, measure flow/velocity/pressure/WSS sensitivity, and report speed and ETA before a long run. Determine duration through successive one-second cycles, requiring conservation, inlet, finite-field, TAWSS and phase-resolved U/p/WSS gates. Existing periodic thresholds remain 5%; a failed check must remain a failure. Three seconds is only the earliest evaluation, not an assumed solution.

## Available outputs

- Original stopped case and logs: `archive/slow_run_complete`.
- Diagnostic WSS in Pa: `diagnostic_outputs/coarse_startup_WSS/startup_WSS_Pa.pvd` (0.002–0.01 s only).
- Full diagnostic ParaView case: `/tmp/aortic_coarse_startup_20261018_03/cfd/aorta/aorta.foam`.
- Detailed measurements: `reports/BENCHMARK_ANALYSIS.json`, `reports/COARSE_OFAT_REVIEW.json`, `reports/COARSE_FINE_STARTUP_SENSITIVITY.json`.
- Restart instructions: `CONTINUATION.md`; machine-readable state: `reports/FINAL_STATUS.json`.

No periodic cycle, final 1080p video, TAWSS/OSI/RRT, or final ParaView export has been completed. The prepared cycle controller remains unlaunched and requires a measured prelaunch report. Its planned video explicitly replays the last validated one-second cycle; replay is not additional simulated time. All large new cases remain in the named Linux directories listed in the continuation file and must be retained.
