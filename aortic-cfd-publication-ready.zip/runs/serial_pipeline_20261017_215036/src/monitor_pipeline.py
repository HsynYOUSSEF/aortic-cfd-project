"""Supervise the authorized serial workflow and persist actual progress and outputs."""
from pathlib import Path
from datetime import datetime,timezone
import subprocess,os,time,json,re,hashlib,traceback,fcntl
coord=Path(__file__).resolve().parents[1];project=coord.parents[1]
lock=(coord/'.monitor.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
env=os.environ.copy();env.update(AORTIC_RANKS='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',AORTIC_STOP_FILE=str(coord/'STOP_REQUESTED'))
manifest={str(p.relative_to(coord)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [coord/'pipeline.sh',*sorted((coord/'src').glob('*.py'))]};(coord/'reports/LAUNCH_SHA256.json').write_text(json.dumps(manifest,indent=2))
started=datetime.now(timezone.utc).isoformat();last_history=0;last_access=0
out=(coord/'logs/launch.log').open('w');process=subprocess.Popen(['bash',str(coord/'pipeline.sh')],cwd=project,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
def readjson(p):
 try:return json.loads(p.read_text())
 except (FileNotFoundError,json.JSONDecodeError):return None
def atomic(p,value):
 tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2));tmp.replace(p)
def numeric_times(case):
 return sorted([float(p.name) for p in case.iterdir() if p.is_dir() and re.fullmatch(r'\d+(?:\.\d+)?',p.name) and all((p/x).is_file() for x in ['U','p','phi'])]) if case.exists() else []
while True:
 code=process.poll();workfile=coord/'WORK_DIRECTORY.txt';work=Path(workfile.read_text().strip()) if workfile.exists() else None;stagefile=coord/'CURRENT_STAGE.txt';stage=stagefile.read_text().strip() if stagefile.exists() else 'launching'
 value={'status':'RUNNING' if code is None else ('COMPLETE' if code==0 else 'STOPPED_OR_FAILED'),'started_utc':started,'updated_utc':datetime.now(timezone.utc).isoformat(),'mode':'serial','stage':stage,'target_simulation_duration_s':30,'work_directory':str(work) if work else None,'pipeline_returncode':code,'full_simulation_complete':False,'completed_simulation_duration_s':None,'old_results_preserved':True,'validation_checks_bypassed':False}
 if work:
  logs=list((work/'logs').glob('*_solver.log'));solverlog=max(logs,key=lambda p:p.stat().st_mtime) if logs else None
  if solverlog:
   with solverlog.open('rb') as stream:stream.seek(max(0,solverlog.stat().st_size-131072));text=stream.read().decode(errors='replace')
   current=None;complete=None
   for line in text.splitlines():
    if line.startswith('Time = '):
     try:current=float(line.split('=',1)[1])
     except ValueError:pass
    elif line.startswith('ExecutionTime = '):complete=current
   dt=re.findall(r'^deltaT\s*=\s*([^\s]+)',text,re.M);co=re.findall(r'^Courant Number mean:\s*([^\s]+)\s+max:\s*([^\s]+)',text,re.M)
   value.update(solver_log=str(solverlog),latest_logged_time_s=current,latest_completed_step_time_s=complete,latest_timestep_s=float(dt[-1]) if dt else None,latest_max_Courant=float(co[-1][1]) if co else None)
  times=numeric_times(work/'cfd/aorta');value.update(latest_saved_time_s=times[-1] if times else None,saved_time_count=len(times),paraview_work_case=str(work/'cfd/aorta/aorta.foam'),mesh_gate=readjson(work/'reports/mesh_check.json'),initialization_gate=readjson(work/'reports/initialization_verification.json'))
  for name in ['short','bridge','full']:
   result=readjson(work/'reports'/f'{name}_solver_result.json')
   if result:value[name+'_solver_result']=result
  value['phase_periodicity']=readjson(work/'reports/phase_periodicity.json');value['deliverable_validation']=readjson(work/'reports/deliverable_validation.json')
  # Keep this actively used, new /tmp work tree accessed during a long calculation.
  # Only access timestamps are refreshed; simulation contents and mtimes are preserved.
  if time.monotonic()-last_access>3600:
   for p in [work,*work.rglob('*')]:
    try:st=p.stat();os.utime(p,ns=(time.time_ns(),st.st_mtime_ns))
    except FileNotFoundError:pass
   last_access=time.monotonic()
 if code is not None:
  log=(coord/'logs/launch.log').read_text(errors='replace');matches=re.findall(r'^COMPLETE: (.+)$',log,re.M)
  if code==0:
   assert matches,'Successful pipeline did not report an export path';dest=Path(matches[-1]);assert (dest/'reports/COMPLETE.txt').is_file();assert value.get('deliverable_validation',{}).get('status')=='PASS'
   value.update(full_simulation_complete=True,completed_simulation_duration_s=30,final_output_directory=str(dest),final_paraview=str(dest/'cfd/aorta/aorta.foam'),final_video=str(dest/'results/final_video/Aortic_Flow_And_Instantaneous_WSS_1080p.mp4'),final_wall_series_Pa=str(dest/'results/aorta/wall_WSS_Pa.pvd'),final_wall_metrics=str(dest/'results/aorta/wall_metrics.vtp'))
   cfg=readjson(dest/'run_config.json');cfg['run_status']='COMPLETE';atomic(dest/'run_config.json',cfg);atomic(coord/'reports/FINAL_OUTPUTS.json',value)
  else:value['failure_log_tail']=log[-8000:]
 atomic(coord/'reports/STATUS.json',value);atomic(project/'reports/SERIAL_PIPELINE_STATUS.json',value)
 if time.monotonic()-last_history>60 or code is not None:
  with (coord/'logs/progress.jsonl').open('a') as stream:stream.write(json.dumps(value)+'\n')
  last_history=time.monotonic()
 if code is not None:break
 time.sleep(5)
out.close()
