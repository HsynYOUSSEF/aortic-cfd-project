from pathlib import Path
import sys,json,subprocess,xml.etree.ElementTree as ET
import numpy as np
import vtk
from vtk.util.numpy_support import vtk_to_numpy
root=Path(sys.argv[1]).resolve();case=root/'cfd/aorta';out=root/'results/aorta';video=root/'results/final_video/Aortic_Flow_And_Instantaneous_WSS_1080p.mp4'
assert json.loads((root/'reports/phase_periodicity.json').read_text())['status']=='PASS'
summary=json.loads((out/'summary.json').read_text());assert summary['conservation_under_0_5_percent'] and summary['cycle_change_under_5_percent'] and summary['max_relative_inlet_waveform_error']<.01
assert json.loads((root/'reports/final_saved_field_validation.json').read_text())['status']=='SAVED_FIELD_CHECKS_PASS'
assert all((case/'30'/name).is_file() for name in ['U','p','phi','wallShearStress'])
entries=[]
for t in np.linspace(29,30,21):
 name=f'wall_{t:g}.vtp';p=out/name;assert p.exists();r=vtk.vtkXMLPolyDataReader();r.SetFileName(str(p));r.Update();wall=r.GetOutput();tau=wall.GetCellData().GetArray('WSS_Pa');assert wall.GetNumberOfCells()>0 and tau is not None and np.isfinite(vtk_to_numpy(tau)).all()
 entries.append(f'<DataSet timestep="{t:g}" group="" part="0" file="{name}"/>')
pvd=out/'wall_WSS_Pa.pvd';pvd.write_text('<?xml version="1.0"?><VTKFile type="Collection" version="0.1" byte_order="LittleEndian"><Collection>'+''.join(entries)+'</Collection></VTKFile>');assert len(ET.parse(pvd).getroot().find('Collection'))==21
r=vtk.vtkXMLPolyDataReader();r.SetFileName(str(out/'wall_metrics.vtp'));r.Update();d=r.GetOutput().GetCellData();taw=vtk_to_numpy(d.GetArray('TAWSS_Pa'));osi=vtk_to_numpy(d.GetArray('OSI'));rrt=vtk_to_numpy(d.GetArray('RRT_Pa_inverse'));active=taw>1e-12
assert np.isfinite(taw).all() and (taw>=0).all();assert np.isfinite(osi[active]).all() and ((osi[active]>=0)&(osi[active]<=.5)).all();assert (rrt>=0).all()
probe=subprocess.run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(video)],capture_output=True,text=True,check=True);info=json.loads(probe.stdout);(video.parent/'ffprobe.json').write_text(probe.stdout);stream=next(x for x in info['streams'] if x['codec_type']=='video');assert (stream['width'],stream['height'],stream['r_frame_rate'],int(stream['nb_frames']))==(1920,1080,'30/1',900);assert abs(float(info['format']['duration'])-30)<.01
metadata=json.loads((video.parent/'render_details.json').read_text());assert metadata['particles']==4000 and metadata['minimum_valid_tracers']>=2000 and metadata['velocity_cycle_s']==[29,30]
result={'status':'PASS','completed_simulation_duration_s':30,'periodicity_cycles_s':[[28,29],[29,30]],'video':str(video),'video_duration_s':30,'video_frames':900,'video_resolution':[1920,1080],'video_fps':30,'paraview':str(case/'aorta.foam'),'wall_series_Pa':str(pvd),'wall_metrics':str(out/'wall_metrics.vtp'),'all_new_saved_times_preserved':True,'interpretation':'Exploratory rigid-wall laminar Newtonian simulation with synthetic inflow and repaired geometry. The video repeats the final one-second solved cycle at slower playback.'}
(root/'reports/deliverable_validation.json').write_text(json.dumps(result,indent=2));cfg=json.loads((root/'run_config.json').read_text());cfg.update(run_status='VALIDATED_PENDING_DESKTOP_EXPORT',completed_simulation_duration_s=30);(root/'run_config.json').write_text(json.dumps(cfg,indent=2));print(json.dumps(result,indent=2))
