"""Bounded solver execution; terminate only the process group launched here."""
from pathlib import Path
import argparse,subprocess,time,re,json,os,signal,math,shutil
p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('--target',type=float,required=True);p.add_argument('--budget',type=float,required=True);p.add_argument('--stage',required=True);p.add_argument('--ranks',type=int,default=1);a=p.parse_args()
case=a.root/'cfd/aorta';log=a.root/'logs'/f'{a.stage}_solver.log';command=['pimpleFoam','-case',str(case),'-noFunctionObjects']
if a.ranks>1:command=['mpirun','-np',str(a.ranks)]+command+['-parallel']
def latest(s,label):
 m=re.findall(r'^'+label+r'\s*=\s*([^\s]+)',s,re.M);return float(m[-1]) if m else None
start=time.monotonic();progress=start;printed=0;previous=None;reason=None
with log.open('w') as stream:
 process=subprocess.Popen(command,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 try:
  while process.poll() is None:
   time.sleep(2)
   with log.open('rb') as f:f.seek(max(0,log.stat().st_size-131072));tail=f.read().decode(errors='replace')
   now=time.monotonic();t=latest(tail,'Time');dt=latest(tail,'deltaT')
   if t is not None and (previous is None or t>previous+1e-12):progress=now;previous=t
   if now-printed>30:print(f'{a.stage}: elapsed {now-start:.0f} s; simulated {t} / {a.target}; dt {dt}',flush=True);printed=now
   if 'FOAM FATAL' in tail or re.search(r'\b(?:nan|inf)\b',tail,re.I):reason='Fatal or non-finite output'
   if dt is not None and (not math.isfinite(dt) or dt<=0 or (dt<1e-8 and (t is None or t<a.target-1e-7))):reason='Timestep collapsed below 1e-8 s'
   if now-progress>360:reason='No simulated-time progress for six minutes'
   if now-start>a.budget:reason='Configured wall-time budget reached'
   stopfile=os.environ.get('AORTIC_STOP_FILE')
   if stopfile and Path(stopfile).exists():reason='Explicit stop request'
   if shutil.disk_usage(a.root).free<3*1024**3:reason='Linux working disk below 3 GiB reserve'
   if reason:break
 finally:
  if process.poll() is None:
   os.killpg(process.pid,signal.SIGTERM)
   try:process.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
text=log.read_text(errors='replace');t=latest(text,'Time');passed=process.returncode==0 and reason is None and t is not None and abs(t-a.target)<1e-7 and re.search(r'^End\s*$',text,re.M) is not None
report={'status':'SOLVER_TARGET_REACHED' if passed else 'STOPPED','stage':a.stage,'target_s':a.target,'simulated_time_s':t,'elapsed_seconds':time.monotonic()-start,'returncode':process.returncode,'reason':reason,'command':command,'interpretation':'Solver completion is only one gate; saved-field, conservation, periodic-cycle and rendering gates remain required.'}
(a.root/'reports'/f'{a.stage}_solver_result.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
raise SystemExit(0 if passed else 1)
