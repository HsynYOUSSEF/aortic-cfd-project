"""Phase-resolved periodicity, in addition to the original TAWSS gate."""
from pathlib import Path
import sys,json
import numpy as np
import vtk
sys.path.insert(0,str(Path(__file__).resolve().parent))
import analyze_results as a
root=Path(sys.argv[1]).resolve();cfg=json.loads((root/'run_config.json').read_text());end=float(cfg['end_time_s']);rho=float(cfg['density_kg_m3']);r=a.reader(root/'cfd/aorta')
expected=np.linspace(end-1,end,21);available=a.vtk_to_numpy(r.GetTimeValues());assert all(np.min(abs(available-t))<1e-7 for t in np.r_[expected,expected-1]),'Missing matching phases'
records=[];volume=None;area=None
for t in expected:
 arrays=[]
 for timepoint in [t,t-1]:
  mesh,patches=a.fields(r,timepoint);wall=patches['aorta_wall']
  if volume is None:
   size=vtk.vtkCellSizeFilter();size.SetInputData(mesh);size.Update();volume=a.vtk_to_numpy(size.GetOutput().GetCellData().GetArray('Volume')).astype(float).copy();area=a.areas(wall).astype(float)
   assert np.isfinite(volume).all() and (volume>0).all() and (area>0).all()
  u=a.vtk_to_numpy(mesh.GetCellData().GetArray('U')).astype(float).copy();p=a.vtk_to_numpy(mesh.GetCellData().GetArray('p')).astype(float).copy()*rho;tau=a.vtk_to_numpy(wall.GetCellData().GetArray('wallShearStress')).astype(float).copy()*rho
  assert all(np.isfinite(x).all() for x in [u,p,tau]);arrays.append((u,p,tau))
 current,prior=arrays;row=[]
 for x,y,weight in zip(current,prior,[volume,volume,area]):
  delta=(x-y)**2;reference=x*x
  if delta.ndim==2:delta=delta.sum(1);reference=reference.sum(1)
  row.extend([float(weight@delta),float(weight@reference)])
 records.append(row)
values=np.trapezoid(np.asarray(records),expected,axis=0);relative=[]
for num,den in zip(values[::2],values[1::2]):relative.append(float(np.sqrt(num/den)) if den>0 else (0.0 if num==0 else float('inf')))
result={'status':'PASS' if all(np.isfinite(x) and x<.05 for x in relative) else 'FAIL','current_cycle_s':[end-1,end],'prior_cycle_s':[end-2,end-1],'paired_phases':21,'threshold_relative_L2':.05,'velocity_volume_time_relative_L2':relative[0],'pressure_volume_time_relative_L2':relative[1],'WSS_area_time_relative_L2':relative[2],'note':'Additional phase-resolved gates; original conservation, inlet and TAWSS cycle-change gates remain required. Mesh/time-step convergence and anatomical accuracy are not established.'}
(root/'reports/phase_periodicity.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));raise SystemExit(0 if result['status']=='PASS' else 1)
