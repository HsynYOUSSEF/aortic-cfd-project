"""One-time startup report. Reads files only; never starts or controls a solver."""
from pathlib import Path
from datetime import datetime,timezone
import json,time,re,fcntl,traceback
coord=Path(__file__).resolve().parents[1];project=coord.parents[1];work=Path((coord/'WORK_DIRECTORY.txt').read_text().strip())
lock=(coord/'.startup_report.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
md=project/'reports/STARTUP_STAGE_REPORT_20261018.md';js=project/'reports/STARTUP_STAGE_REPORT_20261018.json';continuation=project/'reports/STARTUP_CONTINUATION_20261018.md'
def read(p):
 try:return json.loads(p.read_text())
 except (FileNotFoundError,json.JSONDecodeError):return None
def write(p,value):
 temp=p.with_suffix(p.suffix+'.tmp');temp.write_text(json.dumps(value,indent=2));temp.replace(p)
def now():return datetime.now(timezone.utc).isoformat()
def series():
 data=(work/'logs/short_solver.log').read_text(errors='replace');rows=[];t=None
 for line in data.splitlines():
  if line.startswith('Time = '):t=float(line.split('=',1)[1])
  elif line.startswith('ExecutionTime = '):
   m=re.search(r'ExecutionTime = ([0-9.eE+-]+) s\s+ClockTime = ([0-9.eE+-]+) s',line)
   if m and t is not None:rows.append((t,float(m[2]),float(m[1])))
 return rows
previous=read(js)
if previous and previous.get('status') in ['STARTUP_VALIDATED','STARTUP_FAILED']:raise SystemExit('Startup already reported; no duplicate watcher needed')
write(js,{'status':'WAITING_FOR_EXISTING_STARTUP','requested_utc':now(),'check_interval_seconds':300,'work_directory':str(work),'new_solver_launched':False})
md.write_text(f'''# Startup-stage report — pending\n\nThe existing conservative serial startup test has not yet completed. This file will receive one report after its solver and saved-field/WSS validation finish, or after a failure. No additional solver is started.\n\nA local helper checks the result files every five minutes; it makes no Codex/model/API calls. The existing instability watchdog remains active.\n\nWorking case: `{work}/cfd/aorta`\n\nContinuation instructions: `{continuation}`\n\nLive pipeline state: `{project/'reports/SERIAL_PIPELINE_STATUS.json'}`\n''')
while True:
 solver=read(work/'reports/short_solver_result.json');saved=read(work/'reports/saved_field_validation.json');state=read(coord/'reports/STATUS.json') or {}
 reached=bool(solver and solver.get('status')=='SOLVER_TARGET_REACHED' and abs(solver.get('simulated_time_s',-1)-.01)<1e-8)
 fields=(saved or {}).get('fields',[])
 accepted=bool(saved and saved.get('status')=='SAVED_FIELD_CHECKS_PASS' and len(fields)>=5 and abs(fields[-1]['time_s']-.01)<1e-8)
 failed=bool((solver and not reached) or state.get('status')=='STOPPED_OR_FAILED')
 if reached and accepted or failed:
  mesh=read(work/'reports/mesh_check.json');init=read(work/'reports/initialization_verification.json');passed=reached and accepted and (mesh or {}).get('status')=='PASS' and (init or {}).get('status')=='INDEPENDENT_INITIAL_FLOW_CHECK_PASS'
  rows=series();last=rows[-1] if rows else None;elapsed=(solver or {}).get('elapsed_seconds');estimates={}
  if passed and elapsed:
   estimates['whole_startup_average_simulated_s_per_wall_s']=.01/elapsed
   estimates['remaining_30s_solve_days_at_whole_startup_average']=(30-.01)*elapsed/.01/86400
   if len(rows)>1:
    first=rows[max(0,len(rows)-31)];dt=last[0]-first[0];wall=last[1]-first[1]
    if dt>0 and wall>0:
     estimates.update(recent_window_completed_steps=min(30,len(rows)-1),recent_window_simulated_seconds=dt,recent_window_wall_seconds=wall,recent_simulated_s_per_wall_s=dt/wall,remaining_30s_solve_days_at_recent_rate=(30-.01)*wall/dt/86400)
   estimates['interpretation']='Linear runtime projections at measured startup rates, not a reliable ETA. Future adaptive timesteps and flow speeds can change the rate substantially. WSS analysis, video rendering and export time are excluded.'
  completed=now();startup_wall=None
  if accepted and state.get('started_utc'):
   startup_wall=(work/'reports/saved_field_validation.json').stat().st_mtime-datetime.fromisoformat(state['started_utc']).timestamp()
  result={'status':'STARTUP_VALIDATED' if passed else 'STARTUP_FAILED','reported_utc':completed,'work_directory':str(work),'new_solver_launched':False,'full_simulation_complete':False,'startup_target_s':.01,'startup_completed_simulated_time_s':(solver or {}).get('simulated_time_s',last[0] if last else None),'solver_elapsed_wall_seconds':elapsed,'pipeline_launch_to_startup_validation_seconds':startup_wall,'mesh_validation':mesh,'initialization_validation':init,'startup_solver_result':solver,'saved_fields_validated':accepted,'saved_field_count':len(fields),'max_relative_flow_imbalance':max((x['relative_flow_imbalance'] for x in fields),default=None),'max_relative_inlet_waveform_error':max((x['relative_inlet_waveform_error'] for x in fields),default=None),'peak_saved_speed_m_s':max((x['peak_speed_m_s'] for x in fields),default=None),'final_saved_field':fields[-1] if fields else None,'full_simulation_runtime_projections':estimates,'pipeline_state_at_report':state,'continuation_instructions':str(continuation)}
  write(js,result)
  lines=['# Startup-stage report',f'Reported: {completed}',f"**{result['status']}**. No additional solver was launched.",f"Completed startup simulated time: {result['startup_completed_simulated_time_s']} s; target: 0.01 s.",f'Solver elapsed wall runtime: {elapsed} seconds ({elapsed/3600:.3f} hours).' if elapsed is not None else 'Solver elapsed runtime: unavailable; inspect failure logs.',f'Pipeline launch through startup validation: {startup_wall:.1f} seconds.' if startup_wall is not None else 'Startup validation did not finish.',f"Mesh gate: {(mesh or {}).get('status','missing')}; independent initialization gate: {(init or {}).get('status','missing')}; saved-field/WSS gate: {'PASS' if accepted else 'not passed'}; complete validated snapshots: {len(fields)}."]
  if fields:lines.extend([f"Worst relative flow imbalance: {result['max_relative_flow_imbalance']:.8g} (limit 0.005).",f"Worst relative inlet-waveform error: {result['max_relative_inlet_waveform_error']:.8g} (limit 0.01).",f"Maximum saved velocity magnitude: {result['peak_saved_speed_m_s']:.8g} m/s (limit 10).",'WSS dimensions were checked and converted once by density 1060 kg/m3 to Pa.'])
  if estimates:
   lines.append(f"Remaining solve to 30 s at the whole-startup average rate: {estimates['remaining_30s_solve_days_at_whole_startup_average']:.2f} days.")
   if 'remaining_30s_solve_days_at_recent_rate' in estimates:lines.append(f"Remaining solve at the recent completed-step rate: {estimates['remaining_30s_solve_days_at_recent_rate']:.2f} days.")
   lines.append(estimates['interpretation'])
  else:lines.append('No full-run ETA is asserted because startup did not pass.')
  lines.extend([f"Pipeline stage at report: {state.get('stage')}; state: {state.get('status')}. The previously authorized pipeline continues automatically unless a required check fails. No stop or restart was requested.",'The full 30-s simulation, periodic-cycle validation and final 1080p particle/ParaView exports are not established by this startup report.',f'Continuation instructions: `{continuation}`.',f'Detailed numerical results: `{js}`.',f"Failure log tail, if any: {state.get('failure_log_tail','none reported')}."])
  md.write_text('\n\n'.join(lines)+'\n')
  with continuation.open('a') as f:f.write(f'\n\n## Startup report completed\n\nAt {completed}, the one-time reporter recorded **{result["status"]}**. Read `{md}` and `{js}` for validation results, elapsed runtime and computational projections. Continue checking the existing managed pipeline; do not launch a new solver.\n')
  write(coord/'reports/STARTUP_REPORT_WATCHER_STATUS.json',{'status':'REPORT_WRITTEN','reported_utc':completed,'report':str(md),'new_solver_launched':False});print(str(md),flush=True);break
 write(coord/'reports/STARTUP_REPORT_WATCHER_STATUS.json',{'status':'WAITING','last_check_utc':now(),'next_check_after_seconds':300,'new_solver_launched':False})
 for _ in range(5):time.sleep(60)
