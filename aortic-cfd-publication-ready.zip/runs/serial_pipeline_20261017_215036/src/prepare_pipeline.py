from pathlib import Path
import re,shutil
coord=Path(__file__).resolve().parents[1];project=coord.parents[1];source=project/'runs/runtime_repair_20261017_01'
s=(source/'continue_parallel.sh').read_text()
s=s.replace('SOURCE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"\nPROJECT="$(cd "$SOURCE/../.." && pwd)"', 'COORD="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"\nPROJECT="$(cd "$COORD/../.." && pwd)"\nSOURCE="$PROJECT/runs/runtime_repair_20261017_01"\nexport COORD\nexec 9>"$COORD/.pipeline.lock"\nflock -n 9 || { echo "Pipeline already active"; exit 2; }')
s=s.replace('RANKS="${AORTIC_RANKS:-8}"','RANKS="${AORTIC_RANKS:-1}"')
s=s.replace('/tmp/aortic_validated_XXXXXXXX','/tmp/aortic_serial_XXXXXXXX')
s=s.replace('export WORK SOURCE PROJECT RANKS','printf \'%s\\n\' "$WORK" > "$COORD/WORK_DIRECTORY.txt"\nexport WORK SOURCE PROJECT RANKS')
s=s.replace('STAGE=preparation', '''set_stage() {
  STAGE="$1"
  printf '%s\\n' "$STAGE" > "$COORD/CURRENT_STAGE.txt"
  echo "PIPELINE_STAGE=$STAGE"
  if [[ -f "$COORD/STOP_REQUESTED" ]]; then echo 'Explicit stop request received'; exit 130; fi
}
set_stage preparation''')
s=re.sub(r'^STAGE=(.+)$',r'set_stage \1',s,flags=re.M)
s=s.replace('--budget 2700 --stage short','--budget "${AORTIC_SHORT_BUDGET_SECONDS:-10800}" --stage short')
s=s.replace('--budget 2700 --stage bridge','--budget "${AORTIC_BRIDGE_BUDGET_SECONDS:-21600}" --stage bridge')
s=s.replace('--budget 172800 --stage full','--budget "${AORTIC_FULL_BUDGET_SECONDS:-7776000}" --stage full')
# Changes are confined to the new working copy; preserve all earlier scripts/results.
s=s.replace("STAGE='decomposition'", "STAGE='decomposition'")
insert='''
# Use reviewed, serial-aware watchdog and additional final-result checks.
cp "$COORD/src/watch_run.py" "$WORK/src/watch_run.py"
cp "$COORD/src/check_periodicity.py" "$WORK/src/check_periodicity.py"
cp "$COORD/src/check_deliverables.py" "$WORK/src/check_deliverables.py"
"$PY" - "$WORK" <<'PYPATCH'
from pathlib import Path
import sys
root=Path(sys.argv[1]);p=root/'src/validate_saved_fields.py';s=p.read_text()
s=s.replace("ap.add_argument('--minimum-times',type=int,default=1);", "ap.add_argument('--minimum-times',type=int,default=1);ap.add_argument('--minimum-time',type=float,default=0);ap.add_argument('--report-name',default='saved_field_validation.json');")
s=s.replace("if not (folder/'wallShearStress').exists():continue", "if float(folder.name)<args.minimum_time-1e-8:continue\\n if not (folder/'wallShearStress').exists():continue")
s=s.replace("'SAVED_INITIAL_TRANSIENT_CHECKS_PASS'", "'SAVED_FIELD_CHECKS_PASS'")
s=s.replace("root/'reports/saved_field_validation.json'", "root/'reports'/args.report_name")
s=s.replace("'Initial transient diagnostics only; no TAWSS, OSI, RRT or converged-cycle claims.'", "'Saved-field gate only; periodic-cycle validation is a separate required gate.'")
p.write_text(s)
PYPATCH
'''
s=s.replace("set_stage 'native mesh validation'",insert+"\nset_stage 'native mesh validation'")
s=s.replace('test -f "$WORK/cfd/aorta/0.05/p"', '''test -f "$WORK/cfd/aorta/0.05/p"
LD_PRELOAD="$WORK/src/libsha1_compat.so" pimpleFoam -case "$WORK/cfd/aorta" -postProcess -func wallShearStress -time 0.05 > "$WORK/logs/WSS_bridge.log" 2>&1
"$PY" "$WORK/src/validate_saved_fields.py" "$WORK" --require-end .05 --minimum-times 6 --report-name bridge_saved_field_validation.json > "$WORK/logs/validate_bridge.log" 2>&1''')
s=s.replace('"$PY" "$WORK/src/analyze_results.py"', '''set_stage 'final saved-field and periodic-cycle validation'
"$PY" "$WORK/src/validate_saved_fields.py" "$WORK" --minimum-time 28 --require-end 30 --minimum-times 41 --report-name final_saved_field_validation.json > "$WORK/logs/validate_final_fields.log" 2>&1
"$PY" "$WORK/src/analyze_results.py"''')
s=s.replace("set_stage 'actual 1080p flow/WSS video'", '''"$PY" "$WORK/src/check_periodicity.py" "$WORK" > "$WORK/logs/phase_periodicity.log" 2>&1
set_stage 'actual 1080p flow/WSS video' ''')
s=s.replace("set_stage 'export validated final fields to Desktop'", '''"$PY" "$WORK/src/check_deliverables.py" "$WORK" > "$WORK/logs/check_deliverables.log" 2>&1
set_stage 'export validated final fields to Desktop' ''')
s=s.replace("(target/'aorta.foam').touch();", "(target/'aorta.foam').touch();")
(coord/'pipeline.sh').write_text(s)
# Watchdog retains collapse/non-finite/non-progress stops; serial budgets are wall-clock allowances.
w=(source/'src/watch_run.py').read_text();w=w.replace('import argparse,subprocess,time,re,json,os,signal,math','import argparse,subprocess,time,re,json,os,signal,math,shutil')
w=w.replace("if dt is not None and (not math.isfinite(dt) or dt<1e-8):", "if dt is not None and (not math.isfinite(dt) or dt<=0 or (dt<1e-8 and (t is None or t<a.target-1e-7))):")
w=w.replace('if reason:break', '''stopfile=os.environ.get('AORTIC_STOP_FILE')
   if stopfile and Path(stopfile).exists():reason='Explicit stop request'
   if shutil.disk_usage(a.root).free<3*1024**3:reason='Linux working disk below 3 GiB reserve'
   if reason:break''')
(coord/'src/watch_run.py').write_text(w)
print(coord/'pipeline.sh')
