# Authorized serial continuation

The user explicitly authorized serial solving, preservation of old results, instability monitoring, periodic-cycle validation, and final 1080p particle/ParaView outputs.

This controller launches one fresh case on the Linux disk. `WORK_DIRECTORY.txt` records its location. `reports/STATUS.json` and the project `reports/SERIAL_PIPELINE_STATUS.json` report actual progress. `logs/progress.jsonl` retains progress history. `reports/FINAL_OUTPUTS.json` is created only after the full workflow succeeds, and reports the completed simulation duration and final output paths. No previous case or result is deleted or overwritten.

The intended simulated duration is 30 seconds. The final two cycles (28–30 s) must pass the existing <0.5% conservation, <1% inflow waveform, <5% TAWSS cycle-change gates, and finite-field/velocity checks. Additional phase-resolved velocity, pressure and WSS comparisons must each differ by <5% between the final cycles. WSS units are checked and converted to Pa exactly once. Video checks require 1920×1080, 30 fps, 900 frames, successful decoding, 4,000 tracers and at least 2,000 valid tracers throughout. Actual final wall VTPs and Pa-valued PVD references are read back.

The conservative two-outer/two-nonorthogonal-corrector configuration is retained. The numerical/validation thresholds are unchanged; only wall-clock limits have been scaled for the explicitly authorized serial computation: 3 hours for the new 0.01-s baseline test, 6 hours for reaching 0.05 s, and 90 days maximum for the full solve. These are resource allowances, not claims that those stages will need the entire allowance or complete within a particular ETA. Startup measurements indicate a potentially very long full run. Fatal/non-finite output, timestep collapse below 1e-8 s before the endpoint, lack of progress for six minutes, or low Linux disk space stop the solver. No failed validation is skipped and no automatic rerun suppresses failure.

All newly saved times remain on the Linux work disk (`purgeWrite 0`). A separate new Desktop case containing initial fields and the final two cycles, wall metrics and video is exported only after all gates pass and Desktop space is checked. A full simulation duration is never inferred merely from an empty .foam marker or an intended end time.

`STOP_REQUESTED` is an optional explicit stop-request file for this job. No stop request is currently present. This is a direct local serial workflow; no MPI, network workaround, command relay, system installation or external service is used.
