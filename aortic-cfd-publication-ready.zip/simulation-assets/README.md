# Current simulation publication

The 19 October publication hold is superseded by the owner’s 21 October upload request and the publisher’s explicit CC BY 4.0 statement. See [current upload scope](../UPLOAD_STATUS.md), [attribution](../data/original/ATTRIBUTION.md), and [verified file manifest](../PUBLICATION_MANIFEST.json). The historical inventory.json records the earlier local-preservation audit; its uploaded=false flags describe 19 October, not current publication. Full CFD fields remain local.
