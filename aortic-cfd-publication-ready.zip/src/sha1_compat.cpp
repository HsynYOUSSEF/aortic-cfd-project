// Legacy OpenFOAM SHA1 stream-buffer overflow compatibility with modern libstdc++.
// Follows upstream fix intent: OpenFOAM-9 commit b0c15bebd37142f3902901ed5e9a60e33ed456eb.
#include <streambuf>
#include <typeinfo>
#include <cstring>
extern "C" int compat_overflow(std::streambuf*,int) asm("_ZNSt15basic_streambufIcSt11char_traitsIcEE8overflowEi");
extern "C" int compat_overflow(std::streambuf* buf,int c) {
 if (std::strstr(typeid(*buf).name(),"sha1") && c!=std::char_traits<char>::eof()) {
  const char cc=std::char_traits<char>::to_char_type(c);
  return buf->sputn(&cc,1)==1 ? c : std::char_traits<char>::eof();
 }
 return std::char_traits<char>::eof();
}
