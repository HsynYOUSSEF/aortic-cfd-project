"""Non-adjacent triangle intersection check and basic closed-surface checks."""
from pathlib import Path
import json,time
import numpy as np
import vtk
from vtk.util.numpy_support import vtk_to_numpy
from prepare_case import ROOT,topology

def coplanar_overlap(a,b,tol):
 normal=np.cross(a[1]-a[0],a[2]-a[0]);drop=int(np.argmax(abs(normal)));a=np.delete(a,drop,1);b=np.delete(b,drop,1)
 for tri in [a,b]:
  for i in range(3):
   edge=tri[(i+1)%3]-tri[i];axis=np.array([-edge[1],edge[0]]);norm=np.linalg.norm(axis)
   if norm==0:continue
   axis/=norm;pa=a@axis;pb=b@axis
   if min(pa.max(),pb.max())-max(pa.min(),pb.min())<=tol:return False
 return True

def main():
 start=time.time();reader=vtk.vtkXMLPolyDataReader();reader.SetFileName(str(ROOT/'geometry/CFD_surface_SI.vtp'));reader.Update();poly=reader.GetOutput();pts=vtk_to_numpy(poly.GetPoints().GetData());faces=vtk_to_numpy(poly.GetPolys().GetData()).reshape(-1,4)[:,1:];xyz=pts[faces]
 mins=xyz.min(1);maxs=xyz.max(1);tol=1e-10;loc=vtk.vtkStaticCellLocator();loc.SetDataSet(poly);loc.BuildLocator();ids=vtk.vtkIdList();intersections=[];tested=0
 for i,triangle in enumerate(xyz):
  bounds=[mins[i,0]-tol,maxs[i,0]+tol,mins[i,1]-tol,maxs[i,1]+tol,mins[i,2]-tol,maxs[i,2]+tol];loc.FindCellsWithinBounds(bounds,ids)
  candidates=np.array([ids.GetId(k) for k in range(ids.GetNumberOfIds()) if ids.GetId(k)>i],dtype=int)
  if not len(candidates):continue
  candidates=candidates[np.all(maxs[candidates]+tol>=mins[i],axis=1)&np.all(mins[candidates]-tol<=maxs[i],axis=1)]
  for j in candidates:
   if np.any(faces[j,:,None]==faces[i,None,:]):continue
   tested+=1;cop=vtk.reference(0);p1=[0.,0.,0.];p2=[0.,0.,0.];surface_id=[0.,0.]
   hit=vtk.vtkIntersectionPolyDataFilter.TriangleTriangleIntersection(*triangle.tolist(),*xyz[j].tolist(),cop,p1,p2,surface_id,tol)
   if (int(cop) and coplanar_overlap(triangle,xyz[j],tol)) or (hit and not int(cop)):
    intersections.append([int(i),int(j)])
    if len(intersections)>=100:break
  if len(intersections)>=100:break
  if i and i%20000==0:print(f'Checked {i}/{len(faces)} triangles',flush=True)
 t=topology(poly);cross=np.cross(xyz[:,1]-xyz[:,0],xyz[:,2]-xyz[:,0]);areas=np.linalg.norm(cross,axis=1)/2;volume=np.sum(np.einsum('ij,ij->i',xyz[:,0],np.cross(xyz[:,1],xyz[:,2])))/6
 result={'checked_surface':'geometry/CFD_surface_SI.vtp','topology':t,'nonadjacent_triangle_pairs_tested':tested,'nonadjacent_intersections_found':len(intersections),'intersection_pairs_first_100':intersections,'triangle_area_min_m2':float(areas.min()),'signed_enclosed_volume_m3':float(volume),'elapsed_seconds':time.time()-start,'scope':'Excludes triangles sharing any vertex; coplanar tests require positive overlap area. Does not certify anatomy or volume mesh quality.'}
 passed=not intersections and t['boundary_edges']==0 and t['nonmanifold_edges']==0 and t['surface_regions']==1 and areas.min()>1e-18 and volume>0
 result['status']='PASS' if passed else 'FAIL';(ROOT/'reports/surface_check.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));raise SystemExit(0 if passed else 1)

if __name__=='__main__':main()
