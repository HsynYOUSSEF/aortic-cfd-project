"""Verify the immutable prepared inputs before solving; generated results are excluded."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
 return h.hexdigest()
def main():
 manifest=json.loads((ROOT/'INPUT_SHA256.json').read_text());bad=[]
 for name,expected in manifest.items():
  p=ROOT/name
  if not p.is_file() or digest(p)!=expected:bad.append(name)
 if bad:raise RuntimeError('Prepared files changed or missing: '+', '.join(bad))
 print(f'PASS: {len(manifest)} prepared inputs match their SHA256 hashes.')
if __name__=='__main__':main()
